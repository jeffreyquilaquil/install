<?php

namespace app\Console\Commands;

use app\Models\Data;
use app\Models\Sensor;

use Illuminate\Console\Command;

class DatabaseBackup extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'backup';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'database backup and upload to Dropbox.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        echo shell_exec("mysqldump -u ".env('DB_USERNAME', '')." -p".env('DB_PASSWORD', '')." ".env('DB_DATABASE', '')." > "."/tmp/handa-".date('Y-m-d').".sql");
        echo shell_exec("tar cvzf ~/Dropbox/handa-".date('Y-m-d').".tgz /tmp/handa-".date('Y-m-d').".sql");
        echo shell_exec("rm /tmp/handa-".date('Y-m-d').".sql");
    }
}
