<?php

namespace app\Console\Commands;

use app\Models\Data;
use app\Models\Sensor;
use app\Models\Setting;

use Illuminate\Console\Command;

class FetchData extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'data:fetch';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get data from ASTII API.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $username   = Setting::pluck('st_username');
        $password   = Setting::pluck('st_password');

        $opts = array(
                'http' => array(
                    'method' => 'GET',
                    'header' => 'Authorization: Basic '.base64_encode("$username:$password")
                )
            );

        $context    = stream_context_create($opts);
        $sensors    = Sensor::where('dev_id', '!=', '0')->get();

        foreach($sensors as $sensor) {
            $url        = "http://weather.asti.dost.gov.ph/web-api/index.php/api/data/".$sensor->dev_id;

            $file       = @file_get_contents($url, false, $context);
            $data       = json_decode($file, true);

            if($file != false) {
                if($data['type_id'] == 'Waterlevel') {
                    foreach($data['data'] as $logs) {
                        $last_data      = Data::select('ss_id','d_date_time_read')->where('ss_id', '=', $sensor->ss_id)->where('d_date_time_read', '=', substr($logs['dateTimeRead'], 0, 19))->orderBy('d_id', 'DESC')->limit('1')->first();
                        if($last_data == null) {
                            $sensor_data                    = new Data;
                            $sensor_data->ss_id             = $sensor->ss_id;
                            $sensor_data->d_waterlevel      = $logs['waterlevel'] / 100;
                            $sensor_data->d_date_time_read  = substr($logs['dateTimeRead'], 0, 19);
                            $sensor_data->d_rain_value      = 0;
                            $sensor_data->d_rain_intensity  = 0;
                            $sensor_data->d_rain_duration   = 0;
                            $sensor_data->d_air_temperature = 0;
                            $sensor_data->d_air_pressure    = 0;
                            $sensor_data->d_wind_speed      = 0;
                            $sensor_data->d_wind_direction  = 0;
                            $sensor_data->d_air_humidity    = 0;
                            $sensor_data->save();
                        }
                    }
                }
                elseif($data['type_id'] == 'Rain2') {
                    foreach($data['data'] as $logs) {
                        $last_data      = Data::select('ss_id','d_date_time_read')->where('ss_id', '=', $sensor->ss_id)->where('d_date_time_read', '=', substr($logs['dateTimeRead'], 0, 19))->orderBy('d_id', 'DESC')->limit('1')->first();
                        if($last_data == null) {
                            $sensor_data                    = new Data;
                            $sensor_data->ss_id             = $sensor->ss_id;
                            $sensor_data->d_rain_value      = $logs['rain_value'];
                            $sensor_data->d_air_pressure    = $logs['air_pressure'];
                            $sensor_data->d_date_time_read  = substr($logs['dateTimeRead'], 0, 19);
                            $sensor_data->d_rain_intensity  = 0;
                            $sensor_data->d_rain_duration   = 0;
                            $sensor_data->d_air_temperature = 0;
                            $sensor_data->d_air_pressure    = 0;
                            $sensor_data->d_wind_speed      = 0;
                            $sensor_data->d_wind_direction  = 0;
                            $sensor_data->d_air_humidity    = 0;
                            $sensor_data->save();
                        }
                    }
                }
                elseif($data['type_id'] == 'Vaisala' || $data['type_id'] == 'Vaisala10') {
                    foreach($data['data'] as $logs) {
                        $last_data      = Data::select('ss_id','d_date_time_read')->where('ss_id', '=', $sensor->ss_id)->where('d_date_time_read', '=', substr($logs['dateTimeRead'], 0, 19))->orderBy('d_id', 'DESC')->limit('1')->first();
                        if($last_data == null) {
                            $sensor_data                    = new Data;
                            $sensor_data->ss_id             = $sensor->ss_id;
                            $sensor_data->d_waterlevel      = $logs['waterlevel'] / 100;
                            $sensor_data->d_date_time_read  = substr($logs['dateTimeRead'], 0, 19);
                            $sensor_data->d_rain_value      = 0;
                            $sensor_data->d_rain_intensity  = 0;
                            $sensor_data->d_rain_duration   = 0;
                            $sensor_data->d_air_temperature = 0;
                            $sensor_data->d_air_pressure    = 0;
                            $sensor_data->d_wind_speed      = 0;
                            $sensor_data->d_wind_direction  = 0;
                            $sensor_data->d_air_humidity    = 0;
                            $sensor_data->save();
                        }
                    }
                }
                elseif($data['type_id'] == 'Waterlevel & Rain 2') {
                    foreach($data['data'] as $logs) {
                        $last_data      = Data::select('ss_id','d_date_time_read')->where('ss_id', '=', $sensor->ss_id)->where('d_date_time_read', '=', substr($logs['dateTimeRead'], 0, 19))->orderBy('d_id', 'DESC')->limit('1')->first();
                        if($last_data == null) {
                            $sensor_data                    = new Data;
                            $sensor_data->ss_id             = $sensor->ss_id;
                            $sensor_data->d_waterlevel      = $logs['waterlevel'] / 100;
                            $sensor_data->d_rain_value      = $logs['rain_value'];
                            $sensor_data->d_air_pressure    = $logs['air_pressure'];
                            $sensor_data->d_date_time_read  = substr($logs['dateTimeRead'], 0, 19);
                            $sensor_data->d_rain_intensity  = 0;
                            $sensor_data->d_rain_duration   = 0;
                            $sensor_data->d_air_temperature = 0;
                            $sensor_data->d_wind_speed      = 0;
                            $sensor_data->d_wind_direction  = 0;
                            $sensor_data->d_air_humidity    = 0;
                            $sensor_data->save();
                        }
                    }
                }
            }
        }
    }
}
