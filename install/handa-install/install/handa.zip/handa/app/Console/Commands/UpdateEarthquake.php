<?php

namespace app\Console\Commands;

use app\Models\User;
use app\Models\Setting;
use app\Models\Bulletin;
use app\Helpers\CreateMessage;
use Illuminate\Console\Command;

class UpdateEarthquake extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'earthquake';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetch earthquake update to PHIVOLCS website.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $latest_earthquake  = '';
        $raw_text           = file_get_contents(Setting::pluck('st_earthquake'));
        $object             = new \DomDocument;

        @$object->loadHTML($raw_text);
        $eq_links           = $object->getElementsByTagName('a');

        foreach($eq_links as $eq_link) {
            if(strpos($eq_link->getAttribute('href'), 'Earthquake_Information/'.date('F').'/'.date('Y').'_'.date('md'))) {
                $latest_earthquake .= $eq_link->getAttribute('href');
                break;
            }
        }

        $phivolcs           = 'http://www.phivolcs.dost.gov.ph/html/update_SOEPD/';

        $raw_text           = file_get_contents($phivolcs.$latest_earthquake);
        $utf8_text          = strip_tags($raw_text);
        $utf8_text          = trim($utf8_text);
        $utf8_text          = str_replace("°","",$utf8_text);
        $utf8_text          = str_replace("&deg;","",$utf8_text);
        $utf8_text          = str_replace("\"","",$utf8_text);
        $utf8_text          = str_replace("\n","",$utf8_text);
        $utf8_text          = str_replace("\r","",$utf8_text);
        $utf8_text          = str_replace("\t"," ",$utf8_text);
        $utf8_text          = str_replace("&nbsp;"," ",$utf8_text);
        $utf8_text          = html_entity_decode($utf8_text, ENT_QUOTES, "UTF-8");

        // Date and Time
        list($GarbageText_01,$DummyText_01)     = explode("Date/Time",$utf8_text);
        list($GarbageText_02,$DummyText_02)     = explode("Location",$DummyText_01);
        list($Blank_01,$DateTime_01,$DateTime_02,$DateTime_03)      = explode(":",$GarbageText_02);
        
        $EarthquakeDateTime                     = trim($DateTime_01.":".$DateTime_02.":".$DateTime_03);
        
        // Location
        list($GarbageText_03,$DummyText_03)     = explode("Depth of    Focus (Km)",$DummyText_02);
        list($Blank_02,$Location)               = explode(":",$GarbageText_03);
        
        $EarthquakeLocation                     = trim($Location);
        
        // Depth of Focus
        list($GarbageText_04,$DummyText_04)     = explode("Origin",$DummyText_03);
        list($Blank_04,$Depth)                  = explode(":",$GarbageText_04);
        
        $EarthquakeDepth                        = trim($Depth);
        
        // Origin
        list($GarbageText_05,$DummyText_05)     = explode("Magnitude",$DummyText_04);
        list($Blank_05,$Origin)                 = explode(":",$GarbageText_05);
        
        $EarthquakeOrigin                       = trim($Origin);
        
        // Magnitude
        list($GarbageText_06,$DummyText_06)     = explode("Reported    Intensities",$DummyText_05);
        list($Blank_06,$Magnitude)              = explode(":",$GarbageText_06);
        
        $EarthquakeMagnitude                    = trim($Magnitude);
        
        // Expecting Damage
        list($GarbageText_07,$DummyText_07)     = explode("Expecting    Damage",$DummyText_06);
        list($GarbageText_08,$DummyText_08)     = explode("Expecting Aftershocks",$DummyText_07);
        list($Blank_07,$Damage)                 = explode(":",$GarbageText_08);
        
        $EarthquakeDamage                       = trim($Damage);
        
        // Expecting Aftershocks
        list($GarbageText_09,$DummyText_09)     = explode("Issued    On",$DummyText_08);
        list($Blank_08,$Aftershocks)            = explode(":",$GarbageText_09);
        
        $EarthquakeAftershocks                  = trim($Aftershocks);
        
        // Issued On
        list($GarbageText_10,$DummyText_10)     = explode("Prepared",$DummyText_09);
        list($Blank_09,$Issued_01,$Issued_02)   = explode(":",$GarbageText_10);
        
        $EarthquakeIssuedOn                     = trim($Issued_01.":".$Issued_02);
        // $EarthquakeTxtFile                      = '/var/web/handa-v3.1/public/updates/earthquake.txt';

        $file           = fopen('public/updates/earthquake.txt',"w");
        fwrite($file, "Date/Time: ".$EarthquakeDateTime."");
        fwrite($file, "\n");
        fwrite($file, "Location: ".$EarthquakeLocation."");
        fwrite($file, "\n");
        fwrite($file, "Depth of Focus (Km): ".$EarthquakeDepth."");
        fwrite($file, "\n");
        fwrite($file, "Origin: ".$EarthquakeOrigin."");
        fwrite($file, "\n");
        fwrite($file, "Magnitude: ".$EarthquakeMagnitude."");
        fwrite($file, "\n");
        fwrite($file, "Expecting Damage: ".$EarthquakeDamage."");
        fwrite($file, "\n");
        fwrite($file, "Expecting Aftershocks: ".$EarthquakeAftershocks."");
        fwrite($file, "\n");
        fwrite($file, "Issued On: ".$EarthquakeIssuedOn."");
        fclose($file);

        $message = file_get_contents('public/updates/earthquake.txt', 1);
        $message = preg_replace("/[^a-zA-Z0-9\s:.\n,]/", "", $message);

        echo $message."\n";

        if(empty($message)) {
            echo "Message is empty. not saving.";
        }
        else {
            $file = fopen('public/updates/earthquake.txt',"w");
            fwrite($file, $message);
            fclose($file);

            $latest_bulletin    = Bulletin::where('bl_message', '=', $message)->where('bt_id', '=', '1')->latest('bl_id')->get();

            if($latest_bulletin->count()) {
                echo "Duplicate bulletin detected. will not save to database.\n\n";
            }
            else {
                $bulletin               = new Bulletin;
                $bulletin->bl_message   = $message;
                $bulletin->bt_id        = 1;
                $bulletin->bl_type      = 'Auto';
                $bulletin->save();

                $earthquake_update      = 'ID: '.$bulletin->bl_id."\n\n";
                $earthquake_update      .= '[EARTHQUAKE UPDATE]'."\n\n";
                $earthquake_update      .= $message."\n\n";
                $earthquake_update      .= Setting::pluck('st_footer');

                $handa_users            = User::where('is_updated', '=', '1')->where('is_active', '=', '1')->get();

                if(!count($handa_users)) {
                    echo "No handa user(s) is active.";
                }
                else {
                    foreach($handa_users as $user) {
                        $msg    = new CreateMessage;
                        $msg->send_message($user->u_number, $earthquake_update, 'Update', $bulletin->bl_id);
                    }
                }
            }
        }
    }
}
