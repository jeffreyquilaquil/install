<?php

namespace app\Console\Commands;

use app\Models\User;
use app\Models\Setting;
use app\Models\Bulletin;
use app\Helpers\CreateMessage;
use Illuminate\Console\Command;

class UpdateWeather extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'weather';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetch weather update to PAGASA website.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $raw_text       = file_get_contents(Setting::pluck('st_weather'));
        $object         = new \DOMDocument;
        @$object->loadHTML($raw_text);

        $xpath                  = new \DOMXPath($object);
        $issued_at_text         = $xpath->query('//div[@id="content"]');

        foreach($issued_at_text as $a) {
            $data_string    = preg_replace('/\s\s+/', ' ', $a->nodeValue);
            $data_string    = preg_replace("/[^A-Za-z0-9\.: -]/", " ", $a->nodeValue);
            $data_string    = substr($data_string, stripos($data_string, "Issued at"));
            $issued_at      = substr($data_string, 0, stripos($data_string, "Synopsis"));
            $data_string    = substr($data_string, stripos($data_string, "Synopsis"));
            $synopsis       = substr($data_string, 0, strpos($data_string, "."));
            $data_string    = trim(substr($data_string, stripos($data_string, "Forecast:")));
            $data_string    = preg_replace('/\s\s+/', ' ', $data_string);
            $forecast       = substr($data_string, 0, strrpos($data_string, "."));
            $issued_at      = preg_replace('/\s+/', ' ', $issued_at);
            $synopsis       = preg_replace('/\s+/', ' ', $synopsis);
            $forecast       = preg_replace('/\s+/', ' ', $forecast).".";
        }

        if($issued_at == "" || $synopsis == "" || $forecast == "") {
            echo "There is a missing part(s) of the bulletin.\n";
            echo $issued_at."\n\n";
            echo $synopsis."\n\n";
            echo $forecast;
        }
        else {
            $file       = fopen('public/updates/weather.txt',"w");
            fwrite($file, trim($issued_at));
            fwrite($file, "\n\n");
            fwrite($file, trim($synopsis));
            fwrite($file, "\n\n");
            fwrite($file, trim($forecast));
            fwrite($file, "\n");
            fclose($file);

            $message            = file_get_contents('public/updates/weather.txt', 1);
            $latest_bulletin    = Bulletin::where('bl_message', '=', $message)->where('bt_id', '=', '3')->latest('bl_id')->get();

            if($latest_bulletin->count()) {
                echo "Duplicate bulletin detected. will not save to database.\n\n";
            }
            else {
                $bulletin               = new Bulletin;
                $bulletin->bl_message   = $message;
                $bulletin->bt_id        = 3;
                $bulletin->bl_type      = 'Auto';
                $bulletin->save();

                $weather_update         = 'ID: '.$bulletin->bl_id."\n\n";
                $weather_update         .= '[WEATHER UPDATE]'."\n\n";
                $weather_update         .= $message."\n\n";
                $weather_update         .= Setting::pluck('st_footer');

                $handa_users            = User::where('is_active', '=', '1')->where('is_updated', '=', '1')->get();

                if(!count($handa_users)) {
                    echo "No handa user(s) is active.";
                }
                else {
                    foreach($handa_users as $user) {
                        $msg    = new CreateMessage;
                        $msg->send_message($user->u_number, $weather_update, 'Update', $bulletin->bl_id);
                    }
                }
            }
        }
    }
}
