<?php

namespace app\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        Commands\FetchData::class,
        Commands\MessageSent::class,
        Commands\MessageFailed::class,
        Commands\MessageReceived::class,
        Commands\UpdateWeather::class,
        Commands\UpdateEarthquake::class,
        Commands\DatabaseBackup::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('backup')->fridays();
        $schedule->command('earthquake')->everyTenMinutes();
        $schedule->command('weather')->everyTenMinutes();
        $schedule->command('data:fetch')->everyTenMinutes();
    }
}
