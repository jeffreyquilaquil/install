<?php

namespace app\Http\Controllers\backend;

use View;
use Input;

use app\Models\Map;
use app\Http\Requests\MapValidation;
class MapController extends Controller
{
	public function __construct()
	{
		$data = array(
			'page' 		=> 'Maps',
		);
		View::share('data', $data);
	}

	public function index()
	{
		$search 	= '';
		$option 	= 'View';
		$maps 		= Map::latest('m_id')->Paginate(25);
		return view('backend.maps.maps', compact('search', 'maps', 'option'));
	}

	public function search()
	{
		$search 	= Input::get('search');
		$option 	= 'Search';
		$maps 		= Map::where('m_name', 'like', "%$search%")
							 ->latest('m_id')->Paginate(25);
		return view('backend.maps.maps', compact('search', 'maps', 'option'));
	}

	public function add()
	{
		$id 		= 0;
		$map 		= '';
		$option 	= 'Add';
		return view('backend.maps.form', compact('option', 'id', 'map'));
	}

	public function edit($id)
	{
		$option 	= 'Edit';
		$map 		= Map::find($id);
		return view('backend.maps.form', compact('option', 'id', 'map'));
	}

	public function save(MapValidation $request)
	{
		if($request->get('id') == 0) {
			$map = Map::create($request->all());
			$request->except('m_path');
			if($request->file('m_path') != NULL) {
				$request->file('m_path')->move('images/frontend/maps', $request->file('m_path')->getClientOriginalName());
				$map->m_path = 'images/frontend/maps/'.$request->file('m_path')->getClientOriginalName();
				$map->update();
			}
			return redirect('backdoor/maps')->with('success', 'New map successfully added.');
		}
		else {
			$map = Map::find($request->get('id'));
			$map->update($request->all());
			$request->except('m_path');
			if($request->file('m_path') != NULL) {
				$request->file('m_path')->move('images/frontend/maps', $request->file('m_path')->getClientOriginalName());
				$map->m_path = 'images/frontend/maps/'.$request->file('m_path')->getClientOriginalName();
				$map->update();
			}
			return redirect('backdoor/maps')->with('update', 'Map successfully updated.');
		}
	}
}