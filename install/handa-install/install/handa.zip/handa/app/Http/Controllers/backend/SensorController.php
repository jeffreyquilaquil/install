<?php

namespace app\Http\Controllers\backend;

use View;
use Input;

use app\Models\Sensor;
use app\Http\Requests\SensorValidation;

class SensorController extends Controller
{
	public function __construct()
	{
		$data = array(
			'page' 		=> 'Sensors',
		);
		View::share('data', $data);
	}

	public function index()
	{
		$search 	= '';
		$option 	= 'View';
		$sensors 	= Sensor::latest('ss_id')->Paginate(25);
		return view('backend.sensors.sensors', compact('search', 'sensors', 'option'));
	}

	public function search()
	{
		$search 	= Input::get('search');
		$option 	= 'Search';
		$sensors 	= Sensor::where('ss_address', 'like', "%$search%")
							  ->orWhere('ss_latitude', 'like', "%$search%")
							  ->orWhere('ss_longitude', 'like', "%$search%")
							  ->latest('ss_id')->Paginate(25);
		return view('backend.sensors.sensors', compact('search', 'sensors', 'option'));
	}

	public function add()
	{
		$id 		= 0;
		$sensor 	= '';
		$option 	= 'Add';
		return view('backend.sensors.form', compact('option', 'id', 'sensor'));
	}

	public function edit($id)
	{
		$option 	= 'Edit';
		$sensor 	= Sensor::find($id);
		return view('backend.sensors.form', compact('option', 'id', 'sensor'));
	}

	public function save(SensorValidation $request)
	{
		if($request->get('id') == 0) {
			$sensor = Sensor::create($request->all());
			return redirect('backdoor/sensors')->with('success', 'New sensor successfully added.');
		}
		else {
			$sensor = Sensor::find($request->get('id'));
			$sensor->update($request->all());
			return redirect('backdoor/sensors')->with('update', 'Sensor successfully updated.');
		}
	}
}