<?php

namespace app\Http\Controllers\frontend;

use DB;
use View;

use app\Models\Data;
use app\Models\Sensor;
use app\Models\Bulletin;
use app\Models\Setting;

class HomeController extends Controller
{
	public function __construct()
	{
		$data = array(
			'page' 		=> 'Home',
			'latest_eq' => Bulletin::where('bt_id', '=', '1')->where('created_at', '>=', DB::raw('DATE_SUB(NOW(), INTERVAL 1 DAY)'))->orderBy('created_at', 'DESC')->limit('5')->get(),
			'latest_wb' => Bulletin::where('bt_id', '=', '3')->where('created_at', '>=', DB::raw('DATE_SUB(NOW(), INTERVAL 1 DAY)'))->orderBy('created_at', 'DESC')->limit('5')->get(),
			'latest_tc' => Bulletin::where('bt_id', '=', '7')->where('created_at', '>=', DB::raw('DATE_SUB(NOW(), INTERVAL 1 DAY)'))->orderBy('created_at', 'DESC')->limit('5')->get()
		);
		View::share('data', $data);
	}

	public function index()
	{
		$rainfall_data 	= '';
		$latitude 		= Setting::pluck('st_latitude');
		$longitude 		= Setting::pluck('st_longitude');
		$key 			= Setting::pluck('st_api_key');
		$sensors 		= Sensor::where('ss_type', '=', '1')->orWhere('ss_type', '=', '2')->get();
		foreach($sensors as $sensor) {
			$rainfall_data[] = array(
					'sensor_data' 		=> Data::select(DB::raw('AVG(d_rain_value) as avg_rain'))->where('ss_id', '=', $sensor->ss_id)->where('d_date_time_read', '>=', DB::raw('DATE_SUB(NOW(), INTERVAL 1 HOUR)'))->limit('4')->pluck('avg_rain'),
					'sensor_address' 	=> $sensor->ss_address
				);
		}
		return view('frontend.home.home', compact('rainfall_data', 'eq_array', 'latitude', 'longitude', 'key'));
	}

	public function map()
	{
		$sensors 	= Sensor::get();
		foreach($sensors as $sensor) {
			$sensor_data[] = array(
					'ss_id' 		=> $sensor->ss_id,
					'ss_data' 		=> $this->fetch_data($sensor->ss_id, $sensor->ss_type),
					'ss_address'	=> $sensor->ss_address,
					'ss_latitude'	=> $sensor->ss_latitude,
					'ss_longitude'	=> $sensor->ss_longitude,
					'ss_type' 		=> $sensor->ss_type
				);
		}
		return json_encode($sensor_data);
	}

	public function fetch_data($id, $type)
	{
		if($type == '1' || $type == '2') {
			$data 				= DB::select("SELECT d_date_time_read, DATE_FORMAT(d_date_time_read, '%M %d, %Y %h:%i %p') as date_time_read, AVG(d_rain_value) as average_rain_value FROM (SELECT d_id, ss_id, d_waterlevel, d_date_time_read, d_rain_value FROM h_data WHERE ss_id = $id ORDER BY d_date_time_read DESC LIMIT 4) a");
			if($data[0]['d_date_time_read'] == null) {
				$ss_data['ss_data'] = number_format(0, 1);
				$ss_data['ss_date'] = date('F d, Y h:i A');
				$ss_data['status'] 	= 0;
			}
			else {
				$ss_data['ss_data'] = number_format($data[0]['average_rain_value'], 1);
				$ss_data['ss_date'] = $data[0]['date_time_read'];
				$ss_data['status'] 	= intval(abs(strtotime($data[0]['d_date_time_read']) - strtotime(date('Y-m-d H:i:s')))/86400) > 7 ? '0' : '1';
			}
		}
		else {
			$data 				= Data::select(DB::raw('d_date_time_read, DATE_FORMAT(d_date_time_read, "%M %d, %Y %h:%i: %p") as date_time_read, d_waterlevel'))->where('ss_id', '=', $id)->orderBy('d_date_time_read', 'DESC')->limit('1')->get();
			if($data->isEmpty()) {
				$ss_data['ss_data'] = number_format(0, 1);
				$ss_data['ss_date'] = date('F d, Y h:i A');
				$ss_data['status'] 	= 0;
			}
			else {
				$ss_data['ss_data'] = number_format($data[0]->d_waterlevel, 1);
				$ss_data['ss_date'] = $data[0]->date_time_read;
				$ss_data['status'] 	= intval(abs(strtotime($data[0]->d_date_time_read) - strtotime(date('Y-m-d H:i:s')))/86400) > 7 ? '0' : '1';
			}

		}
		return $ss_data;
	}

	public function sensor_feeds()
	{
		$sensors 						= Sensor::get();
        foreach($sensors as $key => $sensor) {
            $data = Data::select(DB::raw('d_date_time_read, DATE_FORMAT(d_date_time_read, "%M %d, %Y %h:%i: %p") as d_date_time_read, d_waterlevel, d_rain_value'))->where('ss_id', '=', $sensor->ss_id)->where('d_date_time_read', '>=', DB::raw('DATE_SUB(NOW(), INTERVAL 1 HOUR)'))->orderBy('d_date_time_read', 'DESC')->limit('4')->get();
            if(!$data->isEmpty()) {
            	$data = $data->toArray();
                $sensor_feeds[] = array(
                	'd_rain_value'  => implode(",", array_pluck($data, ['d_rain_value'])),
                    'd_waterlevel'  => implode(",", array_pluck($data, ['d_waterlevel'])),
                    'ss_type'       => $sensor->ss_type,
                    'ss_address'    => $sensor->ss_address
                );
            }
        }
		return json_encode($sensor_feeds);
	}
}