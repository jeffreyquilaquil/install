<?php

namespace app\Http\Controllers\frontend;

use DB;
use View;
use Input;

use Carbon\Carbon;
use app\Models\Data;
use app\Models\Sensor;
use app\Models\Setting;
use app\Models\Bulletin;

use app\Http\Requests\DateFilter;

class StationController extends Controller
{
	public function __construct()
	{
		$data = array(
			'page' 		=> 'Stations',
			'latest_eq' => Bulletin::where('bt_id', '=', '1')->where('created_at', '>=', DB::raw('DATE_SUB(NOW(), INTERVAL 1 DAY)'))->orderBy('created_at', 'DESC')->limit('5')->get(),
			'latest_wb' => Bulletin::where('bt_id', '=', '3')->where('created_at', '>=', DB::raw('DATE_SUB(NOW(), INTERVAL 1 DAY)'))->orderBy('created_at', 'DESC')->limit('5')->get(),
			'latest_tc' => Bulletin::where('bt_id', '=', '7')->where('created_at', '>=', DB::raw('DATE_SUB(NOW(), INTERVAL 1 DAY)'))->orderBy('created_at', 'DESC')->limit('5')->get()
		);
		View::share('data', $data);
	}

	public function index()
	{
		$arg 		= Sensor::where('ss_type', '=', '1')->get();
		$aws 		= Sensor::where('ss_type', '=', '2')->get();
		$wlms 		= Sensor::where('ss_type', '=', '3')->get();
		$wlmsr 		= Sensor::where('ss_type', '=', '4')->get();
		return view('frontend.stations.stations', compact('arg', 'aws', 'wlms', 'wlmsr'));
	}

	public function aws($id)
	{
		$date_to 		= Input::get('date_to');
		$date_from 		= Input::get('date_from');
		$key 			= Setting::pluck('st_api_key');
		if(Input::get('date_from') == null && Input::get('date_to') == null) {
			$aws_data 	= Data::select('d_date_time_read', 'd_rain_value', 'd_wind_speed', 'd_rain_intensity', 'd_air_temperature', 'd_air_pressure', 'd_wind_direction', 'd_air_humidity')->where('ss_id', '=', $id)->orderBy('d_date_time_read', 'DESC')->Paginate(30);
		}
		else {
			$aws_data 	= Data::select('d_date_time_read', 'd_rain_value', 'd_wind_speed', 'd_rain_intensity', 'd_air_temperature', 'd_air_pressure', 'd_wind_direction', 'd_air_humidity')->where('ss_id', '=', $id)->whereBetween('d_date_time_read', [Carbon::parse(Input::get('date_from'))->format('Y-m-d'), Carbon::parse(Input::get('date_to'))->format('Y-m-d')])->orderBy('d_date_time_read', 'DESC')->Paginate(30);
		}

		$aws 			= Sensor::where('ss_id', '=', $id)->first();
		$aws_latest		= Data::select(DB::raw('MAX(d_date_time_read) as date_time, d_rain_value, d_wind_speed,d_rain_intensity,d_air_temperature,d_air_pressure, d_wind_direction, d_air_humidity'))->where('ss_id', '=', $id)->first();
		return view('frontend.stations.aws', compact('aws', 'aws_latest', 'aws_data', 'id', 'date_from', 'date_to', 'key'));
	}

	public function arg($id)
	{
		$date_to 		= Input::get('date_to');
		$date_from 		= Input::get('date_from');
		$key 			= Setting::pluck('st_api_key');
		if(Input::get('date_from') == null && Input::get('date_to') == null) {
			$arg_data 	= Data::select('d_date_time_read', 'd_rain_value')->where('ss_id', '=', $id)->orderBy('d_date_time_read', 'DESC')->Paginate(30);
		}
		else {
			$arg_data 	= Data::select('d_date_time_read', 'd_rain_value')->where('ss_id', '=', $id)->whereBetween('d_date_time_read', [Carbon::parse(Input::get('date_from'))->format('Y-m-d'), Carbon::parse(Input::get('date_to'))->format('Y-m-d')])->orderBy('d_date_time_read', 'DESC')->Paginate(30);
		}

		$arg 			= Sensor::where('ss_id', '=', $id)->first();
		$arg_latest		= Data::select(DB::raw('MAX(d_date_time_read) as date_time, d_rain_value'))->where('ss_id', '=', $id)->first();
		return view('frontend.stations.arg', compact('arg', 'arg_latest', 'arg_data', 'id', 'date_from', 'date_to', 'key'));
	}

	public function wlms($id)
	{
		$date_to 		= Input::get('date_to');
		$date_from 		= Input::get('date_from');
		$key 			= Setting::pluck('st_api_key');
		if(Input::get('date_from') == null && Input::get('date_to') == null) {
			$wlms_data 	= Data::select('d_date_time_read', 'd_waterlevel')->where('ss_id', '=', $id)->orderBy('d_date_time_read', 'DESC')->Paginate(30);
		}
		else {
			$wlms_data 	= Data::select('d_date_time_read', 'd_waterlevel')->where('ss_id', '=', $id)->whereBetween('d_date_time_read', [Carbon::parse(Input::get('date_from'))->format('Y-m-d'), Carbon::parse(Input::get('date_to'))->format('Y-m-d')])->orderBy('d_date_time_read', 'DESC')->Paginate(30);
		}

		$wlms 			= Sensor::where('ss_id', '=', $id)->first();
		$wlms_latest 	= Data::select(DB::raw('MAX(d_date_time_read) as date_time, d_waterlevel'))->where('ss_id', '=', $id)->first();
		return view('frontend.stations.wlms', compact('wlms', 'wlms_latest', 'wlms_data', 'id', 'date_from', 'date_to', 'key'));
	}

	public function wlmsr($id)
	{
		$date_to 		= Input::get('date_to');
		$date_from 		= Input::get('date_from');
		$key 			= Setting::pluck('st_api_key');
		if(Input::get('date_from') == null && Input::get('date_to') == null) {
			$wlmsr_data = Data::select('d_date_time_read', 'd_waterlevel', 'd_rain_value')->where('ss_id', '=', $id)->orderBy('d_date_time_read', 'DESC')->Paginate(30);
		}
		else {
			$wlmsr_data = Data::select('d_date_time_read', 'd_waterlevel', 'd_rain_value')->where('ss_id', '=', $id)->whereBetween('d_date_time_read', [Carbon::parse(Input::get('date_from'))->format('Y-m-d'), Carbon::parse(Input::get('date_to'))->format('Y-m-d')])->orderBy('d_date_time_read', 'DESC')->Paginate(30);
		}

		$wlmsr 			= Sensor::where('ss_id', '=', $id)->first();
		$wlmsr_latest 	= Data::select(DB::raw('MAX(d_date_time_read) as date_time, d_waterlevel, d_rain_value'))->where('ss_id', '=', $id)->first();
		return view('frontend.stations.wlmsr', compact('wlmsr', 'wlmsr_latest', 'wlmsr_data', 'id', 'date_from', 'date_to', 'key'));
	}

	public function chart_data($id)
	{
		$chart_data = Data::select('d_date_time_read', 'd_rain_value', 'd_waterlevel')->where('ss_id', '=', $id)->orderBy('d_id', 'DESC')->limit('48')->get();
		return json_encode($chart_data);
	}
}