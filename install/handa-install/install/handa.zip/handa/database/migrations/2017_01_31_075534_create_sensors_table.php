<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSensorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('h_sensors', function (Blueprint $table) {
            $table->increments('ss_id');
            $table->string('ss_address');
            $table->string('ss_latitude');
            $table->string('ss_longitude');
            $table->string('ss_elevation');
            $table->integer('ss_type');
            $table->integer('dev_id');
            $table->tinyInteger('is_active')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('h_sensors');
    }
}
