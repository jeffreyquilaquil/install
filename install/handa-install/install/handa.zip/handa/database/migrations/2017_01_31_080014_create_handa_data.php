<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateHandaData extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('h_data', function (Blueprint $table) {
            $table->mediumIncrements('d_id');
            $table->integer('ss_id')->unsigned();
            $table->foreign('ss_id')->references('ss_id')->on('h_sensors')->onUpdate('cascade');
            $table->datetime('d_date_time_read');
            $table->float('d_rain_value');
            $table->float('d_rain_intensity');
            $table->float('d_rain_duration');
            $table->float('d_air_temperature');
            $table->float('d_air_pressure');
            $table->float('d_wind_speed');
            $table->float('d_wind_direction');
            $table->float('d_air_humidity');
            $table->float('d_waterlevel');
            $table->index(['ss_id', 'd_date_time_read']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('h_data');
    }
}
