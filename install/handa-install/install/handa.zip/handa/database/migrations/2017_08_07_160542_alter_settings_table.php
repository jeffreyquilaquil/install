<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('h_settings', function (Blueprint $table) {
            $table->string('st_latitude');
            $table->string('st_longitude');
            $table->string('st_api_key');
            $table->string('st_username');
            $table->string('st_password');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
