<?php

use Illuminate\Database\Seeder;

class BulletinRecipientTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('h_bulletin_recipients')->delete();
        exec('mysql -u '.env('DB_USERNAME').' -p'.env('DB_PASSWORD').' '.env('DB_DATABASE').' < '.storage_path('sql/h_bulletin_recipients.sql'));
    }
}
