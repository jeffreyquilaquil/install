<?php

use Illuminate\Database\Seeder;

class BulletinTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('h_bulletins')->delete();
        exec('mysql -u '.env('DB_USERNAME').' -p'.env('DB_PASSWORD').' '.env('DB_DATABASE').' < '.storage_path('sql/h_bulletins.sql'));
    }
}
