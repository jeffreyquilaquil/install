<?php

use Illuminate\Database\Seeder;

class ContactGroupTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('h_contact_groups')->delete();
        exec('mysql -u '.env('DB_USERNAME').' -p'.env('DB_PASSWORD').' '.env('DB_DATABASE').' < '.storage_path('sql/h_contact_groups.sql'));
    }
}
