<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        $this->call(UserTableSeeder::class);
        $this->call(SensorTableSeeder::class);
        // $this->call(DataTableSeeder::class);
        $this->call(BulletinTypeTableSeeder::class);
        $this->call(BulletinTableSeeder::class);
        $this->call(GroupTableSeeder::class);
        $this->call(ContactTableSeeder::class);
        $this->call(ContactGroupTableSeeder::class);
        $this->call(BulletinRecipientTableSeeder::class);
        $this->call(SettingTableSeeder::class);
        $this->call(SmsLogTableSeeder::class);
        $this->call(SmsTimestampTableSeeder::class);
        
        Model::reguard();
    }
}
