<?php

use app\Models\Group;
use Illuminate\Database\Seeder;

class GroupTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		DB::table('h_groups')->delete();

		Group::create([
				'g_name' 		=> 'Batangas',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'Cavite',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'Laguna',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'Quezon',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'Rizal',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'RDRRMC4A',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'DOST4A',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'Regional Directors',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'Guest',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'DOST ROs',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'Media',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'First Send',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'NCR',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
		Group::create([
				'g_name' 		=> 'TestGroup',
				'is_active' 	=> 1,
				'created_at' 	=> date('Y-m-d H:i:s'),
				'updated_at' 	=> date('Y-m-d H:i:s')
			]);
    }
}
