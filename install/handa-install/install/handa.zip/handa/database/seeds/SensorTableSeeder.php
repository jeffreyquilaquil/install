<?php

use app\Models\Sensor;

use Illuminate\Database\Seeder;


class SensorTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('h_sensors')->delete();

        Sensor::create([
        		'ss_address' 	=> 'Malabanan, Balete, Batangas',
        		'ss_latitude' 	=> '14.01786',
        		'ss_longitude' 	=> '121.12888',
        		'ss_elevation' 	=> '209.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '437'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Kumintang Ilaya, Batangas, Batangas',
        		'ss_latitude' 	=> '13.7733',
        		'ss_longitude' 	=> '121.0619',
        		'ss_elevation' 	=> '43.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '149'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Balitoc, Calatagan, Batangas',
        		'ss_latitude' 	=> '13.854639',
        		'ss_longitude' 	=> '120.632222',
        		'ss_elevation' 	=> '21.0',
        		'ss_type' 		=> '2',
        		'dev_id' 		=> '29'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Barangay 2, Laurel, Batangas',
        		'ss_latitude' 	=> '14.05033',
        		'ss_longitude' 	=> '120.93244',
        		'ss_elevation' 	=> '43.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '442'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Ayao-iyao, Lemery, Batangas',
        		'ss_latitude' 	=> '13.89663',
        		'ss_longitude' 	=> '120.91284',
        		'ss_elevation' 	=> '6.0',
        		'ss_type' 		=> '4',
        		'dev_id' 		=> '504'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Calo, Lobo, Batangas',
        		'ss_latitude' 	=> '13.68753',
        		'ss_longitude' 	=> '121.20902',
        		'ss_elevation' 	=> '303.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '486'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Poblacion, Padre Garcia, Batangas',
        		'ss_latitude' 	=> '13.68753',
        		'ss_longitude' 	=> '121.20902',
        		'ss_elevation' 	=> '303.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '455'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Escribano, San Juan, Batangas',
        		'ss_latitude' 	=> '13.82076',
        		'ss_longitude' 	=> '121.37399',
        		'ss_elevation' 	=> '33.0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '757'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'San Francisco, Santo Tomas, Batangas',
        		'ss_latitude' 	=> '14.04496',
        		'ss_longitude' 	=> '121.18866',
        		'ss_elevation' 	=> '224.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '436'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Barangay I, Amadeo, Cavite',
        		'ss_latitude' 	=> '14.17023',
        		'ss_longitude' 	=> '120.92218',
        		'ss_elevation' 	=> '442.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '440'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Lantic, Carmona, Cavite',
        		'ss_latitude' 	=> '14.26472',
        		'ss_longitude' 	=> '121.08083',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '457'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Bancod, Indang, Cavite',
        		'ss_latitude' 	=> '14.197867',
        		'ss_longitude' 	=> '120.883533',
        		'ss_elevation' 	=> '309.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '147'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Sampaloc I, Dasmarinas City, Cavite',
        		'ss_latitude' 	=> '14.31219',
        		'ss_longitude' 	=> '120.97131',
        		'ss_elevation' 	=> '138.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '439'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Ramirez, Magallanes, Cavite',
        		'ss_latitude' 	=> '14.17002',
        		'ss_longitude' 	=> '120.71764',
        		'ss_elevation' 	=> '302.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '627'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Brgy. 14 - Loro, Cavite City, Cavite',
        		'ss_latitude' 	=> '14.494444',
        		'ss_longitude' 	=> '120.899222',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '2',
        		'dev_id' 		=> '31'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Masaya, Bay, Laguna',
        		'ss_latitude' 	=> '14.14341',
        		'ss_longitude' 	=> '121.27277',
        		'ss_elevation' 	=> '28.1',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '482'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Bubukal, Santa Cruz, Laguna',
        		'ss_latitude' 	=> '14.255167',
        		'ss_longitude' 	=> '121.407417',
        		'ss_elevation' 	=> '21.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '148'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Barangay I Poblacion, Cabuyao, Laguna',
        		'ss_latitude' 	=> '14.27135',
        		'ss_longitude' 	=> '121.12427',
        		'ss_elevation' 	=> '34.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '668'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Paliparan, Calauan, Laguna',
        		'ss_latitude' 	=> '14.11902',
        		'ss_longitude' 	=> '121.28717',
        		'ss_elevation' 	=> '53.2',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '481'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Poblacion, Cavinti, Laguna',
        		'ss_latitude' 	=> '14.24685',
        		'ss_longitude' 	=> '121.50039',
        		'ss_elevation' 	=> '213.36',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '441'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Longos, Kalayaan, Laguna',
        		'ss_latitude' 	=> '14.33601',
        		'ss_longitude' 	=> '121.49829',
        		'ss_elevation' 	=> '325.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '438'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Taytay, Majayjay, Laguna',
        		'ss_latitude' 	=> '14.11465',
        		'ss_longitude' 	=> '121.50526',
        		'ss_elevation' 	=> '538.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '443'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Maitim, Los Banos, Laguna',
        		'ss_latitude' 	=> '14.1564',
        		'ss_longitude' 	=> '121.234',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '287'
        	]);
        Sensor::create([
        		'ss_address' 	=> ' Inabuan, San Francisco - Aurora, Quezon',
        		'ss_latitude' 	=> '14.13332',
        		'ss_longitude' 	=> '121.41523',
        		'ss_elevation' 	=> '216.11',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '444'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Bagong Pook, Rizal, Laguna',
        		'ss_latitude' 	=> '14.11053',
        		'ss_longitude' 	=> '121.404448',
        		'ss_elevation' 	=> '265',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '447'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Pook, Santa Rosa City, Laguna',
        		'ss_latitude' 	=> '14.31446',
        		'ss_longitude' 	=> '121.11377',
        		'ss_elevation' 	=> '35.8',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '446'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'San Francisco, Victoria, Laguna',
        		'ss_latitude' 	=> '14.2014',
        		'ss_longitude' 	=> '121.35667',
        		'ss_elevation' 	=> '18.51',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '445'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Malinao Ilaya, Atimonan, Quezon',
        		'ss_latitude' 	=> '14.014692',
        		'ss_longitude' 	=> '121.917922',
        		'ss_elevation' 	=> '34.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '435'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Inabuan, San Francisco - Aurora, Quezon',
        		'ss_latitude' 	=> '13.346306',
        		'ss_longitude' 	=> '122.530833',
        		'ss_elevation' 	=> '19.0',
        		'ss_type' 		=> '2',
        		'dev_id' 		=> '35'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Lalo, Tayabas, Quezon',
        		'ss_latitude' 	=> '14.052783',
        		'ss_longitude' 	=> '121.539833',
        		'ss_elevation' 	=> '657.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '151'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Lita, Tayabas, Quezon',
        		'ss_latitude' 	=> '14.018078',
        		'ss_longitude' 	=> '121.596672',
        		'ss_elevation' 	=> '160.0',
        		'ss_type' 		=> '2',
        		'dev_id' 		=> '37'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Magsaysay, Infanta, Quezon',
        		'ss_latitude' 	=> '14.55138',
        		'ss_longitude' 	=> '121.596672',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '2',
        		'dev_id' 		=> '34'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Talisoy, Jomalig, Quezon',
        		'ss_latitude' 	=> '14.696847',
        		'ss_longitude' 	=> '122.338889',
        		'ss_elevation' 	=> '5.0',
        		'ss_type' 		=> '2',
        		'dev_id' 		=> '33'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Matandang Sabang Kanluran, Catanauan, Quezon',
        		'ss_latitude' 	=> '13.602',
        		'ss_longitude' 	=> '122.295',
        		'ss_elevation' 	=> '36.1226',
        		'ss_type' 		=> '2',
        		'dev_id' 		=> '0'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Socorro, Unisan, Quezon',
        		'ss_latitude' 	=> '13.838067',
        		'ss_longitude' 	=> '121.97835',
        		'ss_elevation' 	=> '14.6',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '198'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Poblacion Ibaba, Angono, Rizal',
        		'ss_latitude' 	=> '14.526811',
        		'ss_longitude' 	=> '121.142206',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '0'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'San Juan, Baras, Rizal',
        		'ss_latitude' 	=> '14.55369',
        		'ss_longitude' 	=> '121.2858',
        		'ss_elevation' 	=> '148.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '483'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Bagumbayan, Pililla, Rizal',
        		'ss_latitude' 	=> '14.47678',
        		'ss_longitude' 	=> '121.31559',
        		'ss_elevation' 	=> '29.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '485'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Bagong Nayon, Antipolo City, Rizal',
        		'ss_latitude' 	=> '14.662644',
        		'ss_longitude' 	=> '121.168919',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '2012'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'San Jose, Antipolo City, Rizal',
        		'ss_latitude' 	=> '14.639419',
        		'ss_longitude' 	=> '121.222047',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '0'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Looc, Cardona, Rizal',
        		'ss_latitude' 	=> '14.473367',
        		'ss_longitude' 	=> '121.2203',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '4',
        		'dev_id' 		=> '86'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Balite, Rodriguez, Rizal',
        		'ss_latitude' 	=> '14.733133',
        		'ss_longitude' 	=> '121.130364',
        		'ss_elevation' 	=> '33.8',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1526'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'San Isidro, Rodriguez, Rizal',
        		'ss_latitude' 	=> '14.763161',
        		'ss_longitude' 	=> '121.159708',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '1525'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Bombongan, Morong, Rizal',
        		'ss_latitude' 	=> '14.5174',
        		'ss_longitude' 	=> '121.235467',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '150'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'San Rafael, Rodriguez, Rizal',
        		'ss_latitude' 	=> '14.727913',
        		'ss_longitude' 	=> '121.191932',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '212'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Mayasang, Lemery, Batangas',
        		'ss_latitude' 	=> '14.01604',
        		'ss_longitude' 	=> '120.8628',
        		'ss_elevation' 	=> '480.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '971'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Dayap Itaas, Laurel, Batangas',
        		'ss_latitude' 	=> '14.05535',
        		'ss_longitude' 	=> '120.85189',
        		'ss_elevation' 	=> '625.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '970'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Barangay 1 Poblacion, General Mariano Alvarez, Cavite',
        		'ss_latitude' 	=> '14.29558',
        		'ss_longitude' 	=> '121.00694',
        		'ss_elevation' 	=> '178.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '962'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Villahermosa, Lopez, Quezon',
        		'ss_latitude' 	=> '13.87004',
        		'ss_longitude' 	=> '122.26912',
        		'ss_elevation' 	=> '27',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '1096'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Sampaloc Bogon, Sariaya, Quezon',
        		'ss_latitude' 	=> '13.99579',
        		'ss_longitude' 	=> '121.50408',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '976'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Barangay Zone 1, Atimonan, Quezon',
        		'ss_latitude' 	=> '13.99206',
        		'ss_longitude' 	=> '121.89258',
        		'ss_elevation' 	=> '42',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '0'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Bunga, Tanza, Cavite',
        		'ss_latitude' 	=> '14.3512',
        		'ss_longitude' 	=> '120.87189',
        		'ss_elevation' 	=> '38',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '825'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Patugo, Balayan, Batangas',
        		'ss_latitude' 	=> '14.00401',
        		'ss_longitude' 	=> '120.78477',
        		'ss_elevation' 	=> '182',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '978'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Leviste, Rosario, Batangas',
        		'ss_latitude' 	=> '13.77391',
        		'ss_longitude' 	=> '121.27545',
        		'ss_elevation' 	=> '142',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '0'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Barangay I, Silang, Cavite',
        		'ss_latitude' 	=> '14.22323',
        		'ss_longitude' 	=> '120.97126',
        		'ss_elevation' 	=> '323',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '953'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Molino II, Bacoor, Cavite',
        		'ss_latitude' 	=> '14.39745',
        		'ss_longitude' 	=> '120.98040',
        		'ss_elevation' 	=> '42',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1185'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Macabling, Santa Rosa City, Laguna',
        		'ss_latitude' 	=> '14.29760',
        		'ss_longitude' 	=> '121.09422',
        		'ss_elevation' 	=> '20',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1228'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Santa Rosa II, Noveleta, Cavite',
        		'ss_latitude' 	=> '14.42073',
        		'ss_longitude' 	=> '120.88497',
        		'ss_elevation' 	=> '22',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1163'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Macabling, Santa Rosa City, Laguna',
        		'ss_latitude' 	=> '14.29745',
        		'ss_longitude' 	=> '121.09413',
        		'ss_elevation' 	=> '17',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1226'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'San Antonio, Binan City, Laguna',
        		'ss_latitude' 	=> '14.33465',
        		'ss_longitude' 	=> '121.08595',
        		'ss_elevation' 	=> '12',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1209'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Dela Paz, Binan City, Laguna',
        		'ss_latitude' 	=> '14.34266',
        		'ss_longitude' 	=> '121.08481',
        		'ss_elevation' 	=> '29',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1243'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Santo Nino, Binan City, Laguna',
        		'ss_latitude' 	=> '14.33172',
        		'ss_longitude' 	=> '121.08485',
        		'ss_elevation' 	=> '19',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1227'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Don Jose, Santa Rosa City, Laguna',
        		'ss_latitude' 	=> '14.26180',
        		'ss_longitude' 	=> '121.05758',
        		'ss_elevation' 	=> '0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1262'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Tubigan, Binan City, Laguna',
        		'ss_latitude' 	=> '14.32802',
        		'ss_longitude' 	=> '121.07792',
        		'ss_elevation' 	=> '23',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1210'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Katigan Kanluran, Tayabas, Quezon',
        		'ss_latitude' 	=> '14.04466',
        		'ss_longitude' 	=> '121.61776',
        		'ss_elevation' 	=> '177.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '1263'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Santa Catalina, Atimonan, Quezon',
        		'ss_latitude' 	=> '14.020688',
        		'ss_longitude' 	=> '121.814926',
        		'ss_elevation' 	=> '0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '914'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Santa Catalina, Atimonan, Quezon',
        		'ss_latitude' 	=> '14.088629',
        		'ss_longitude' 	=> '121.759307',
        		'ss_elevation' 	=> '0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '1095'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Hinapulan, Boac, Marinduque',
        		'ss_latitude' 	=> '13.4103',
        		'ss_longitude' 	=> '121.94',
        		'ss_elevation' 	=> '0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '0'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Tiguion, Gasan, Marinduque',
        		'ss_latitude' 	=> '13.334722',
        		'ss_longitude' 	=> '121.860556',
        		'ss_elevation' 	=> '37.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '0'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Bangbangalon, Boac, Marinduque',
        		'ss_latitude' 	=> '13.364229',
        		'ss_longitude' 	=> '121.947311',
        		'ss_elevation' 	=> '0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '0'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Poblacion, Binan City, Laguna',
        		'ss_latitude' 	=> '14.33903',
        		'ss_longitude' 	=> '121.0856',
        		'ss_elevation' 	=> '18',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1208'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Malindig, Bauan, Batangas',
        		'ss_latitude' 	=> '13.81010',
        		'ss_longitude' 	=> '120.96346',
        		'ss_elevation' 	=> '152',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '974'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Sampaloc, Tanay, Rizal',
        		'ss_latitude' 	=> '14.4999',
        		'ss_longitude' 	=> '121.28285',
        		'ss_elevation' 	=> '13',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '484'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'San Salvador, Baras, Rizal',
        		'ss_latitude' 	=> '14.55369',
        		'ss_longitude' 	=> '121.2858',
        		'ss_elevation' 	=> '148',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '483'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Banay-banay I, Lipa City, Batangas',
        		'ss_latitude' 	=> '13.93415',
        		'ss_longitude' 	=> '121.19043',
        		'ss_elevation' 	=> '365.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '1810'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Mataas Na Pulo, Nasugbu, Batangas',
        		'ss_latitude' 	=> '14.08793',
        		'ss_longitude' 	=> '120.72858',
        		'ss_elevation' 	=> '95.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '1811'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Toong, Tuy, Batangas',
        		'ss_latitude' 	=> '14.05',
        		'ss_longitude' 	=> '120.76',
        		'ss_elevation' 	=> '164.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '1813'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Bulakin I, Dolores, Quezon',
        		'ss_latitude' 	=> '14.01',
        		'ss_longitude' 	=> '121.54',
        		'ss_elevation' 	=> '155.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '1866'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Pina, Taysan, Batangas',
        		'ss_latitude' 	=> '13.72',
        		'ss_longitude' 	=> '121.22',
        		'ss_elevation' 	=> '105.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '1816'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Sapangan, San Juan, Batangas',
        		'ss_latitude' 	=> '13.78',
        		'ss_longitude' 	=> '131.3',
        		'ss_elevation' 	=> '61.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '1867'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Malibu, Tuy, Batangas',
        		'ss_latitude' 	=> '13.99',
        		'ss_longitude' 	=> '120.72',
        		'ss_elevation' 	=> '20.0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1815'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Sambat, Balayan, Batangas',
        		'ss_latitude' 	=> '13.95',
        		'ss_longitude' 	=> '120.72',
        		'ss_elevation' 	=> '84.0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1817'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Manggalang-Bantilan, Sariaya, Quezon',
        		'ss_latitude' 	=> '13.833849',
        		'ss_longitude' 	=> '121.430328',
        		'ss_elevation' 	=> '16.0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1869'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Pinagbayanan, San Juan, Batangas',
        		'ss_latitude' 	=> '13.81',
        		'ss_longitude' 	=> '121.44',
        		'ss_elevation' 	=> '12.0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1871'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Malabrigo, Lobo, Batangas',
        		'ss_latitude' 	=> '13.645149',
        		'ss_longitude' 	=> '121.212791',
        		'ss_elevation' 	=> '17.0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1870'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Barangay 2, Lian, Batangas',
        		'ss_latitude' 	=> '14.042168',
        		'ss_longitude' 	=> '120.651362',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1818'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Dacanlao, Calaca, Batangas',
        		'ss_latitude' 	=> '13.939555',
        		'ss_longitude' 	=> '120.778008',
        		'ss_elevation' 	=> '0.0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1819'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Almacen, Unisan, Quezon',
        		'ss_latitude' 	=> '13.87',
        		'ss_longitude' 	=> '122.0',
        		'ss_elevation' 	=> '11.0',
        		'ss_type' 		=> '3',
        		'dev_id' 		=> '1883'
        	]);
        Sensor::create([
        		'ss_address' 	=> 'Cahil, Calaca, Batangas',
        		'ss_latitude' 	=> '14.03051',
        		'ss_longitude' 	=> '120.83487',
        		'ss_elevation' 	=> '445.0',
        		'ss_type' 		=> '1',
        		'dev_id' 		=> '1812'
        	]);
    }
}
