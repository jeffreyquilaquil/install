<?php

use Illuminate\Database\Seeder;

use app\Models\Setting;

class SettingTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('h_settings')->delete();

        Setting::create([
        		'st_name' 		=> 'Hazard Notification, Dissemination and Awareness (HaNDA)',
        		'st_alias' 		=> 'Project HaNDA',
        		'st_footer' 	=> '-SENT via HaNDA',
        		'st_about' 		=> '',
        		'st_globe' 		=> '639178162822',
        		'st_smart' 		=> '',
        		'st_facebook' 	=> 'https://www.facebook.com/dost4a.handa/',
        		'st_twitter' 	=> 'https://twitter.com/DRRMRegion4a',
        		'st_google' 	=> '',
        		'st_address' 	=> '',
        		'st_extra' 		=> '',
                'st_earthquake' => 'http://www.phivolcs.dost.gov.ph/html/update_SOEPD/EQLatest.html',
                'st_weather'    => 'http://www1.pagasa.dost.gov.ph/index.php/general-weather/daily-weather-forecast',
                'st_volcano'    => '',
                'st_cyclone'    => '',
                'st_latitude'   => '14.1250273',
                'st_longitude'  => '121.5933434',
                'st_api_key'    => 'AIzaSyCDzewCy_3XM_SKe4IaGDeb087N9wn7CMc',
                'st_username'   => 'dostregion4a',
                'st_password'   => 'd0st4a1116',
        	]);
    }
}
