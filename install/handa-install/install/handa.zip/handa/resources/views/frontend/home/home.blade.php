@extends('layouts.frontend')
	@section('content')
		<br>
		<div class="container-fluid">
			<div class="row" id="embed-map">
				<div class="col-md-7">
					<div class="panel panel-default panel-plain">
						<div class="panel-body no-padding">
							<div id="map"></div>
							@include('frontend.home.legend.legend')
						</div>
					</div>
				</div>
				<div class="col-md-5">
					<div class="panel panel-default panel-plain">
						<div class="panel-heading clearfix">
							<h4 class="panel-title pull-left"><strong>Waterlevel Data</strong></h4>
						</div>
						<div class="panel-body sensor-feeds">
							<table width="100%" id="handa-feeds">
								<thead></thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<br>
		<br>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-3">
					<div class="panel panel-default panel-plain">
						<div class="panel-heading">
							<h5 class="panel-title"><strong>WEATHER UPDATE</strong></h5>
						</div>
						@if(!count($data['latest_wb']))
							<div class="panel-body panel-widget text-justify">
								<i class="fa fa-exclamation-circle text-danger"></i> No updates found.
							</div>
						@else
							<div class="panel-widget">
								<table width="100%" class="side-panel-table">
									<tbody>
									@foreach($data['latest_wb'] as $wb)
										<tr>
											<td><small><p>{!! nl2br($wb->bl_message) !!}</p></small></td>
										</tr>
									@endforeach
									</tbody>
								</table>
							</div>
						@endif
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default panel-plain">
						<div class="panel-heading">
							<h5 class="panel-title"><strong>TROPICAL CYCLONE UPDATE</strong></h5>
						</div>
						<div class="panel-body panel-widget text-justify">
							<div class="text-center"><a href="http://www1.pagasa.dost.gov.ph/index.php/tropical-cyclones/weather-bulletins" target="_blank">PAGASA LINK</a></div>
							<iframe src="http://www1.pagasa.dost.gov.ph/index.php/tropical-cyclones/weather-bulletins#content" frameborder="no" width="100%" scrolling="no" height="775"></iframe>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default panel-plain">
						<div class="panel-heading">
							<h5 class="panel-title"><strong>RAINFALL DATA</strong></h5>
						</div>
						@if(!$rainfall_data)
							<div class="panel-body panel-widget text-justify">
								<i class="fa fa-exclamation-circle text-danger"></i> No data found.
							</div>
						@else
							<div class="panel-widget">
								<table width="100%" class="side-panel-table">
									<tbody>
									@foreach($rainfall_data as $rf)
										@if($rf['sensor_data'] != null)
											<tr>
												<td><small><p>
													@if($rf['sensor_data'] >= 31)
														<img height="35" class="sensor-img" src="{{ asset('images/frontend/legends/rain_torrential.png') }}"> <span>{!! $rf['sensor_address'] !!}</span><br><div>{!! number_format((float)$rf['sensor_data'], 2, '.', '') !!} mm/hr</div>
													@elseif($rf['sensor_data'] >= 16 && $rf['sensor_data'] <= 30)
														<img height="35" class="sensor-img" src="{{ asset('images/frontend/legends/rain_intense.png') }}"> <span>{!! $rf['sensor_address'] !!}</span><br><div>{!! number_format((float)$rf['sensor_data'], 2, '.', '') !!} mm/hr</div>
													@elseif($rf['sensor_data'] >= 7.6 && $rf['sensor_data'] <= 15)
														<img height="35" class="sensor-img" src="{{ asset('images/frontend/legends/rain_heavy.png') }}"> <span>{!! $rf['sensor_address'] !!}</span><br><div>{!! number_format((float)$rf['sensor_data'], 2, '.', '') !!} mm/hr</div>
													@elseif($rf['sensor_data'] >= 2.5 && $rf['sensor_data'] <= 7.5)
														<img height="35" class="sensor-img" src="{{ asset('images/frontend/legends/rain_moderate.png') }}"> <span>{!! $rf['sensor_address'] !!}</span><br><div>{!! number_format((float)$rf['sensor_data'], 2, '.', '') !!} mm/hr</div>
													@elseif($rf['sensor_data'] >= 0.1 && $rf['sensor_data'] <= 2.4)
														<img height="35" class="sensor-img" src="{{ asset('images/frontend/legends/rain_light.png') }}"> <span>{!! $rf['sensor_address'] !!}</span><br><div>{!! number_format((float)$rf['sensor_data'], 2, '.', '') !!} mm/hr</div>
													@else
														<img height="35" class="sensor-img" src="{{ asset('images/frontend/legends/rain_none.png') }}"> <span>{!! $rf['sensor_address'] !!}</span><br><div>{!! number_format((float)$rf['sensor_data'], 2, '.', '') !!} mm/hr</div>
													@endif
												</p></small></td>
											</tr>
										@endif
									@endforeach
									</tbody>
								</table>
							</div>
						@endif
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default panel-plain">
						<div class="panel-heading">
							<h5 class="panel-title"><strong>EARTHQUAKE UPDATE</strong></h5>
						</div>
						@if(!count($data['latest_eq']))
							<div class="panel-body panel-widget text-justify">
								<i class="fa fa-exclamation-circle text-danger"></i> No updates found.
							</div>
						@else
							<div class="panel-widget">
								<table width="100%" class="side-panel-table">
									<tbody>
									@foreach($data['latest_eq'] as $eq)
										<tr>
											<td><small><p>{!! nl2br($eq->bl_message) !!}</p></small></td>
										</tr>
									@endforeach
									</tbody>
								</table>
							</div>
						@endif
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<div class="panel panel-default panel-plain">
						<div class="panel-heading">
							<h5 class="panel-title"><strong>HAZARD MAPS</strong></h5>
						</div>
						<div class="panel-body panel-widget">
							<center>
								<img src="{{ asset('images/frontend/widgets/hazard.jpg') }}" class="img-circle text-center" width="150" height="150">
							<hr/>
							<p class="widget-label">Be aware of the flood, storm surge, tsunami and landslide prone areas from the list of DOST's hazard maps.</p>
							<br>
							<button class="btn btn-default btn-md">View Hazard Maps &raquo;</button>
							</center>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="panel panel-default panel-plain">
						<div class="panel-heading">
							<h5 class="panel-title"><strong>STATIONS</strong></h5>
						</div>
						<div class="panel-body panel-widget">
							<center>
								<img src="{{ asset('images/frontend/widgets/stations.jpg') }}" class="img-circle text-center" width="150" height="150">
							<hr/>
							<p class="widget-label">Monitor rainfall and water level data from DOST’s automated sensors installed near your location.</p>
							<br><br>
							<a href="{{ url('stations') }}" class="btn btn-default btn-md">View Stations &raquo;</a>
							</center>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="panel panel-default panel-plain">
						<div class="panel-heading">
							<h5 class="panel-title"><strong>INQUIRY</strong></h5>
						</div>
						<div class="panel-body panel-widget">
							<center>
								<img src="{{ asset('images/frontend/widgets/inquiry.jpg') }}" class="img-circle text-center" width="150" height="150">
							<hr/>
							<p class="widget-label">Be updated of the latest weather, storm, flood bulletins from PAGASA and earthquake alerts PHIVOLCS.</p>
							<br><br>
							<button class="btn btn-default btn-md">View Inquiry &raquo;</button>
							</center>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script src="https://maps.googleapis.com/maps/api/js?key={{ $key }}"></script>
		<script type="text/javascript" src="{{ asset('extensions/sparklines/jquery.sparkline.min.js') }}"></script>
		<script type="text/javascript" async="true">
		$(document).ready(function() {

			var map ;
			var icons 	= [];
			var popups 	= [];
			var marker 	= [];
			var markers = [];
			var info 	= new google.maps.InfoWindow();
			var shape 	= {
				coord: 	[1, 1, 1, 32, 37, 37, 18, 1],
				type: 	'poly'
			};

			map = new google.maps.Map(document.getElementById('map'), {
				zoom: 9,
				center: {lat: {{ $latitude }}, lng: {{ $longitude }}},
				mapTypeId: google.maps.MapTypeId.ROADMAP
			});


			$.ajax({
				url: "map",
				type: "get",
				success: function(data) {
					$.each($.parseJSON(data), function(i, e) {
							if(e.ss_type == '3' || e.ss_type == '4') {
								icons.push($('#waterlevel').attr('src'));
							}
							else if(e.ss_data['ss_data'] >= 31) {
								icons.push($('#torrential').attr('src'));
							}
							else if((e.ss_data['ss_data'] >= 16) && (e.ss_data['ss_data'] <= 30)) {
								icons.push($('#intense').attr('src'))
							}
							else if((e.ss_data['ss_data'] >= 7.6) && (e.ss_data['ss_data'] <= 15)) {
								icons.push($('#heavy').attr('src'))
							}
							else if((e.ss_data['ss_data'] >= 2.5) && (e.ss_data['ss_data'] <= 7.5)) {
								icons.push($('#moderate').attr('src'))
							}
							else if((e.ss_data['ss_data'] >= 0.1) && (e.ss_data['ss_data'] <= 2.4)) {
								icons.push($('#light').attr('src'))
							}
							else {
								icons.push($('#none').attr('src'));
							}
						if(e.ss_type == '1') {
							popups.push(
								'<div><strong>Automated Rain Gauge</strong></div>'+
								'<div><a class="text-success" href="{!! url("stations/arg/'+e.ss_id+'") !!}" target="_blank"><strong>'+e.ss_address+'</strong></a></div><br>'+
								'<div>as of '+e.ss_data['ss_date']+'</div>'+
								'<div><strong>'+e.ss_data['ss_data']+' mm/hr</strong></div>'+
								'</div>'
							);
						} else if(e.ss_type == '2') {
							popups.push(
								'<div><strong>Automated Weather Station</strong></div>'+
								'<div><a class="text-success" href="{!! url("stations/arg/'+e.ss_id+'") !!}" target="_blank"><strong>'+e.ss_address+'</strong></a></div><br>'+
								'<div>as of '+e.ss_data['ss_date']+'</div>'+
								'<div><strong>'+e.ss_data['ss_data']+' mm/hr</strong></div>'+
								'</div>'
							);
						} else if(e.ss_type == '3') {
							popups.push(
								'<div><strong>Water Level Monitoring Station</strong></div>'+
								'<div><a class="text-success" href="{!! url("stations/wlms/'+e.ss_id+'") !!}" target="_blank"><strong>'+e.ss_address+'</strong></a></div><br>'+
								'<div>as of '+e.ss_data['ss_date']+'</div>'+
								'<div><strong>'+e.ss_data['ss_data']+' m</strong></div>'+
								'</div>'
							);
						} else if(e.ss_type == '4') {
							popups.push(
								'<div><strong>Water Level Monitoring Station with Automated Rain Gauge</strong></div>'+
								'<div><a class="text-success" href="{!! url("stations/wlms/'+e.ss_id+'") !!}" target="_blank"><strong>'+e.ss_address+'</strong></a></div><br>'+
								'<div>as of '+e.ss_data['ss_date']+'</div>'+
								'<div><strong>'+e.ss_data['ss_data']+' m</strong></div>'+
								'</div>'
							);
						}

						marker 	= new google.maps.Marker({
							position: new google.maps.LatLng(e.ss_latitude, e.ss_longitude),
							map: map,
							icon: new google.maps.MarkerImage(icons[i], new google.maps.Size(32, 37), new google.maps.Point(0,0), new google.maps.Point(0, 32)),
							shape: shape,
							category: e.ss_type
						});
						markers.push(marker);

						google.maps.event.addListener(marker, 'mouseover', (function(marker, i) {
							return function() {
								info.setContent(popups[i]);
								info.open(map, marker);
							}
						})(marker, i));
					});
				}
			});

			$.ajax({
				url: "eq_feeds",
				type: "get",
				success:function(data) {
					console.log(data);
				}

			});

			$.ajax({
				url: "sensor_feeds",
				type: "get",
				success: function(data) {
					$.each($.parseJSON(data), function(i, e) {
						if(e.ss_type == 3 || e.ss_type == 4) {
							$('#handa-feeds tbody').append(
								'<tr>'+
								'<td>'+e.ss_address+': <span class="wlmsparkline">'+e.d_waterlevel+'</span></td>'+
								'/tr>'
							);
						}
					});
				}
			}).done(function() {
				$('.argsparkline').sparkline('html', {width: 75});
				$('.wlmsparkline').sparkline('html', {width: 75})
			});

			var legend = document.getElementById('legend');
			var filter = document.getElementById('filter');
			map.controls[google.maps.ControlPosition.TOP_RIGHT].push(legend);
			map.controls[google.maps.ControlPosition.RIGHT].push(filter);

			$('#sensor-filter').change(function() {
				var selected = $('#sensor-filter').find(":selected").val();
				for (var i = 0; i < markers.length; i++) {
					marker = markers[i];
					if(marker.category == selected || selected.length === 0) {
						marker.setVisible(true);
					}
					else {
						marker.setVisible(false);
					}
				}
			});
		});
		</script>
	@stop