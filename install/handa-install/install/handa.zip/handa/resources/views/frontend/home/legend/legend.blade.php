<div id="legend">
	<div class="panel panel-default panel-plain">
		<div class="panel-heading">
			<h4 class="panel-title">LEGEND</h4>
		</div>
		<div class="panel-body map">
			<table width="100%" class="map-legend-table">
				<tr>
					<td><img id="torrential" height="25" src="{{ asset('images/frontend/legends/rain_torrential.png') }}"></td>
					<td>
						<div><strong>TORRENTIAL</strong></div>
						<div>More than 30mm rain</div>
					</td>
				</tr>
				<tr>
					<td><img id="intense" height="25" src="{{ asset('images/frontend/legends/rain_intense.png') }}"></td>
					<td>
						<div><strong>INTENSE</strong></div>
						<div>15 - 30mm rain</div>
					</td>
				</tr>
				<tr>
					<td><img id="heavy" height="25" src="{{ asset('images/frontend/legends/rain_heavy.png') }}"></td>
					<td>
						<div><strong>HEAVY</strong></div>
						<div>7.5 - 15mm rain</div>
					</td>
				</tr>
				<tr>
					<td><img id="moderate" height="25" src="{{ asset('images/frontend/legends/rain_moderate.png') }}"></td>
					<td>
						<div><strong>MODERATE</strong></div>
						<div>2.5 - 7.5mm rain</div>
					</td>
				</tr>
				<tr>
					<td><img id="light" height="25" src="{{ asset('images/frontend/legends/rain_light.png') }}"></td>
					<td>
						<div><strong>LIGHT</strong></div>
						<div>Less than 2.5mm rain</div>
					</td>
				</tr>
				<tr>
					<td><img id="none" height="25" src="{{ asset('images/frontend/legends/rain_none.png') }}"></td>
					<td>
						<div><strong>NO RAIN</strong></div>
						<div>0mm rain</div>
					</td>
				</tr>
				<tr>
					<td><img id="waterlevel" height="25" src="{{ asset('images/frontend/legends/water_level.png') }}"></td>
					<td>
						<div><strong>WATER LEVEL STATION</strong></div>
					</td>
				</tr>
			</table>
		</div>
	</div>
</div>

<div id="filter">
	<div class="panel panel-default panel-plain">
		<div class="panel-heading">
			<h4 class="panel-title">FILTER SENSORS</h4>
		</div>
		<div class="panel-body filter">
			<select class="form-control input-sm" id="sensor-filter">
				<option value="" selected>Select option</option>
				<option value="1">Automated Rain Gauge</option>
				<option value="2">Automated Weather Station</option>
				<option value="3">Water level Monitorin Station</option>
				<option value="4">Water Level Monitoring Station with Automated Rain Gauge</option>
			</select>
		</div>
	</div>
</div>