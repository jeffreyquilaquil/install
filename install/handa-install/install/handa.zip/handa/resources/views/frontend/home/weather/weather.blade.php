<div class="container-fluid">
	<div class="row">
		<div class="col-md-2">
			<div class="panel panel-default panel-plain">
				<div class="panel-heading clearfix">
					<h4 class="panel-title pull-left"><strong>Torrential</strong></h4>
					<h4 class="panel-title pull-right"><img height="25" src="{{ asset('images/frontend/legends/rain_torrential.png') }}"></h4>
				</div>
				<div class="panel-body weather-widgets">
				@foreach($rainfall_data as $rainfall)
					@if($rainfall['sensor_data'] >= 31)
						<div class="nowrap">{{ $rainfall['sensor_address'] }}</div>
					@endif
				@endforeach
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default panel-plain">
				<div class="panel-heading clearfix">
					<h4 class="panel-title pull-left"><strong>Intense</strong></h4>
					<h4 class="panel-title pull-right"><img height="25" src="{{ asset('images/frontend/legends/rain_intense.png') }}"></h4>
				</div>
				<div class="panel-body weather-widgets">
				@foreach($rainfall_data as $rainfall)
					@if($rainfall['sensor_data'] >= 16 && $rainfall['sensor_data'] <= 30)
						<div class="nowrap">{{ $rainfall['sensor_address'] }}</div>
					@endif
				@endforeach
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default panel-plain">
				<div class="panel-heading clearfix">
					<h4 class="panel-title pull-left"><strong>Heavy</strong></h4>
					<h4 class="panel-title pull-right"><img height="25" src="{{ asset('images/frontend/legends/rain_heavy.png') }}"></h4>
				</div>
				<div class="panel-body weather-widgets">
				@foreach($rainfall_data as $rainfall)
					@if($rainfall['sensor_data'] >= 7.6 && $rainfall['sensor_data'] <= 15)
						<div class="nowrap">{{ $rainfall['sensor_address'] }}</div>
					@endif
				@endforeach
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default panel-plain">
				<div class="panel-heading clearfix">
					<h4 class="panel-title pull-left"><strong>Moderate</strong></h4>
					<h4 class="panel-title pull-right"><img height="25" src="{{ asset('images/frontend/legends/rain_moderate.png') }}"></h4>
				</div>
				<div class="panel-body weather-widgets">
				@foreach($rainfall_data as $rainfall)
					@if($rainfall['sensor_data'] >= 2.5 && $rainfall['sensor_data'] <= 7.5)
						<div class="nowrap">{{ $rainfall['sensor_address'] }}</div>
					@endif
				@endforeach
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default panel-plain">
				<div class="panel-heading clearfix">
					<h4 class="panel-title pull-left"><strong>Light</strong></h4>
					<h4 class="panel-title pull-right"><img height="25" src="{{ asset('images/frontend/legends/rain_light.png') }}"></h4>
				</div>
				<div class="panel-body weather-widgets">
				@foreach($rainfall_data as $rainfall)
					@if($rainfall['sensor_data'] >= 0.1 && $rainfall['sensor_data'] <= 2.4)
						<div class="nowrap">{{ $rainfall['sensor_address'] }}</div>
					@endif
				@endforeach
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default panel-plain">
				<div class="panel-heading clearfix">
					<h4 class="panel-title pull-left"><strong>No Rain</strong></h4>
					<h4 class="panel-title pull-right"><img height="25" src="{{ asset('images/frontend/legends/rain_none.png') }}"></h4>
				</div>
				<div class="panel-body weather-widgets">
				@foreach($rainfall_data as $rainfall)
					@if($rainfall['sensor_data'] >= 0)
						<div class="nowrap">{{ $rainfall['sensor_address'] }}</div>
					@endif
				@endforeach
				</div>
			</div>
		</div>
	</div>
</div>