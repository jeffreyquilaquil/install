@extends('layouts.frontend')
	@section('content')
		<link rel="stylesheet" type="text/css" href="{{ asset('extensions/morris/morris.css') }}">
		<link rel="stylesheet" href="{{ asset('extensions/date-picker/bootstrap-datepicker3.css') }}" type="text/css">

		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading clearfix">
							<h4 class="custom-header-title pull-left"><strong>Automated Weather Station</strong></h4>
							<h4 class="custom-header-title2 pull-right"><span class="fa fa-map-marker text-danger"></span> <span id="address">{{ $aws->ss_address }}</span></h4>
						</div>
						<div class="panel-body panel-fixed-height sensor-content">
							<br>
							<div class="row">
								<div class="col-md-9">
									<div id="sensor-map"></div>
									<div id="latitude" class="hidden">{{ $aws->ss_latitude }}</div>
									<div id="longitude" class="hidden">{{ $aws->ss_longitude }}</div>
								</div>
								<div class="col-md-3">
									<div class="panel panel-default panel-plain">
										<div class="panel-heading">
											<div><h4 class="panel-title"><strong>Readings</strong></h4></div>
											<div><small>as of {{ Carbon\Carbon::parse($aws_latest->date_time)->format('F d, Y h:i A') }}</small></div>
										</div>
										<div class="panel-body no-padding sensor-body">
											<table width="100%" class="sensor-table">
												<tr>
													<td>
														<img src="{{ asset('images/frontend/sensors/wind_speed.jpg') }}" class="float-img"> 
														<strong>Wind Speed</strong>
														<div><small>{{ $aws_latest->d_wind_speed }} mm</small></div>
													</td>
												</tr>
												<tr>
													<td>
														<img src="{{ asset('images/frontend/sensors/rainfall.jpg') }}" class="float-img"> 
														<strong>Rainfall Amount</strong>
														<div><small>{{ $aws_latest->d_rain_value }} mm</small></div>
													</td>
												</tr>
												<tr>
													<td>
														<img src="{{ asset('images/frontend/sensors/rain_intensity.jpg') }}" class="float-img"> 
														<strong>Rainfall Intensity</strong>
														<div><small>{{ $aws_latest->d_rain_intensity }} mm</small></div>
													</td>
												</tr>
												<tr>
													<td>
														<img src="{{ asset('images/frontend/sensors/weather_temp.png') }}" class="float-img"> 
														<strong>Air Temperature</strong>
														<div><small>{{ $aws_latest->d_rain_temperature }} mm</small></div>
													</td>
												</tr>
												<tr>
													<td>
														<img src="{{ asset('images/frontend/sensors/wind_direction.jpg') }}" class="float-img"> 
														<strong>Wind Direction</strong>
														<div><small>{{ $aws_latest->d_wind_direction }} mm</small></div>
													</td>
												</tr>
												<tr>
													<td>
														<img src="{{ asset('images/frontend/sensors/humidity.jpg') }}" class="float-img"> 
														<strong>Air Humidity</strong>
														<div><small>{{ $aws_latest->d_air_humidity }} mm</small></div>
													</td>
												</tr>
											</table>
										</div>
									</div>
								</div>
							</div>
							<br>
							<div class="row">
								<div class="col-md-12">
									Data Source: <strong><a class="text-success" href="http://fmon.asti.dost.gov.ph/weather/predict/" target="_blank">PREDICT</a></strong> (Advanced Science and Technology Institute)
								</div>
							</div>
							<br>
							<div class="row">
								<div class="col-md-12">
									<div class="panel panel-default panel-plain">
										<div class="panel-heading">
											<h4 class="panel-title"><strong>12 HOUR DATA</strong></h4>
										</div>
										<div class="panel-body">
											<div id="12-hour-data"></div>
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="panel panel-default panel-plain">
										<div class="panel-heading">
											<h4 class="panel-title"><strong>PREVIOUS DATA</strong></h4>
										</div>
										<div class="panel-body">
											{!! Form::open(['url' => 'stations/aws/'.$id, 'class' => 'form-inline pull-right']) !!}
											<div class="input-group">
												<span class="input-group-addon">From</span>
												{!! Form::text('date_from', $date_from, ['class' => 'form-control input-sm filter', 'readonly']) !!}
											</div>
											<div class="input-group">
												<span class="input-group-addon">To</span>
												{!! Form::text('date_to', $date_to, ['class' => 'form-control input-sm filter', 'readonly']) !!}
											</div>
											<div class="form-group">
												{!! Form::submit('Submit', ['class' => 'btn btn-primary btn-sm']) !!}
											</div>
											{!! Form::close() !!}
										</div>
										@if(!count($aws_data))
											<div class="panel-body">
												<h4 class="text-danger"><strong><i class="fa fa-info-circle"></i> No data found.</strong></h4>
											</div>
										@else
										<table class="table table-hover custom-table">
											<thead>
												<tr>
													<th>DateTime</th>
													<th class="text-center">Wind Speed</th>
													<th class="text-center">Rain Amount</th>
													<th class="text-center">Rain Intensity</th>
													<th class="text-center">Air Temperature</th>
													<th class="text-center">Air Pressure</th>
													<th class="text-center">Wind Direction</th>
													<th class="text-center">Air Humidity</th>
												</tr>
											</thead>
											<tbody>
											@foreach($aws_data as $aws)
												<tr>
													<td>{{ Carbon\Carbon::parse($aws->d_date_time_read)->format('F d, Y h:i A') }} </td>
													<td class="text-center">{{ $aws->d_wind_speed }}</td>
													<td class="text-center">{{ $aws->d_rain_value }} mm</td>
													<td class="text-center">{{ $aws->d_rain_intensity }}</td>
													<td class="text-center">{{ $aws->d_air_temperature }}</td>
													<td class="text-center">{{ $aws->d_air_pressure }}</td>
													<td class="text-center">{{ $aws->d_wind_direction }}</td>
													<td class="text-center">{{ $aws->d_air_humidity }}</td>
												</tr>
											@endforeach	
											</tbody>
										</table>
										<div class="panel-footer custom-footer">
											@if($aws_data->render())
											<div class="text-center">
												@if(Input::get('date_from') == null && Input::get('date_to') == null)
													{!! $aws_data->render() !!}
												@else
													{!! $aws_data->appends(Request::only('date_from', 'date_to'))->render() !!}
												@endif
											</div>
											@endif
										</div>
										@endif
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<script src="https://maps.googleapis.com/maps/api/js?key={{ $key }}"></script>
		<script type="text/javascript" src="{{ asset('extensions/date-picker/bootstrap-datepicker.js') }}"></script>
		<script type="text/javascript" src="{{ asset('extensions/morris/raphael.min.js') }}"></script>
		<script type="text/javascript" src="{{ asset('extensions/morris/morris.min.js')}}"></script>
		<script type="text/javascript" src="{{ asset('js/arg.js') }}"></script>
		<script type="text/javascript">

			$('.filter').datepicker({
				format: 'MM dd, yyyy',
				orientation: 'top'
			});

			$.ajax({
				url: '{{ url("stations/chart_data/".Request::segment(3)) }}',
				type: 'get',
				dataType: "json",
				success: function(data) {
					console.log(data);
					Morris.Line({
					  element: '12-hour-data',
					  data: data,
					  xkey: 'd_date_time_read',
					  ykeys: ['d_rain_value'],
					  labels: ['Rainfall Amount (mm)'],
					  hideHover: 'auto'
					});
				}
			});
		</script>
	@stop