@include('layouts.backend_header')
@yield('content')
@include('layouts.backend_footer')