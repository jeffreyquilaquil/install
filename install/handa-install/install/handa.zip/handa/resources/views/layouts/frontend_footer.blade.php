	<div class="container">
		<div class="row">
			<footer>
				<div class="col-md-6">
					<div class="frontend-footer">
						<a href="http://www.ndrrmc.gov.ph/" target="_blank"><img class="img-circle" data-src="{{ asset('images/frontend/footer/phivolcs_logo_small.png') }}" src="{{ asset('images/frontend/footer/ndrrmc_logo_small.png') }}" alt="NDRRMC" title="NDRRMC"></a>
						<a href="https://kidlat.pagasa.dost.gov.ph/" target="_blank"><img class="img-circle" data-src="{{ asset('images/frontend/footer/phivolcs_logo_small.png') }}" src="{{ asset('images/frontend/footer/pagasa_logo_small.png') }}" alt="PAGASA" title="PAGASA"></a>
						<a href="http://www.mgbcalabarzon.com/" target="_blank"><img class="img-circle" data-src="{{ asset('images/frontend/footer/phivolcs_logo_small.png') }}" src="{{ asset('images/frontend/footer/mgb_logo_small.png') }}" alt="DENR-MGB" title="DENR-MGB"></a>
						<a href="http://www.phivolcs.dost.gov.ph/" target="_blank"><img class="img-circle" data-src="{{ asset('images/frontend/footer/phivolcs_logo_small.png') }}" src="{{ asset('images/frontend/footer/phivolcs_logo_small.png') }}" alt="PHIVOLCS" title="PHIVOLCS"></a>
					</div>
				</div>
				<div class="col-md-6">
					<div class="frontend-footer">
						<div class="pull-right">&copy; {{ date('Y') }} Project HaNDA. All Rights Reserved</div>
						<div class="pull-right"><a class="text-success" href="http://region4a.dost.gov.ph/">Developed by Department of Science and Technology - Region 4A · MIS Unit</a></div>
					</div>
				</div>
			</footer>	
		</div>
	</div>
</body>
</html>