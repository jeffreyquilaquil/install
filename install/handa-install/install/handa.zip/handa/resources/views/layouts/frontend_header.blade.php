<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>{{ $data['page'] }} | HaNDA</title>
	<link rel="icon" href="{{ asset('images/frontend/header/handa.ico') }}" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/bootstrap/css/bootstrap.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/font-awesome/css/font-awesome.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('css/frontend.css') }}">
	<script type="text/javascript" src="{{ asset('extensions/jquery/jquery.min.js') }}"></script>
	<script type="text/javascript" src="{{ asset('extensions/bootstrap/js/bootstrap.min.js') }}"></script>
</head>
<body>
	<nav class="navbar navbar-default navbar-custom navbar-static-top">
		<div class="container custom-container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
	      		</button>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li {{(Request::is('/') ? 'class=active' : '')}}><a href="{{ url('/') }}"><h3>Home</h3></a></li>
					<li {{(Request::is('bulletins') || (Request::is('bulletins/'.Request::segment(2))) ? 'class=active' : '')}}><a href="{{ url('bulletins') }}"><h3>Bulletins</h3></a></li>
					<li {{(Request::is('stations') || (Request::is('stations/arg/'.Request::segment(3))) || (Request::is('stations/wlms/'.Request::segment(3))) || (Request::is('stations/aws/'.Request::segment(3))) || (Request::is('stations/wlmsr/'.Request::segment(3))) ? 'class=active' : '')}}><a href="{{ url('stations') }}"><h3>Stations</h3></a></li>
					<li {{(Request::is('maps') ? 'class=active' : '')}}><a href="{{ url('maps') }}"><h3>Maps</h3></a></li>
				</ul>
			</div>
		</div>
	</nav>
<div class="home-banner"></div>
<br><br>