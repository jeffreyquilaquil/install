-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 19, 2017 at 12:49 PM
-- Server version: 5.6.35-1+deb.sury.org~xenial+0.1
-- PHP Version: 5.6.30-7+deb.sury.org~xenial+1

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `handa_db2`
--

--
-- Dumping data for table `h_maps`
--

INSERT INTO `h_maps` (`m_id`, `m_name`, `m_type`, `m_path`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Active Faults', 0, '15a.jpg', 0, '2016-01-19 09:01:27', '2016-01-19 09:01:27'),
(2, 'Climate Map', 0, '3a.jpg', 0, '2016-01-19 09:02:18', '2016-01-19 09:02:18'),
(3, 'Earthquake Induced', 0, '12a.jpg', 0, '2016-01-19 09:03:57', '2016-01-19 09:03:57'),
(4, 'Earthquake Triggered Landslide', 0, '16a.jpg', 0, '2016-01-19 09:04:47', '2016-01-19 09:04:47'),
(5, 'Flood Hazard', 0, '8a.jpg', 0, '2016-01-19 09:05:33', '2016-01-19 09:05:33'),
(6, 'Flooded Area', 0, '1a.jpg', 0, '2016-01-19 09:06:01', '2016-01-19 09:06:01'),
(7, 'Ground Rapture', 0, '4a.jpg', 0, '2016-01-19 09:06:30', '2016-01-19 09:06:30'),
(8, 'Ground Shaking', 0, '2a.jpg', 0, '2016-01-19 09:06:49', '2016-01-19 09:06:49'),
(9, 'Liquefaction Hazard', 0, '6a.jpg', 0, '2016-01-19 09:07:29', '2016-01-19 09:07:29'),
(10, 'Protected Areas', 0, '11a.jpg', 0, '2016-01-19 09:08:05', '2016-01-19 09:08:05'),
(11, 'Rain Induced Landslide', 0, '7a.jpg', 0, '2016-01-19 09:08:42', '2016-01-19 09:08:42'),
(12, 'Slope', 0, '10a.jpg', 0, '2016-01-19 09:09:03', '2016-01-19 09:09:03'),
(13, 'Tsunami - Batangas', 0, '17a.jpg', 0, '2016-01-19 09:09:33', '2016-01-19 09:09:33'),
(14, 'Tsunami - Cavite', 0, '18a.jpg', 0, '2016-01-19 09:09:56', '2016-01-19 09:09:56'),
(15, 'Tsunami - Quezon', 0, '19a.jpg', 0, '2016-01-19 09:10:17', '2016-01-19 09:10:17'),
(16, 'Volcanic Hazard', 0, '5a.jpg', 0, '2016-01-19 09:10:37', '2016-01-19 09:10:37'),
(17, 'Water Resource', 0, '9a.jpg', 0, '2016-01-19 09:11:21', '2016-01-19 09:11:21');
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
