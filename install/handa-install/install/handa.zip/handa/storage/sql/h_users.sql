-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 19, 2017 at 12:50 PM
-- Server version: 5.6.35-1+deb.sury.org~xenial+0.1
-- PHP Version: 5.6.30-7+deb.sury.org~xenial+1

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `handa_db2`
--

--
-- Dumping data for table `h_users`
--

INSERT INTO `h_users` (`u_id`, `u_username`, `u_password`, `u_fname`, `u_mname`, `u_lname`, `u_number`, `is_updated`, `is_admin`, `is_active`, `remember_token`, `created_at`, `updated_at`) VALUES
(2, 'kevs', '$2y$10$yWc8jfPZCanxB/jM8ZuXrOnHRZ.fTlVDnkjGBqXw1CFfk28CSM5/G', 'Kevin', 'Brian', 'Paris', '639069741897', 1, 1, 1, 'bJEkk2ghjAYc4IqR0KmCrUe6BjCHqr6NeQcN5Ht4AzCMFb3zLQX94HjESO01', '2015-12-16 07:15:35', '2016-06-23 05:33:49'),
(3, 'kiecoomonster', '$2y$10$QnaZn95gS//GLO63eV.7peg/pAlm.dF0TwEf34JI9F31vnPGevCoW', 'Francisco', 'R.', 'Barquilla', '639771372442', 1, 1, 1, 'a9JTAiYNzjzhyCVdIpO9p3KrjvKQxZ8wPQ3kbm29hwgd7kVVKf21ObHZOfOI', '2015-12-16 07:27:30', '2016-04-05 00:23:21'),
(6, 'Mariel', '$2y$10$x6RY.EOopqXOINS9iq8M8.CShXVRV45GUz23EZzvSSF4t7t09BgNa', 'Mariel', 'V', 'Camposo', '639267427154', 1, 1, 1, 'u43seSwczaKpFHeWohImXJJP6AQC1KGBaUjnsuxhMYLoYhXlYI2grkmYziMT', '2017-02-15 01:41:39', '2017-02-15 01:41:39'),
(7, 'claudezzzzz', '$2y$10$uqlhVJ1lHfHyRQoU4qqrcOelANKq3N2FxBWT9ktKJlqrysBa/hctW', 'Jene Claude', 'D', 'Dizon', '639176217400', 1, 1, 1, 'qySNkKhnnrYSl8Lur3eLmpowdDTDCsT1ycEq7en8vNflGXeQch1VODSb4wZe', '2017-04-05 07:46:02', '2017-04-10 23:57:09'),
(9, 'jjgcalibo', '$2y$10$WLnZFFW84cS6IKdB1Alw4OqDTGT5bxW14Il.lcU5RfS2SP7LKy4WO', 'John Julius', 'G', 'Calibo', '639398207073', 1, 1, 1, 'kg3UnyHJqjFhmLoliOnJq8bcgAFYUfmTzlzMSpL6tvkXINL6mAlDuiv1sErn', '2017-04-11 08:26:15', '2017-04-11 08:26:15');
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
