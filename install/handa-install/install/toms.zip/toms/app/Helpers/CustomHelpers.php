<?php

use Carbon\Carbon;
use App\Models\Travel;
use App\Models\Official;

function format_middle_name($input)
{
	return substr($input, 0, 1).".";
}

function format_date($date)
{
	return Carbon::parse($date)->format('F d, Y');
}

function get_notifications()
{
	$notifications 				= array();
	$notifications['pending'] 	= '';
	$notifications['travel'] 	= Travel::whereHas('passengers', function($a) {
									$a->where('to_travel_passengers.u_id', '=', Auth::user()->u_id)->where('is_read', '=', '0');
								})->where('is_active', '=', '1')->count();
	$official 					= Official::where('u_id', '=', Auth::user()->u_id)->first();
	if($official) {
		$signatory              = Official::where('u_id', '=', Auth::user()->u_id)->pluck('to_approval');
        if($signatory == 0) {
            $notifications['pending'] = Travel::where('u_id', '!=', Auth::user()->u_id)->where('to_recommending', '=', '0')->where('is_active', '=', '1')->whereHas('user', function($a) {
                                $a->whereHas('officials', function($b) {
                                    $b->where('u_id', '=', Auth::user()->u_id);
                                });
                            })->count();
        }
        else {
            $notifications['pending'] = Travel::where('u_id', '!=', Auth::user()->u_id)->where('to_approval', '=', '0')->where('is_active', '=', '1')->whereHas('user', function($a) {
                                $a->whereHas('officials', function($b) {
                                    $b->where('u_id', '=', Auth::user()->u_id);
                                });
                            })->count();
        }
	}
	$notifications['total'] 	= $notifications['travel'] + $notifications['pending'];
	return $notifications;
}

function get_group_heads($id)
{
	$group_heads 	= App\Models\Official::where('u_id', '=', $id)->first();
	if($group_heads) {
		return true;
	}
}

function get_date_diff($date)
{
	$created_at 	= Carbon::parse($date);
	$seconds 		= $created_at->diffInSeconds(Carbon::now());
	$minutes 		= $created_at->diffInMinutes(Carbon::now());
	$days 			= $created_at->diffInDays(Carbon::now());

	if($minutes == 0) {
		echo Carbon::now()->subSeconds($seconds)->diffForHumans();
	}
	elseif($days == 0) {
		echo Carbon::now()->subMinutes($minutes)->diffForHumans();
	}
	else {
		echo Carbon::now()->subDays($days)->diffForHumans();
	}
}

function create_initials($first, $middle, $last)
{
	$full_name 	= $first." ".$middle." ".$last;
	$words 		= explode(" ", $full_name);
	$acronym 	= "";
	foreach($words as $word) {
		$acronym .= $word[0];
	}
	return $acronym;
}

function get_user_role($role)
{
	return App\Models\Role::where('r_name', '=', $role)->pluck('r_id');
}