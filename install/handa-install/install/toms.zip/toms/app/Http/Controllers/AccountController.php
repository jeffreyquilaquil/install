<?php

namespace App\Http\Controllers;

use View;
use Session;
use App\Models\User;
use App\Models\Role;
use App\Models\Region;
use App\Http\Requests\AccountValidation;

class AccountController extends Controller
{
    public function __construct()
    {
        $data = array(
            'page'  => 'Users'
        );
        View::share('data', $data);
    }

    public function index_admin()
    {
        $admins     = User::where('r_id', '=', '2')->orderBy('rg_id')->orderBy('r_id')->Paginate(15);
        return view('accounts.accounts', compact('admins'));
    }

    public function add()
    {
        $id         = 0;
        $option     = 'New';
        $user       = new User;
        $regions    = Region::lists('rg_name', 'rg_id');
        $roles      = Role::lists('r_name', 'r_id');
        return view('accounts.form', compact('regions', 'id', 'user', 'roles', 'option'));
    }

    public function edit($id)
    {
        $option     = 'Update';
        $user       = User::find($id);
        $regions    = Region::lists('rg_name', 'rg_id');
        $roles      = Role::lists('r_name', 'r_id');
        return view('accounts.form', compact('regions', 'id', 'user', 'roles', 'option')); 
    }

    public function save(AccountValidation $request, $id)
    {
        if($id == 0) {
            $user       = User::create($request->all());
            Session::put('alert_type', 'alert-success');
            return redirect('administrators')->with('message', 'New user successfully added.');
        }
        else {
            $user       = User::find($id);
            $user->update($request->all());
            Session::put('alert_type', 'alert-info');
            return redirect('administrators')->with('message', 'User successfully updated.');
        }
    }
}