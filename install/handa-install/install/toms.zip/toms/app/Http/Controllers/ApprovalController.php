<?php

namespace App\Http\Controllers;

use Auth;
use View;
use Input;
use Session;
use App\Models\User;
use App\Models\Travel;
use App\Models\Comment;
use App\Models\Expense;
use App\Models\Official;
use App\Models\TravelFundExpense;
use Illuminate\Pagination\Paginator;

class ApprovalController extends Controller
{
    public function __construct()
    {
        $data = array(
            'page'  => 'Approval'
        );
        View::share('data', $data);
    }

    public function index()
    {
        $official               = Official::where('u_id', '=', Auth::user()->u_id)->pluck('to_approval');

        if($official == 0) {
            $travels            = Travel::where('u_id', '!=', Auth::user()->u_id)->where('to_recommending', '=', '0')->where('is_active', '=', '1')->whereHas('user', function($a) {
                                $a->whereHas('officials', function($b) {
                                    $b->where('u_id', '=', Auth::user()->u_id);
                                });
                            })->Paginate(15);
        }
        else {
            $travels            = Travel::where('u_id', '!=', Auth::user()->u_id)->where('to_approval', '=', '0')->where('is_active', '=', '1')->whereHas('user', function($a) {
                                $a->whereHas('officials', function($b) {
                                    $b->where('u_id', '=', Auth::user()->u_id);
                                });
                            })->Paginate(15);
        }

        return view('approval.approval', compact('travels'));
    }

    public function view($id)
    {
        $option             = 'View';
        $expenses           = Expense::all();
        $travel             = Travel::find($id);
        $funds              = TravelFundExpense::where('t_id', '=', $id)->lists('f_id')->toArray();
        return view('approval.view', compact('id', 'travel', 'option', 'funds', 'expenses'));
    }

    public function save($id)
    {
        $travel                     = Travel::find($id);

        if(Input::get('tc_comment') != "") {
            $comment                = new Comment;
            $comment->t_id          = $travel->t_id;
            $comment->u_id          = Auth::user()->u_id;
            $comment->tc_comment    = Input::get('tc_comment');
            $comment->save();
        }

        $approval                   = Official::where('u_id', '=', Auth::user()->u_id)->where('g_id', '=', $travel->user->group->g_id)->where('r_id', '=', $travel->user->r_id)->where('to_approval', '=', '1')->first();
        
        if(Input::get('action') == 1) {
            if($approval) {
                $travel->to_approval        = 1;
            }
            else {
                $travel->to_recommending    = 1;
            }
            $travel->update();
            Session::put('alert_type', 'alert-success');
            return redirect('approval')->with('message', 'Travel Order approved.');
        }
        else {
            if($approval) {
                $travel->to_approval        = 2;
            }
            else {
                $travel->to_recommending    = 2;
            }
            $travel->update();
            Session::put('alert_type', 'alert-danger');
            return redirect('approval')->with('message', 'Travel Order disapproved.');
        }

    }
}
