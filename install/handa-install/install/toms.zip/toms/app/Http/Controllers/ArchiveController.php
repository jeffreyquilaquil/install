<?php

namespace App\Http\Controllers;

use Auth;
use View;
use Input;
use Session;
use App\Models\User;
use App\Models\Travel;
class ArchiveController extends Controller
{
    public function __construct()
    {      
        $data = array(
            'page'  => 'Archive'
        );
        View::share('data', $data);
    }

    public function index()
    {
        $archives     = User::where('r_id', '>', '2')->orderBy('u_lname')->Paginate(15);
        return view('archive.archive', compact('archives'));
    }

    public function search()
    {
        $search     = Input::get('search');
        $archives   = User::where('r_id', '>', '2')
                            ->where(function($query) use ($search) {
                                $query->where('u_fname', 'like', "%$search%")
                                      ->orWhere('u_mname', 'like', "%$search%")
                                      ->orWhere('u_lname', 'like', "%$search%");
                            })->orWhereHas('group', function($q) use($search) {
                                $q->where('g_name', 'like', "%$search%");
                            })->Paginate(15);
        return view('archive.archive', compact('archives'));
    }

    public function view($id)
    {
        $user       = User::find($id);
        $travels    = Travel::where('u_id', '=', $id)->latest('t_id')->Paginate(15);
        return view('archive.view', compact('travels', 'user'));
    }
}
