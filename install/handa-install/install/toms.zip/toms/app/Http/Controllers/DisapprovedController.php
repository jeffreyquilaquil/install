<?php

namespace App\Http\Controllers;

use Auth;
use View;
use Input;
use Session;
use App\Models\User;
use App\Models\Travel;
use App\Models\Comment;
use App\Models\Official;

class DisapprovedController extends Controller
{
    public function __construct()
    {
        $data = array(
            'page'  => 'Disapproved'
        );
        View::share('data', $data);
    }

    public function index()
    {
        $official               = Official::where('u_id', '=', Auth::user()->u_id)->pluck('to_approval');

        if($official == 0) {
            $travels            = Travel::where('u_id', '!=', Auth::user()->u_id)->where('to_recommending', '=', '2')->where('is_active', '=', '1')->whereHas('user', function($a) {
                                $a->whereHas('officials', function($b) {
                                    $b->where('u_id', '=', Auth::user()->u_id);
                                });
                            })->Paginate(15);
        }
        else {
            $travels            = Travel::where('u_id', '!=', Auth::user()->u_id)->where('to_approval', '=', '2')->where('is_active', '=', '1')->whereHas('user', function($a) {
                                $a->whereHas('officials', function($b) {
                                    $b->where('u_id', '=', Auth::user()->u_id);
                                });
                            })->Paginate(15);
        }
        
        return view('disapproved.disapproved', compact('travels'));
    }

    public function view($id)
    {
        $option             = 'View';
        $travel             = Travel::find($id);
        $comments           = Comment::where('t_id', '=', $id)->get();
        return view('disapproved.view', compact('id', 'travel', 'option', 'comments'));
    }
}
