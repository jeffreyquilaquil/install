<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use View;
use Session;
use App\Models\User;
use App\Models\Group;
use App\Models\Division;
use App\Http\Requests\GroupValidation;

class GroupController extends Controller
{
    public function __construct()
    {
        $data = array(
            'page'  => 'Groups'
        );
        View::share('data', $data);
    }

    public function index()
    {
        $groups         = Group::Paginate(15);
        return view('groups.groups', compact('groups'));
    }

    public function add()
    {
        $id             = 0;
        $option         = 'New';
        $group          = new Group;
        $division       = Division::lists('d_name', 'd_id');
        $users          = User::select('u_id', DB::raw('CONCAT(u_lname, ", ", u_fname) as full_name'))->where('r_id', '>=', '3')->where('r_id', '<=', '5')->lists('full_name', 'u_id');
        return view('groups.form', compact('id', 'group', 'option', 'users', 'division'));
    }

    public function edit($id)
    {
        $option         = 'Update';
        $group          = Group::find($id);
        $division       = Division::lists('d_name', 'd_id');
        $users          = User::select('u_id', DB::raw('CONCAT(u_lname, ", ", u_fname) as full_name'))->where('r_id', '>', '2')->orderBy('u_lname')->lists('full_name', 'u_id');
        return view('groups.form', compact('id', 'group', 'option', 'users', 'division'));
    }

    public function view($id)
    {
        $option         = 'View';
        $group          = Group::find($id);
        $division       = Division::lists('d_name', 'd_id');
        $users          = User::select('u_id', DB::raw('CONCAT(u_lname, ", ", u_fname) as full_name'))->where('r_id', '>=', '3')->where('r_id', '<=', '5')->lists('full_name', 'u_id');
        return view('groups.form', compact('id', 'group', 'option', 'users', 'division'));
    }

    public function save(GroupValidation $request, $id)
    {
        if($id == 0) {
            $group      = Group::create($request->all());
            Session::put('alert_type', 'alert-success');
            return redirect('groups')->with('message', 'New group successfully added.');
        }
        else {
            $group      = Group::find($id);
            $group->update($request->all());
            Session::put('alert_type', 'alert-info');
            return redirect('groups')->with('message', 'Group successfully updated.');
        }
    }
}
