<?php

namespace App\Http\Controllers;

use Auth;
use View;
use Calendar;
use Carbon\Carbon;
use App\Models\Travel;
class HomeController extends Controller
{
	public function __construct()
	{
		$data = array(
			'page' 	=> 'Home'
		);
		View::share('data', $data);
	}

    public function index()
    {
		$events 	= [];
        $employees  = '';
        $travels    = Travel::where('is_active', '=', '1')->get();

        foreach($travels as $travel) {
            foreach($travel->passengers as $employee) {
                $employees .= "<div>".$employee->u_fname." ".format_middle_name($employee->u_mname)." ".$employee->u_lname."</div>";
            }
            $events[] = Calendar::event(
                    $travel->t_destination." - ".create_initials($travel->user->u_fname, $travel->user->u_mname, $travel->user->u_lname),
                    true,
                    $travel->t_start_date,
                    Carbon::parse($travel->t_end_date)->addDay(),
                    $travel->t_id,
                        [
                            'color'         => $travel->user->u_id == Auth::user()->u_id ? '#5cb85c' : '#428bca',
                            'date'          => $travel->t_start_date == $travel->t_end_date ? Carbon::parse($travel->t_start_date)->format('F d') : Carbon::parse($travel->t_start_date)->format('F d')." to ".Carbon::parse($travel->t_end_date)->format('d'),
                            'created_by'    => '<strong>Created By:&nbsp</strong><strong class="text-primary">'.$travel->user->u_fname." ".format_middle_name($travel->user->u_mname)." ".$travel->user->u_lname.'</strong><br>',
                            'time'          => '<strong>Time of Departure:&nbsp</strong><strong class="text-primary">'.$travel->t_time.'</strong><br><br>',
                            'destination'   => '<strong>Destination </strong><p class="text-primary"><strong>'.$travel->t_destination."</strong></p><br>",
                            'purpose'       => '<strong>Purpose </strong><p class="text-primary"><strong>'.$travel->t_purpose."</strong></p><br>",
                            'employees'     => '<div class="pull-left"><strong><div>Employee/s</div></strong><strong class="text-primary">'.$employees.'</strong></div>',
                        ]
                );
            $employees = '';
        }

		$calendar   = Calendar::addEvents($events, [
                        'className' => 'calendarData',
                    ])->setOptions([
                        'header'        => ['left' => 'prev', 'center' => 'title', 'right' => 'next'],
                        'eventLimit'    => true,
                        'columnFormat'  => 'dddd',
                        'aspectRatio'   => '2',
                        'contentHeight' => 1000,
                        'eventOrder'    => 'color',
                    ])->setCallbacks([
                        'eventRender'   => 'function(event, element) {
                                                element.find(".fc-title").prepend("'."<span class='fa fa-user'></span> ".'");
                                                element.find(".fc-content").addClass("no-spill");
                                                element.attr("href", "javascript:void(0);");
                                                element.click(function() {
                                                    $("#eventUrl").attr("href", event.url);
                                                    $("#modalTitle").html(event.date);
                                                    $("#modalBody").html(event.created_by + event.time + event.destination + event.purpose + event.employees);
                                                    $("#calendarModal").modal();
                                                });
                                            }',
                    ]);
        return view('home.home', compact('calendar'));
    }
}
