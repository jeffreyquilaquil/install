<?php

namespace App\Http\Controllers;

use PDF;
use Auth;
use Image;
use App\Models\User;
use App\Models\Group;
use App\Models\Travel;
use App\Models\Expense;
use App\Models\Official;
use App\Models\TravelFundExpense;

class ImageController extends Controller
{
    public function show($id)
    {
        $user           = User::find($id);
        if($user->u_signature != NULL) {
	        $storage_path   = storage_path('app/images/signature/'.$user->u_signature);
	        $image          = Image::make($storage_path)->response();
	        return $image;
        }
        else {
        	return null;
        }
    }

    public function pdf($id)
    {
        $expenses           = Expense::all();
        $travel             = Travel::find($id);
        $recommending       = Official::where('g_id', '=', Auth::user()->g_id)->where('r_id', '=', Auth::user()->r_id)->where('to_approval', '=', '0')->first();
        $approval           = Official::where('g_id', '=', Auth::user()->g_id)->where('r_id', '=', Auth::user()->r_id)->where('to_approval', '=', '1')->first();
        $funds              = TravelFundExpense::where('t_id', '=', $id)->lists('f_id')->toArray();
        $rd                 = User::where('r_id', '=', get_user_role('Regional Director'))->first();
        $view               = view('pdf.travelorder.travelorder', compact('travel', 'expenses', 'rd', 'funds', 'recommending', 'approval'));
        $pdf                = PDF::loadHTML($view, 'travelorder');
        return $pdf->inline();
    }
}