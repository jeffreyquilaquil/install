<?php

namespace App\Http\Controllers;

use Auth;
use Session;
use App\Http\Requests\UserLogin;

class LoginController extends Controller
{
    public function index()
    {
        $error_message = '';
        if(Session::has('error_message')) {
            $error_message = Session::get('error_message');
            Session::put('error_message', '');
        }
        return view('login.login', compact('error_message'));
    }

    public function su_index()
    {
        $error_message = '';
        if(Session::has('error_message')) {
            $error_message = Session::get('error_message');
            Session::put('error_message', '');
        }
        return view('login.su_login', compact('error_message'));
    }

    public function login(UserLogin $request)
    {
        $userdata   = array(
                'u_username'    => $request->get('username'),
                'password'      => $request->get('password'),
                'is_active'     => 1
            );
        if(Auth::attempt($userdata)) {
            return redirect('home');
        }
        return redirect('/')->with('error_message', 'Invalid username or password');
    }
    
    public function su_login(UserLogin $request)
    {
        $userdata   = array(
                'u_username'    => $request->get('username'),
                'password'      => $request->get('password'),
                'is_active'     => 0,
                'r_id'          => 1
            );
        if(Auth::attempt($userdata)) {
            return redirect('administrators');
        }
        return redirect('su')->with('error_message', 'Invalid username or password');
    }

    public function logout()
    {
        Session::flush();
        Auth::logout();
        return redirect('/');
    }
}
