<?php

namespace App\Http\Controllers;

use Auth;
use View;
use Session;
use App\Models\User;
use App\Http\Requests\ProfileValidation;
class ProfileController extends Controller
{
    public function __construct()
    {
        $data = array(
            'page'  => 'Profile'
        );
        View::share('data', $data);
    }

    public function index()
    {
        $option         = 'Profile';
        $user           = User::find(Auth::user()->u_id);
        return view('profile.profile', compact('id', 'user', 'option'));
    }

    public function save(ProfileValidation $request)
    {
    	$user       = User::find(Auth::user()->u_id);
        $user->update($request->all());
    	$request->except('u_image');
    	if($request->file('u_image') != NULL) {
    		$filename 		= $request->file('u_image')->getClientOriginalName();
    		$request->file('u_image')->move('images/profile', $filename);
    		$user->u_image 	= 'images/profile/'.$filename;
    		$user->update();
    	}
        Session::put('alert_type', 'alert-success');
        return redirect('profile')->with('message', 'Profile successfully updated.');
    }
}