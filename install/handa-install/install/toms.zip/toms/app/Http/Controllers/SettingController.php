<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use View;
use Input;
use Session;
use App\Models\User;
use App\Models\Role;
use App\Models\Group;
use App\Models\Setting;
use App\Models\Official;
use App\Http\Requests\SettingValidation;
class SettingController extends Controller
{
    public function __construct()
    {      
        $data = array(
            'page'  => 'Settings'
        );
        View::share('data', $data);
    }

    public function index()
    {
        $officials  = Official::get();
        $setting    = Setting::first();
        $groups     = Group::get();
        return view('settings.settings', compact('setting', 'groups', 'officials'));
    }

    public function add()
    {
        $id             = 0;
        $option         = 'New';
        $official       = new Official;
        $groups         = Group::lists('g_name', 'g_id');
        $approval       = array('0' => 'Recommending Approval', '1' => 'Approval');
        $role           = Role::where('r_id', '>', '2')->lists('r_name', 'r_id');
        $users          = User::select('u_id', DB::raw('CONCAT(u_lname, ", ", u_fname) as full_name'))->where('r_id', '>=', '3')->orderBy('u_lname')->lists('full_name', 'u_id');
        return view('settings.form', compact('id', 'official', 'option', 'users', 'groups', 'role', 'approval'));
    }

    public function edit($id)
    {
        $option         = 'Update';
        $official       = Official::find($id);
        $groups         = Group::lists('g_name', 'g_id');
        $approval       = array('0' => 'Recommending Approval', '1' => 'Approval');
        $role           = Role::where('r_id', '>', '2')->lists('r_name', 'r_id');
        $users          = User::select('u_id', DB::raw('CONCAT(u_lname, ", ", u_fname) as full_name'))->where('r_id', '>=', '3')->orderBy('u_lname')->lists('full_name', 'u_id');
        return view('settings.form', compact('id', 'official', 'option', 'users', 'groups', 'role', 'approval'));
    }

    public function save(SettingValidation $request)
    {
        $setting    = Setting::first();
        $setting->update($request->all());
        Session::put('alert_type', 'alert-info');
        return redirect('settings')->with('message', 'System Settings successfully updated.');
    }

    public function official($id)
    {
        if($id == 0) {
            $official   = Official::create(Input::all());
            Session::put('alert_type', 'alert-success');
            return redirect('settings')->with('message', 'New settings successfully added.');
        }
        else {
            $official   = Official::find($id);
            $official->update(Input::all());
            Session::put('alert_type', 'alert-success');
            return redirect('settings')->with('message', 'Settings successfully updated.');
        }
    }
}