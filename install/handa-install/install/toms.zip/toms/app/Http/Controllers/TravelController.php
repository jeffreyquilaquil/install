<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use View;
use Session;
use App\Models\User;
use App\Models\Mode;
use App\Models\Travel;
use App\Models\Comment;
use App\Models\Expense;
use App\Models\Passenger;
use App\Models\Official;
use App\Models\TravelFundExpense;
use App\Http\Requests\TravelValidation;

class TravelController extends Controller
{
    public function __construct()
    {     
        $data = array(
            'page'  => 'Travels'
        );
        View::share('data', $data);
    }

    public function index()
    {
    	$travels 			= Travel::whereHas('passengers', function($q) {
                                $q->where('to_travel_passengers.u_id', '=', Auth::user()->u_id)->orWhere('to_travels.u_id', '=', Auth::user()->u_id);
                            })->latest('t_id')->Paginate(15);
        return view('travels.travels', compact('travels'));
    }

    public function add()
    {
    	$id             	= 0;
        $option         	= 'New';
        $travel         	= new Travel;
        $modes 				= Mode::lists('m_name', 'm_id');
        $users 				= User::select('u_id', DB::raw('CONCAT(u_lname, ", ", u_fname) as full_name'))->where('r_id', '>=', '3')->orderBy('u_lname')->lists('full_name', 'u_id');
        return view('travels.form', compact('id', 'travel', 'option', 'modes', 'users'));
    }

    public function edit($id)
    {
        $option         	= 'Update';
        $travel         	= Travel::find($id);
        $modes 				= Mode::lists('m_name', 'm_id');
        $users 				= User::select('u_id', DB::raw('CONCAT(u_lname, ", ", u_fname) as full_name'))->where('r_id', '>=', '3')->orderBy('u_lname')->lists('full_name', 'u_id');
        $travel->passengers = Passenger::where('t_id', '=', $id)->lists('u_id')->all();
        return view('travels.form', compact('id', 'travel', 'option', 'modes', 'users'));
    }

    public function view($id)
    {
        $option             = 'View';
        $travel             = Travel::find($id);
        $comments           = Comment::where('t_id', '=', $id)->get();
        $expenses           = Expense::all();
        $funds              = TravelFundExpense::where('t_id', '=', $id)->lists('f_id')->toArray();
        if($travel->u_id == Auth::user()->u_id) {
            Comment::where('t_id', '=', $id)->update(['is_read' => 1]);
        }
        Passenger::where('u_id', '=', Auth::user()->u_id)->where('is_read', '=', '0')->update(['is_read' => '1']);
        return view('travels.view', compact('id', 'travel', 'option', 'comments', 'expenses', 'funds'));
    }

    public function save(TravelValidation $request, $id)
    {
        $fund_ids           = $request->get('f_id');
        $expense_ids        = $request->get('e_id');
        $others             = $request->get('tfe_others');

        if($id == 0) {
            $travel         = Travel::create($request->all());

            $sync_data  = [];
            $i          = 0;
            foreach($expense_ids as $key => $expense) {
                if($fund_ids[$key] == '3') {
                    $sync_data[]      = ['f_id' => $fund_ids[$key], 'e_id' => $expense_ids[$key], 'tfe_others' => $others[$i]];
                    $i++;
                }
                else {
                    $sync_data[]      = ['f_id' => $fund_ids[$key], 'e_id' => $expense_ids[$key], 'tfe_others' => ''];
                }
            }
            
            $travel->expenses()->attach($sync_data);

            if($request->hasFile('t_files')) {
                $filenames          = [];
                foreach($request->file('t_files') as $file) {
                    $filenames[]    = time().'-'.$file->getClientOriginalName();
                    $file_type      = $file->getClientOriginalExtension();
                    if($file_type == 'pdf' || $file_type == 'jpg' || $file_type == 'jpeg' || $file_type == 'png') {
                        $file->move(base_path('storage/app/documents/'.date('Y-F').'/'), time().'-'.$file->getClientOriginalName());
                    }
                    else {
                        Session::put('alert_type', 'alert-danger');
                        return redirect()->back()->with('message', 'File type must be pdf, jpg, jpeg or png.');
                    }
                }
                $travel->documents()->attach($filenames);
            }

            $request->except('passengers');
            $travel->passengers()->attach($request->get('passengers'));
            Session::put('alert_type', 'alert-success');
            return redirect('travels')->with('message', 'New travel successfully added.');
        }
        else {
            $travel                     = Travel::find($id);
            $travel->to_recommending    = 0;
            $travel->to_approval        = 0;
            $travel->is_active          = 1;

            $sync_data                  = [];
            $i                          = 0;
            foreach($expense_ids as $key => $expense) {
                if($fund_ids[$key] == '3') {
                    $sync_data[]      = ['f_id' => $fund_ids[$key], 'e_id' => $expense_ids[$key], 'tfe_others' => $others[$i]];
                    $i++;
                }
                else {
                    $sync_data[]      = ['f_id' => $fund_ids[$key], 'e_id' => $expense_ids[$key], 'tfe_others' => ''];
                }
            }

            if($request->hasFile('t_files')) {
                $filenames          = [];
                foreach($request->file('t_files') as $file) {
                    $filenames[]    = time().'-'.$file->getClientOriginalName();
                    $file_type      = $file->getClientOriginalExtension();
                    if($file_type == 'pdf' || $file_type == 'jpg' || $file_type == 'jpeg' || $file_type == 'png') {
                        $file->move(base_path('storage/app/documents/'.date('Y-F').'/'), time().'-'.$file->getClientOriginalName());
                    }
                    else {
                        Session::put('alert_type', 'alert-danger');
                        return redirect()->back()->with('message', 'File type must be pdf, jpg, jpeg or png.');
                    }
                }
                $travel->documents()->sync($filenames, true);
            }

            $request->except('passengers');
            $travel->expenses()->sync([]);
            $travel->expenses()->sync($sync_data);
            $travel->passengers()->sync($request->get('passengers'), true);
            $travel->touch();
            $travel->update($request->all());           
            Session::put('alert_type', 'alert-info');
            return redirect('travels')->with('message', 'Travel successfully updated.');
        }
    }
}