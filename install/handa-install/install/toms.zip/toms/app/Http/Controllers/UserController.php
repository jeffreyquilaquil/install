<?php

namespace App\Http\Controllers;

use Auth;
use View;
use Input;
use Session;
use App\Models\User;
use App\Models\Role;
use App\Models\Group;
use App\Http\Requests\UserValidation;

class UserController extends Controller
{
    public function __construct()
    {      
        $data = array(
            'page'  => 'Users'
        );
        View::share('data', $data);
    }

    public function index()
    {
        $users      = User::where('r_id', '>', '2')->orderBy('u_lname')->Paginate(15);
        return view('users.users', compact('users'));
    }

    public function search()
    {
        $search     = Input::get('search');
        $users      = User::where('r_id', '>', '2')
                            ->where(function($query) use ($search) {
                                $query->where('u_fname', 'like', "%$search%")
                                      ->orWhere('u_mname', 'like', "%$search%")
                                      ->orWhere('u_lname', 'like', "%$search%");
                            })->orWhereHas('group', function($q) use($search) {
                                $q->where('g_name', 'like', "%$search%");
                            })->Paginate(15);
        return view('users.users', compact('users'));
    }
    public function add()
    {
        $id             = 0;
        $option         = 'New';
        $user           = new User;
        $roles          = Role::where('r_id', '>', '2')->lists('r_name', 'r_id');
        $groups         = Group::lists('g_name', 'g_id');
        return view('users.form', compact('id', 'user', 'option', 'roles', 'groups'));
    }

    public function edit($id)
    {
        $option         = 'Update';
        $user           = User::find($id);
        $roles          = Role::where('r_id', '>', '2')->lists('r_name', 'r_id');
        $groups         = Group::lists('g_name', 'g_id');
        return view('users.form', compact('id', 'user', 'option', 'roles', 'groups'));
    }

    public function save(UserValidation $request, $id)
    {
        if($id == 0) {
            $user       = User::create($request->all());
            Session::put('alert_type', 'alert-success');
            return redirect('users')->with('message', 'New user successfully added.');
        }
        else {
            $user       = User::find($id);
            $user->update($request->all());
            $request->except('u_signature');
            if($request->file('u_signature') != null) {
                $extension              = $request->file('u_signature')->getClientOriginalExtension();
                $request->file('u_signature')->move(base_path('storage/app/images/signature/'), $user->u_username.".".$extension);
                $user->u_signature      = $user->u_username.".".$extension;
                $user->update();
            }
            Session::put('alert_type', 'alert-info');
            return redirect('users')->with('message', 'User successfully updated.');
        }
    }

    public function reset($id)
    {
        $user               = User::find($id);
        $user->u_password   = 'dostcalabarzon';
        $user->save();
        Session::put('alert_type', 'alert-success');
        return redirect('users')->with('message', 'Password successfully updated.');
    }
}
