<?php

namespace App\Http\Middleware;

use Auth;
use Closure;
use Session;

class AdminAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(Auth::user()->r_id == '2') {
            return $next($request);
        }
        else {
            Session::put('alert_type', 'alert-danger');
            return redirect()->back()->with('message', 'You are not authorized to access this page.');
        }
    }
}
