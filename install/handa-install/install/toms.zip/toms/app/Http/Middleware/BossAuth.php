<?php

namespace App\Http\Middleware;

use Auth;
use Session;
use Closure;

class BossAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(get_group_heads(Auth::user()->u_id)) {
            return $next($request);
        }
        else {
            Session::put('alert_type', 'alert-danger');
            return redirect()->back()->with('message', 'You are not authorized to access this page.');
        }
        return $next($request);
    }
}
