<?php

namespace App\Http\Middleware;

use Auth;
use Session;
use Request;
use Closure;
use App\Models\Travel;

class MustBeOwnerOfTravel
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $role)
    {
        // $id         = Request::segment(3);
        // $travel     = Travel::find($id);
        // if($id == 0) {
        //     return $next($request);
        // }
        // if($travel == null) {
        //     Session::put('alert_type', 'alert-warning');
        //     return redirect()->back()->with('message', 'No record found.');
        // }
        // if($role == 'update' && $travel->u_id == Auth::user()->u_id) {
        //     return $next($request);
        // }
        // if($role == 'view') {
        //     if(count($travel->passengers) == 0) {
        //         if($travel->u_id == Auth::user()->u_id) {
        //             return $next($request);
        //         }
        //     }
        //     else {
        //         foreach($travel->passengers as $user) {
        //             if($user->u_id == Auth::user()->u_id) {
        //                 return $next($request);
        //             }
        //         }
        //     }
        // }
        // Session::put('alert_type', 'alert-warning');
        // return redirect()->back()->with('message', 'Oops! You are not allowed to access this page.');
    }
}