<?php

namespace App\Http\Requests;

use Input;
use App\Http\Requests\Request;

class AccountValidation extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'u_fname'           => 'required|min:2',
            'u_mname'           => 'required|min:1',
            'u_lname'           => 'required|min:2',
            'u_username'        => 'required|alpha_num|min:3|unique:to_users,u_username,'.Request::segment(3).',u_id',
            'u_password'        => 'required|min:8',
            'rg_id'             => 'required',
            'r_id'              => 'required'
        ];
    }

    public function attributes()
    {
        return [
            'u_fname'           => 'First Name',
            'u_mname'           => 'Middle Name',
            'u_lname'           => 'Last Name',
            'u_username'        => 'Username',
            'u_password'        => 'Password',
            'u_signature'       => 'Signature',
            'rg_id'             => 'Region',
            'r_id'              => 'Role'
        ];
    }
}
