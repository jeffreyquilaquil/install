<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class ProfileValidation extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'u_fname'           => 'required|min:2',
            'u_mname'           => 'required|min:1',
            'u_lname'           => 'required|min:2',
            'u_username'        => 'required|alpha_num|min:3|unique:to_users,u_username,'.\Auth::user()->u_id.',u_id',
            'u_password'        => 'required|min:8',
            'u_position'        => 'required',
            'u_image'           => 'image'
        ];
    }

    public function attributes()
    {
        return [
            'u_fname'           => 'First Name',
            'u_mname'           => 'Middle Name',
            'u_lname'           => 'Last Name',
            'u_username'        => 'Username',
            'u_password'        => 'Password',
            'u_position'        => 'Designation',
            'u_image'           => 'Profile Picture'
        ];
    }
}
