<?php

namespace App\Http\Requests;

use Carbon\Carbon;
use App\Models\User;
use App\Http\Requests\Request;

class TravelValidation extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            't_start_date'      => 'required',
            't_end_date'        => 'required',
            't_time'            => 'required',
            'passengers'        => 'required',
            't_destination'     => 'required',
            'm_id'              => 'required',
            't_purpose'         => 'required',
            't_files[]'         => 'image'
        ];

    }

    public function attributes()
    {
        return [
            't_start_date'      => 'Start Date',
            't_end_date'        => 'End Date',
            't_time'            => 'Time of Departure',
            'passengers'        => 'Employee/s',
            't_destination'     => 'Destination',
            'm_id'              => 'Mode of Travel',
            't_purpose'         => 'Purpose of Visit',
            't_files[]'         => 'Travel Documents' 
        ];
    }

    public function getValidatorInstance()
    {
        $data                   = $this->all();
        $data['t_start_date']   = Carbon::parse($data['t_start_date'])->format('Y-m-d');
        $data['t_end_date']     = Carbon::parse($data['t_end_date'])->format('Y-m-d');
        $data['u_id']           = \Auth::user()->u_id;
        $this->getInputSource()->replace($data);
        return parent::getValidatorInstance();
    }
}
