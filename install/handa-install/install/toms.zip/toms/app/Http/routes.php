<?php

Route::group(['middleware' => 'verify.session'], function() {

	// Login Routes
	get('/', 'LoginController@index');
	get('login', 'LoginController@login');
	post('login', 'LoginController@login');

	get('su', 'LoginController@su_index');
	get('su/login', 'LoginController@su_login');
	post('su/login', 'LoginController@su_login');
});



Route::group(['middleware' => 'auth'], function() {

	get('home', 'HomeController@index');
	get('profile', 'ProfileController@index');
	get('profile/save', 'ProfileController@save');
	post('profile/save', 'ProfileController@save');
	
	get('travels', 'TravelController@index');
	get('travels/new', 'TravelController@add');
	get('travels/update/{id}', 'TravelController@edit');
	get('travels/view/{id}', 'TravelController@view');
	get('travels/save/{id}', 'TravelController@save');
	post('travels/save/{id}', 'TravelController@save');

	get('archive', 'ArchiveController@index');
	get('archive/search', 'ArchiveController@search');
	post('archive/search', 'ArchiveController@search');
	get('archive/view/{id}', 'ArchiveController@view');

	Route::group(['middleware' => 'auth.superuser'], function() {

		// Superuser Route
		get('administrators', 'AccountController@index_admin');
		get('administrators/new', 'AccountController@add');
		get('administrators/update/{id}', 'AccountController@edit');
		get('administrators/save/{id}', 'AccountController@save');
		post('administrators/save/{id}', 'AccountController@save');
	});

	Route::group(['middleware' => 'auth.admin'], function() {

		// Users Route
		get('users', 'UserController@index');
		get('users/new', 'UserController@add');
		get('users/search', 'UserController@search');
		post('users/search', 'UserController@search');
		get('users/update/{id}', 'UserController@edit');
		get('users/save/{id}', 'UserController@save');
		post('users/save/{id}', 'UserController@save');
		get('users/reset/{id}', 'UserController@reset');
		
		// Groups Route
		get('groups', 'GroupController@index');
		get('groups/new', 'GroupController@add');
		get('groups/update/{id}', 'GroupController@edit');
		get('groups/view/{id}', 'GroupController@view');
		get('groups/save/{id}', 'GroupController@save');
		post('groups/save/{id}', 'GroupController@save');

		get('settings', 'SettingController@index');
		get('settings/new', 'SettingController@add');
		get('settings/update/{id}', 'SettingController@edit');
		get('settings/official/{id}', 'SettingController@official');
		post('settings/official/{id}', 'SettingController@official');
		get('settings/save', 'SettingController@save');
		post('settings/save', 'SettingController@save');
	});

	Route::group(['middleware' => 'auth.boss'], function() {

		get('approval', 'ApprovalController@index');
		get('approval/view/{id}', 'ApprovalController@view');
		post('approval/save/{id}', 'ApprovalController@save');

		get('approved', 'ApprovedController@index');
		get('approved/view/{id}', 'ApprovedController@view');


		get('disapproved', 'DisapprovedController@index');
		get('disapproved/view/{id}', 'DisapprovedController@view');
	});

	get('pdf/{id}', 'ImageController@pdf');
});

get('image/{id}', 'ImageController@show');
get('logout', 'LoginController@logout');