<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    protected $table 		= 'to_travel_comments';
    protected $primaryKey 	= 'tc_id';
    protected $fillable 	= ['t_id', 'u_id', 'tc_comment', 'is_read'];

    public function user()
    {
    	return $this->hasOne('App\Models\User', 'u_id', 'u_id');
    }
}