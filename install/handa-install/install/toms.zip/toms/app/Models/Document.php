<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    protected $table 		= 'to_travel_documents';
    protected $primaryKey 	= 'td_id';
    protected $fillable 	= ['t_id', 'td_path'];

    public function travel()
    {
    	return $this->hasOne('App\Models\Travel', 't_id', 't_id');
    }
}