<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Expense extends Model
{
    protected $table 		= 'to_expenses';
    protected $primaryKey 	= 'e_id';
    protected $fillable 	= ['e_name'];
}