<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Group extends Model
{
    protected $table 		= 'to_groups';
    protected $primaryKey 	= 'g_id';
    protected $fillable 	= ['g_name', 'd_id'];

    public function users()
    {
    	return $this->hasMany('App\Models\User', 'g_id', 'g_id')->orderBy('r_id');
    }

    public function division()
    {
    	return $this->hasOne('App\Models\Division', 'd_id', 'd_id');
    }
}