<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Official extends Model
{
    protected $table 		= 'to_officials';
    protected $primaryKey 	= 'to_id';
    protected $fillable 	= ['u_id', 'g_id', 'r_id', 'to_approval', 'oic'];

    public function user()
    {
    	return $this->hasOne('App\Models\User', 'u_id', 'u_id');
    }

    public function group()
    {
    	return $this->hasOne('App\Models\Group', 'g_id', 'g_id');
    }

    public function role()
    {
        return $this->hasOne('App\Models\Role', 'r_id', 'r_id');
    }
}