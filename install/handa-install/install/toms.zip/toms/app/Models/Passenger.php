<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Passenger extends Model
{
    protected $table 		= 'to_travel_passengers';
    protected $primaryKey 	= 'tp_id';
    protected $fillable 	= ['t_id', 'u_id', 'is_read'];

    public function user()
    {
    	return $this->hasOne('App\Models\User', 'u_id', 'u_id');
    }
}