<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    protected $table 		= 'to_roles';
    protected $primaryKey 	= 'r_id';
    protected $fillable 	= ['r_name'];
}