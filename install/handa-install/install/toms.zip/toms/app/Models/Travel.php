<?php

namespace App\Models;

use Carbon;
use Illuminate\Database\Eloquent\Model;

class Travel extends Model
{
    protected $table 		= 'to_travels';
    protected $primaryKey 	= 't_id';
    protected $dates 		= ['t_start_date', 't_end_date'];
    protected $fillable 	= ['t_start_date', 't_end_date', 't_purpose', 't_destination', 't_time', 't_remarks', 'm_id', 'u_id', 'to_recommending', 'to_approval', 'is_read', 'is_active'];

    public function passengers()
    {
    	return $this->belongsToMany('App\Models\User', 'to_travel_passengers', 't_id', 'u_id')->withTimestamps();
    }

    public function comments()
    {
        return $this->belongsToMany('App\Models\User', 'to_travel_comments', 't_id', 'u_id')->withTimestamps();
    }

    public function documents()
    {
        return $this->belongsToMany('App\Models\Document', 'to_travel_documents', 't_id', 'td_path')->withTimestamps();
    }

    public function signatures()
    {
        return $this->belongsToMany('App\Models\Official', 'to_officials', 't_id', 'u_id');
    }

    public function files()
    {
        return $this->hasMany('App\Models\Document', 't_id', 't_id');
    }
    
    public function unread()
    {
        return $this->belongsToMany('App\Models\User', 'to_travel_comments', 't_id', 'u_id')->where('is_read', '=', '0')->withTimestamps();
    }

    public function expenses()
    {
        return $this->belongsToMany('App\Models\Expense', 'to_travel_funds_expenses', 't_id', 'e_id')->withPivot('f_id', 'tfe_others')->withTimestamps();
    }

    public function users()
    {
    	return $this->hasMany('App\Models\User', 'u_id', 'u_id');
    }

    public function user()
    {
        return $this->hasOne('App\Models\User', 'u_id', 'u_id');
    }
    
    public function mode()
    {
        return $this->hasOne('App\Models\Mode', 'm_id', 'm_id');
    }
}