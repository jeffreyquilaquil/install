<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TravelFundExpense extends Model
{
    protected $table 		= 'to_travel_funds_expenses';
    protected $primaryKey 	= 'tfe_id';
    protected $fillable 	= ['t_id', 'f_id', 'e_id'];
}