<?php

namespace App\Models;

use Hash;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;

class User extends Model implements AuthenticatableContract, CanResetPasswordContract
{
	use Authenticatable, CanResetPassword;

    protected $table 		= 'to_users';
    protected $primaryKey 	= 'u_id';
    protected $hidden 		= 'u_password';
    protected $fillable 	= ['u_suffix', 'u_fname', 'u_mname', 'u_lname', 'u_username', 'u_password', 'u_position', 'u_signature', 'u_image', 'g_id',  'r_id', 'is_active'];

    public function getAuthPassword()
    {
    	return $this->u_password;
    }

    public function setUpasswordAttribute($value)
    {
    	$this->attributes['u_password'] 	= Hash::make($value);
    }

    public function setUfnameAttribute($value)
    {
    	$this->attributes['u_fname'] 		= ucwords($value);
    }

    public function setUmnameAttribute($value)
    {
        $this->attributes['u_mname']        = ucwords($value);
    }

    public function setUlnameAttribute($value)
    {
    	$this->attributes['u_lname'] 		= ucwords($value);
    }

    public function group()
    {
        return $this->hasOne('App\Models\Group', 'g_id', 'g_id');
    }

    public function role()
    {
        return $this->hasOne('App\Models\Role', 'r_id', 'r_id');
    }

    public function officials()
    {
        return $this->hasMany('App\Models\Official', 'g_id', 'g_id');
    }
}