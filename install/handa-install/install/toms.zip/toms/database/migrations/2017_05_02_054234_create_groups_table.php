<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGroupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('to_groups', function (Blueprint $table) {
            $table->increments('g_id');
            $table->string('g_name');
            $table->integer('d_id')->unsigned();
            $table->foreign('d_id')->references('d_id')->on('to_divisions')->onUpdate('cascade')->onDelete('cascade');
            $table->tinyInteger('is_active')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('to_groups');
    }
}