<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('to_users', function (Blueprint $table) {
            $table->increments('u_id');
            $table->string('u_username');
            $table->string('u_password');
            $table->string('u_fname');
            $table->string('u_mname');
            $table->string('u_lname');
            $table->string('u_suffix');
            $table->string('u_position')->nullable();
            $table->string('u_signature')->nullable();
            $table->string('u_image')->nullable();
            $table->integer('r_id')->unsigned()->nullable();
            $table->foreign('r_id')->references('r_id')->on('to_roles')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('g_id')->unsigned()->nullable();
            $table->foreign('g_id')->references('g_id')->on('to_groups')->onUpdate('cascade')->onDelete('cascade');
            $table->tinyInteger('is_active')->default(1);
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        \DB::statement('SET FOREIGN_KEY_CHECKS=0');
        Schema::dropIfExists('to_users');
        \DB::statement('SET FOREIGN_KEY_CHECKS=1');
    }
}
