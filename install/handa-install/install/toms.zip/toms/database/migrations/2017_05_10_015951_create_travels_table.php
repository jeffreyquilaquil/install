<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTravelsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('to_travels', function (Blueprint $table) {
            $table->increments('t_id');
            $table->text('t_purpose');
            $table->text('t_destination');
            $table->date('t_start_date');
            $table->date('t_end_date');
            $table->string('t_time');
            $table->text('t_remarks')->nullable();
            $table->integer('u_id')->unsigned();
            $table->foreign('u_id')->references('u_id')->on('to_users')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('m_id')->unsigned();
            $table->foreign('m_id')->references('m_id')->on('to_modes')->onUpdate('cascade')->onDelete('cascade');
            $table->tinyInteger('to_recommending')->unsigned();
            $table->tinyInteger('to_approval')->unsigned();
            $table->tinyInteger('is_read')->default(0);
            $table->tinyInteger('is_active')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('to_travels');
    }
}
