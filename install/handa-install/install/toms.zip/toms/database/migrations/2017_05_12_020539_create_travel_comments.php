<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTravelComments extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('to_travel_comments', function (Blueprint $table) {
            $table->increments('tc_id');
            $table->integer('t_id')->unsigned();
            $table->foreign('t_id')->references('t_id')->on('to_travels')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('u_id')->unsigned();
            $table->foreign('u_id')->references('u_id')->on('to_users')->onUpdate('cascade')->onDelete('cascade');
            $table->text('tc_comment');
            $table->tinyInteger('is_read')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('to_travel_comments');
    }
}
