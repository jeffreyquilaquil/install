<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTravelDocuments extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('to_travel_documents', function (Blueprint $table) {
            $table->increments('td_id');
            $table->integer('t_id')->unsigned();
            $table->foreign('t_id')->references('t_id')->on('to_travels')->onDelete('cascade')->onUpdate('cascade');
            $table->string('td_path');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('to_travel_documents');
    }
}
