<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTravelFundsExpense extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('to_travel_funds_expenses', function (Blueprint $table) {
            $table->increments('tfe_id');
            $table->integer('t_id')->unsigned();
            $table->foreign('t_id')->references('t_id')->on('to_travels')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('f_id')->unsigned();
            $table->foreign('f_id')->references('f_id')->on('to_funds')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('e_id')->unsigned();
            $table->foreign('e_id')->references('e_id')->on('to_expenses')->onUpdate('cascade')->onDelete('cascade');
            $table->string('tfe_others')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('to_travel_funds_expenses');
    }
}
