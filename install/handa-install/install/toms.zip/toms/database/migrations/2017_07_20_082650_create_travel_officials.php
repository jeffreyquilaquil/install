<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTravelOfficials extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('to_officials', function (Blueprint $table) {
            $table->increments('to_id');
            $table->integer('u_id')->unsigned();
            $table->foreign('u_id')->references('u_id')->on('to_users')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('g_id')->unsigned();
            $table->foreign('g_id')->references('g_id')->on('to_groups')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('r_id')->unsigned();
            $table->foreign('r_id')->references('r_id')->on('to_roles')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('to_approval')->unsigned();
            $table->tinyInteger('oic')->unsigned();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('to_officials');
    }
}
