<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTravelSignatures extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('to_travel_signatures', function (Blueprint $table) {
            $table->increments('ts_id');
            $table->integer('t_id')->unsigned();
            $table->foreign('t_id')->references('t_id')->on('to_travels')->onUpdate('cascade')->onDelete('cascade');
            $table->integer('u_id')->unsigned();
            $table->integer('ts_role')->unsigned();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('to_travel_signatures');
    }
}
