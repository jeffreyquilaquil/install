<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        $this->call(DivisionTableSeeder::class);
        $this->call(RoleTableSeeder::class);
        // $this->call(GroupTableSeeder::class);
        $this->call(UserTableSeeder::class);
        $this->call(ModeTableSeeder::class);
        $this->call(SettingTableSeeder::class);
        $this->call(FundTableSeeder::class);
        $this->call(ExpenseTableSeeder::class);
        // $this->call(OfficialTableSeeder::class);

        Model::reguard();
    }
}