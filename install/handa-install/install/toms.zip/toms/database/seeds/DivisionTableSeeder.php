<?php

use App\Models\Division;
use Illuminate\Database\Seeder;

class DivisionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('to_divisions')->delete();

        Division::create(['d_name'     =>   'Regional Office']);
        Division::create(['d_name'     =>   'Provincial Office']);
        Division::create(['d_name'     =>   'Finance and Administrative Services']);
    }
}