<?php

use App\Models\Expense;
use Illuminate\Database\Seeder;

class ExpenseTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('to_expenses')->delete();
        Expense::create(['e_name' 	=> 'Accomodation']);
        Expense::create(['e_name' 	=> 'Meals/Food']);
        Expense::create(['e_name' 	=> 'Incidental expenses']);
        Expense::create(['e_name' 	=> 'Accomodation']);
        Expense::create(['e_name' 	=> 'Subsistence']);
        Expense::create(['e_name' 	=> 'Incidental expenses']);
    }
}
