<?php

use App\Models\Fund;
use Illuminate\Database\Seeder;

class FundTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('to_funds')->delete();
        Fund::create(['f_name' 	=> 'General Funds']);
        Fund::create(['f_name' 	=> 'Project Funds']);
        Fund::create(['f_name' 	=> 'Others']);
    }
}
