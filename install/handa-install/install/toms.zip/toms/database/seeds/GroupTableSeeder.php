e<?php

use App\Models\Group;
use Illuminate\Database\Seeder;

class GroupTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('to_groups')->delete();

        Group::create([
        	'g_name'       	=> 'Cavite',
            'd_id'          => 2,
        ]);
        Group::create([
        	'g_name'       	=> 'Laguna',
            'd_id'          => 2,
        ]);
        Group::create([
        	'g_name'       	=> 'Batangas',
            'd_id'          => 2,
        ]);
        Group::create([
        	'g_name'       	=> 'Rizal',
            'd_id'          => 2,
        ]);
        Group::create([
        	'g_name'       	=> 'Quezon',
            'd_id'          => 2,
        ]);
        Group::create([
            'g_name'        => 'Regional Office',
            'd_id'          => 1,
        ]);
        Group::create([
            'g_name'        => 'Finance and Administrative Services',
            'd_id'          => 3,
        ]);
    }
}
