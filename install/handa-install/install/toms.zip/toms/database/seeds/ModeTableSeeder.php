<?php

use App\Models\Mode;
use Illuminate\Database\Seeder;

class ModeTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('to_modes')->delete();

        Mode::create(['m_name' 		=> 'DOST Vehicle']);
        Mode::create(['m_name' 		=> 'Public Conveyance']);
        Mode::create(['m_name' 		=> 'Van Rental']);
    }
}
