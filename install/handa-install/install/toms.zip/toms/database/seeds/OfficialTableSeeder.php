<?php

use App\Models\Official;
use Illuminate\Database\Seeder;

class OfficialTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('to_officials')->delete();

        Official::create([
            'u_id'          => 12,
            'g_id'          => 6,
            'r_id'          => 3,
            'oic'           => 0,
        ]);
        Official::create([
            'u_id'          => 13,
            'g_id'          => 6,
            'r_id'          => 4,
            'oic'           => 0,
        ]);
        Official::create([
            'u_id'          => 30,
            'g_id'          => 6,
            'r_id'          => 5,
            'oic'           => 0,
        ]);
        Official::create([
            'u_id'          => 96,
            'g_id'          => 6,
            'r_id'          => 6,
            'oic'           => 0,
        ]);
    }
}