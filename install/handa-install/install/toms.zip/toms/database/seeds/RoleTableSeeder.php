<?php

use App\Models\Role;
use Illuminate\Database\Seeder;

class RoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('to_roles')->delete();

        Role::create(['r_name' 		=> 'Superuser']);
        Role::create(['r_name' 		=> 'Administrator']);
        Role::create(['r_name'      => 'Regional Director']);
        Role::create(['r_name'      => 'Assistant Regional Director - TO']);
        Role::create(['r_name'      => 'Assistant Regional Director - FAS']);
        Role::create(['r_name'      => 'Provincial Director']);
        Role::create(['r_name'      => 'Staff']);
        Role::create(['r_name'      => 'FAS-Admin']);
    }
}