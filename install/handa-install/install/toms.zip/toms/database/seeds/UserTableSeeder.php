<?php

use App\Models\User;
use Illuminate\Database\Seeder;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('to_users')->delete();
        // exec('mysql -u '.env('DB_USERNAME').' -p'.env('DB_PASSWORD').' '.env('DB_DATABASE').' < '.storage_path('sql/to_users.sql'));

        User::create([
                'u_username'        => 'admin',
                'u_password'        => 'admin',
                'u_fname'           => 'DOST',
                'u_mname'           => '..',
                'u_lname'           => 'ADMIN',
                'r_id'              => '2',
                'g_id'              => NULL,
                'is_active'         => '1',
            ]);
    }
}
 