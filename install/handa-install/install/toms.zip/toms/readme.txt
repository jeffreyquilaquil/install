FONTS

	1. sudo apt-get install ttf-mscorefonts-installer

WKHTMLTOPDF installation.

	1. sudo mv /var/web/toms/wkhtmltopdf/wkhtmltox.tar.xz /usr/local/bin/wkhtmltox.tar.xz
	2. sudo tar xf wkhtmltox.tar.xz