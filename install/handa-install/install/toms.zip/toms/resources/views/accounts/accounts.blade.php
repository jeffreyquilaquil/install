@extends('layouts.admin_content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="header clearfix">
								<div class="pull-left">
									<!-- <h4 class="title"><span class="fa fa-user"></span> Users</h4> -->
								</div>
								<div class="pull-right">
									<a href="{{ url('administrators/new') }}"><button class="btn btn-info btn-simple btn-xs" type="button" rel="tooltip" title="" data-original-title="New admin"><i class="fa fa-plus fa-2x"></i></button></a>
								</div>
							</div>
							<div class="content table-responsive table-full-width">
							@if(!count($admins))
								<div class="card-body">
									<p class="text-warning"><span class="fa fa-exclamation-circle"></span> <strong>No data found.</strong></p>
								</div>
							@else
								<table class="table table-hover">
									<thead>
										<th>ID</th>
										<th>Name</th>
										<th>Region</th>
										<th>Role</th>
										<th class="text-right"></th>
									</thead>
									<tbody>
										@foreach($admins as $key => $admin)
										<tr>
											<td>{{ ($admins->currentpage() - 1) * $admins->perpage() + $key + 1 }}</td>
											<td>{{ $admin->u_fname }} {{ $admin->u_mname }} {{ $admin->u_lname }} </td>
											<td>{{ $admin->region->rg_name }}</td>
											<td>{{ $admin->role->r_name }}</td>
											<td class="text-right">
												<a href="{{ url('administrators/update/'.$admin->u_id) }}"><button class="btn btn-info btn-simple btn-xs" type="button" rel="tooltip" title="" data-original-title="Update"><i class="fa fa-edit fa-lg"></i></button></a>
											</td>
										</tr>
										@endforeach
									</tbody>
								</table>
								@if($admins->render())
									<div class="text-center">{!! $admins->render() !!}</div>
								@endif
							@endif
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	@stop