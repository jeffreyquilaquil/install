@extends('layouts.admin_content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="header clearfix">
								<div class="pull-left">
									<h4 class="title"><a href="{{ url('administrators') }}" class="text-info"><span class="fa fa-users"></span> Users</a> | {{ $option }}</h4> 
								</div>
							</div>
							<div class="content">
								{!! Form::model($user, ['url' => 'administrators/save/'.$id, 'autocomplete' => 'off', 'files' => 'true']) !!}
									<br>
									<div class="row">
										<div class="col-md-4">
											<label>First Name <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('u_fname') }}</strong></span></label>
											{!! Form::text('u_fname', NULL, ['class' => 'form-control', 'placeholder' => 'First Name']) !!}
										</div>
										<div class="col-md-4">
											<label>Middle Name <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('u_mname') }}</strong></span></label>
											{!! Form::text('u_mname', NULL, ['class' => 'form-control', 'placeholder' => 'Middle Name']) !!}
										</div>
										<div class="col-md-4">
											<label>Last Name <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('u_lname') }}</strong></span></label>
											{!! Form::text('u_lname', NULL, ['class' => 'form-control', 'placeholder' => 'Last Name']) !!}
										</div>
									</div>
									<br>
									<div class="row">
										<div class="col-md-4">
											<label class="text-nowrap">Username <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('u_username') }}</strong></span></label>
											{!! Form::text('u_username', NULL, ['class' => 'form-control', 'placeholder' => 'Username']) !!}
										</div>
										<div class="col-md-4">
											<label>Password <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('u_password') }}</strong></span></label>
											{!! Form::password('u_password', ['class' => 'form-control', 'placeholder' => 'Password']) !!}
										</div>
										<div class="col-md-4">
											<label>Designation </label>
											{!! Form::text('u_position', NULL, ['class' => 'form-control', 'placeholder' => 'Designation']) !!}
										</div>
									</div>
									<br>
									<div class="row">
										<div class="col-md-4">
											<label>Region <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('rg_id') }}</strong></span></label>
											{!! Form::select('rg_id', $regions, NULL, ['class' => 'form-control', 'placeholder' => 'Select Region']) !!}
										</div>
										<div class="col-md-4">
											<label>Role <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('r_id') }}</strong></span></label>
											{!! Form::select('r_id', $roles, NULL, ['class' => 'form-control', 'placeholder' => 'Select Role']) !!}
										</div>
										<div class="col-md-4">
											<label>Status </label>
											{!! Form::select('is_active', array('1' => 'Active', '0' => 'Inactive'), NULL, ['class' => 'form-control']) !!}
										</div>
									</div>
									<br>
									<div class="row">
										<div class="col-md-12">
											{!! Form::submit('Save', ['class' => 'btn btn-info btn-fill text-center pull-right']) !!}
										</div>
									</div>
								{!! Form::close() !!}
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	@stop