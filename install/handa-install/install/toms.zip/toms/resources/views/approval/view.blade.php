@extends('layouts.content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-content">
								<h4><a href="{{ url('approval') }}">For Approval</a> | {{ $option }}</h4>
								<br>
								{!! Form::model($travel, ['url' => '', 'autocomplete' => 'off']) !!}
									<div class="row">
										<div class="input-daterange">
											<div class="col-md-4">
												<label>Start Date: </label>
												<label class="text-primary"><strong>{{ format_date($travel->t_start_date) }}</strong></label>
											</div>
											<div class="col-md-4">
												<label>End Date: </label>
												<label class="text-primary"><strong>{{ format_date($travel->t_end_date) }}</strong></label>
											</div>
										</div>
										<div class="col-md-4">
											<label>Time of Departure: </label>
											<label class="text-primary"><strong>{{ $travel->t_time }}</strong></label>
										</div>
									</div>
									<br>
									<div class="row">
										<div class="col-md-6">
											<label>Destination: </label>
											<label class="text-primary"><strong>{{ $travel->t_destination }}</strong></label>
										</div>
										<div class="col-md-6">
											<label>Mode of Travel: </label>
											<label class="text-primary"><strong>{{ $travel->mode->m_name }}</strong></label>
										</div>
									</div>
									<br>
									<div class="row">
										<div class="col-md-12">
											<div><label>Employee/s: </label></div>
											@foreach($travel->passengers as $user)
												<span class="passenger-container">
													<label {!! $user->r_id == 5 || $user->r_id == 6 || $user->r_id == 7 ? 'class="label label-success text-white custom-label"' : 'class="label label-warning text-white"' !!}><strong><small>{{ $user->u_fname }} {{ format_middle_name($user->u_mname) }} {{ $user->u_lname }}</small></strong></label>
												</span>
											@endforeach
										</div>
									</div>
									<br>
									<div class="row">
										<div class="col-md-6">
											<label>Purpose: </label>
											<label class="text-primary"><strong>{{ $travel->t_purpose }}</strong></label>
										</div>
										<div class="col-md-6">
											<label>Remarks</label>
											<label class="text-danger"><strong>{{ $travel->t_remarks }}</strong></label>
										</div>
									</div>
									<br>
									<div class="row">
										<div class="col-md-3">
											<label>Travel Documents: </label>
											@foreach($travel->files as $document)
												<div><a href="{{ url('view/'.$document->td_id) }}" target="_blank">{!! $document->td_path !!}</a></div>
											@endforeach
										</div>
									</div>
									<br>
									<div class="row">
										<div class="col-md-3">
											<label>Travel Expenses to be incurred</label>
										</div>
										<div class="col-md-9 text-center">
											<label>Appropriate/Fund to which travel expenses would be charged to:</label>
										</div>
									</div>
									<br>
									<table width="100%">
										<thead>
											<tr>
												<th width="30%">&nbsp</th>
												<th width="23%" class="text-center">(@if(in_array('1', $funds))<span class="fa fa-check"></span>@else &nbsp @endif) General Fund</th>
												<th width="23%" class="text-center">(@if(in_array('2', $funds))<span class="fa fa-check"></span>@else &nbsp @endif) Project Funds</th>
												<th width="23%" class="text-center">(@if(in_array('3', $funds))<span class="fa fa-check"></span>@else &nbsp @endif) Others</th>
											</tr>
										</thead>
									</table>
									<table width="100%">
										@foreach($expenses as $key => $expense)
											@if($key == 0)
												<tr>
													<th>Actual</th>
												</tr>
											@elseif($key == 3)
												<tr>
													<th>Per Diem</th>
												</tr>
											@endif
											<tr>
												<td width="30%">{!! $expense->e_name !!}</td>
												<td width="23%" class="text-center">
													@foreach($travel->expenses as $ex)
														@if($ex->pivot->f_id == 1 && $ex->e_id == $expense->e_id)
															<span class="fa fa-check"></span>
														@endif
													@endforeach
													&nbsp
												</td>
												<td width="23%" class="text-center">
													@foreach($travel->expenses as $ex)
														@if($ex->pivot->f_id == 2 && $ex->e_id == $expense->e_id)
															<span class="fa fa-check"></span>
														@endif
													@endforeach
													&nbsp
												</td>
												<td width="23%" class="text-center">
													@foreach($travel->expenses as $ex)
														@if($ex->pivot->f_id == 3 && $ex->e_id == $expense->e_id)
															{!! $ex->pivot->tfe_others !!}
														@endif
													@endforeach
													&nbsp
												</td>
											</tr>
										@endforeach
									</table>
									<br>
								{!! Form::close() !!}
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-content">
								<h5>Comments</h5>
								{!! Form::open(['url' => 'approval/save/'.$id, 'autocomplete' => 'off']) !!}
									<div class="row">
										<div class="col-md-12">
											{!! Form::textarea('tc_comment', NULL, ['class' => 'form-control', 'placeholder' => 'Leave your comments here', 'size' => '10x5']) !!}
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											<div class="pull-right">
												{!! Form::button('<i class="material-icons">check</i>', ['class' => 'btn btn-primary btn-fill text-center', 'name' => 'action', 'value' => '1', 'title' => 'Approve', 'type' => 'submit']) !!}
												{!! Form::button('<i class="material-icons">clear</i>', ['class' => 'btn btn-danger btn-fill text-center', 'name' => 'action', 'value' => '0',  'title' => 'Disapprove', 'type' => 'submit']) !!}
											</div>
										</div>
									</div>
								{!! Form::close() !!}
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	@stop