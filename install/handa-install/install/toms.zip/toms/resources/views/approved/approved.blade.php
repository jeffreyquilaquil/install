@extends('layouts.content')
	@section('content')
        <div class="content">
            <div class="container-fluid">
            	<div class="row">
            		<div class="col-md-12">
            			<div class="card">
                            <div class="card-content table-responsive">
                            @if(!count($travels))
                                <div class="card-body">
                                    <h4>Approved</h4>
                                    <h4><small class="text-danger"><strong><span class="fa fa-exclamation-circle"></span> No data found.</strong></small></h4>
                                </div>
                            @else
                                <table class="table table-hover">
                                    <thead>
                                        <th class="text-left text-nowrap">ID</th>
                                        <th class="text-nowrap">Created By</th>
                                        <th class="text-nowrap">Destination</th>
                                        <th class="text-nowrap">Purpose</th>
                                        <th class="text-center text-nowrap">Employee/s</th>
                                        <th class="text-nowrap text-center">Date of Travel</th>
                                        <th class="text-nowrap text-center">Date/Time Updated</th>
                                        <th class="text-nowrap"></th>
                                    </thead>
                                    <tbody>
                                        @foreach($travels as $key => $travel)
                                        <tr>
                                            <td class="text-left text-nowrap">{{ ($travels->currentpage() - 1) * $travels->perpage() + $key + 1 }}</td>
                                            <td class="text-nowrap">{!! $travel->user->u_fname !!} {!! format_middle_name($travel->user->u_mname) !!} {!! $travel->user->u_lname !!}</td>
                                            <td>{!! nl2br($travel->t_destination) !!}</td>
                                            <td>{!! nl2br($travel->t_purpose) !!}</td>
                                            <td class="text-center">{{ count($travel->passengers) }}</td>
                                            <td class="text-nowrap text-center">{!! $travel->t_start_date == $travel->t_end_date ? format_date($travel->t_start_date) : format_date($travel->t_start_date)."<br>".format_date($travel->t_end_date) !!}</td>
                                            <td class="text-nowrap text-center">{{ get_date_diff($travel->updated_at) }}</td>
                                            <td class="text-right text-nowrap">
                                                <a href="{{ url('approved/view/'.$travel->t_id) }}"><button class="btn btn-primary btn-simple btn-xs" type="button" rel="tooltip" data-original-title="View"><i class="fa fa-eye fa-lg"></i></button></a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                @if($travels->render())
                                    <div class="text-center">{!! $travels->render() !!}</div>
                                @endif
                            @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @stop