@extends('layouts.content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-content table-responsive">
								{!! Form::open(['url' => 'archive/search', 'class' => 'navbar-form', 'role' => 'search']) !!}
									<div class="form-group is-empty">
										{!! Form::text('search', NULL, ['class' => 'form-control', 'placeholder' => 'Search', 'required']) !!}
			                        	<span class="material-input"></span>
									</div>
									<button type="submit" class="btn btn-white btn-round btn-just-icon">
										<i class="material-icons">search</i><div class="ripple-container"></div>
									</button>
								{!! Form::close() !!}
							@if(!count($archives))
								<div class="card-body">
									<h4><small class="text-danger"><strong><span class="fa fa-exclamation-circle"></span> No data found.</strong></small></h4>
								</div>
							@else
								<table class="table">
									<thead>
										<th>ID</th>
										<th>Name</th>
										<th>Designation</th>
										<th>Role</th>
										<th class="text-right"></th>
									</thead>
									<tbody>
										@foreach($archives as $key => $user)
										<tr>
											<td>{{ ($archives->currentpage() - 1) * $archives->perpage() + $key + 1 }}</td>
											<td>{{ $user->u_lname }}, {{ $user->u_fname }} {{ format_middle_name($user->u_mname) }}</td>
											<td>{{ $user->u_position }}</td>
											<td>{{ $user->role->r_name }}</td>
											<td class="text-right">
												<a href="{{ url('archive/view/'.$user->u_id) }}"><button class="btn btn-info btn-simple btn-xs" type="button" rel="tooltip" title="" data-original-title="View"><i class="fa fa-eye fa-lg"></i></button></a>
											</td>
										</tr>
										@endforeach
									</tbody>
								</table>
								@if($archives->render())
									<div class="text-center">{!! $archives->render() !!}</div>
								@endif
							@endif
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	@stop