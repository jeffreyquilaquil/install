@extends('layouts.content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						
						<div class="card">
							<div class="card-content table-responsive">
							@if(!count($travels))
								<div class="card-body">
									<h4><a href="{{ url('archive') }}">Archive</a> | {{ $user->u_lname }} {{ format_middle_name($user->u_mname) }} {{ $user->u_fname }}</h4>
									<h4><small class="text-danger"><strong><span class="fa fa-exclamation-circle"></span> No data found.</strong></small></h4>
								</div>
							@else
								<h4><a href="{{ url('archive') }}">Archive</a> | {{ $user->u_lname }} {{ format_middle_name($user->u_mname) }} {{ $user->u_fname }}</h4>
								<table class="table">
									<thead>
										<th class="text-left text-nowrap">ID</th>
                                        <th>Destination</th>
                                        <th class="text-nowrap">Purpose</th>
                                        <th class="text-nowrap">Date of Travel</th>
                                        <th class="text-nowrap text-center">Date/Time Updated</th>
                                        <th class="text-nowrap text-center">Status</th>
                                        <th clas="text-right"></th>
									</thead>
									<tbody>
										@foreach($travels as $key => $travel)
										<tr>
                                            <td>{{ ($travels->currentpage() - 1) * $travels->perpage() + $key + 1 }}
                                                @if($travel->u_id == Auth::user()->u_id)
                                                    <span class="fa fa-check text-success" rel="tooltip" data-original-title="Created by you"></span>
                                                @else
                                                    <span class="fa fa-user text-warning" rel="tooltip" data-original-title="Created by {{ create_initials($travel->user->u_fname, $travel->user->u_mname, $travel->user->u_lname) }}"></span>
                                                @endif
                                            </td>
                                            <td>{!! $travel->t_destination !!}</td>
                                            <td>{!! nl2br($travel->t_purpose) !!}</td>
                                            <td class="text-nowrap">{!! $travel->t_start_date == $travel->t_end_date ? format_date($travel->t_start_date) : format_date($travel->t_start_date)."<br>".format_date($travel->t_end_date) !!}</td>
                                            <td class="text-nowrap text-center">{{ get_date_diff($travel->updated_at) }}</td>
                                            <td class="text-nowrap text-center">
                                            @if(Auth::user()->r_id == 7)
                                                @if($travel->to_recommending == 2 || $travel->to_approval == 2)
                                                    <i class="fa fa-times text-danger" rel="tooltip" data-original-title="Disapproved"></i>
                                                @elseif($travel->to_recommending == 1 && $travel->to_approval == 1)
                                                    <i class="fa fa-check text-success" rel="tooltip" data-original-title="Approved"></i>
                                                @else
                                                    <i class="fa fa-hourglass text-warning" rel="tooltip" data-original-title="Pending"></i>
                                                @endif
                                            @else
                                                @if($travel->to_approval == 2)
                                                    <i class="fa fa-times text-danger" rel="tooltip" data-original-title="Disapproved"></i>
                                                @elseif($travel->to_approval == 1)
                                                    <i class="fa fa-check text-success" rel="tooltip" data-original-title="Approved"></i>
                                                @else
                                                    <i class="fa fa-hourglass text-warning" rel="tooltip" data-original-title="Pending"></i>
                                                @endif
                                            @endif
                                            </td>
                                            <td class="text-right"><a href="{{ url('pdf/'.$travel->t_id) }}" target="_blank"><button class="btn btn-info btn-simple btn-xs" type="button" rel="tooltip" data-original-title="Print"><i class="fa fa-print fa-lg"></i></button></a></td>     
                                        </tr>
										@endforeach
									</tbody>
								</table>
								@if($travels->render())
									<div class="text-center">{!! $travels->render() !!}</div>
								@endif
							@endif
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	@stop