@extends('layouts.content')
    @section('content')
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-content">
                                {!! Form::model($travel, ['url' => '', 'autocomplete' => 'off']) !!}
                                    <h4><a href="{{ url('disapproved') }}">Disapproved</a> | {{ $option }}</h4>
                                    <br>
                                    <div class="row">
                                        <div class="input-daterange">
                                            <div class="col-md-4">
                                                <label>Start Date: </label>
                                                <label class="text-primary"><strong>{{ format_date($travel->t_start_date) }}</strong></label>
                                            </div>
                                            <div class="col-md-4">
                                                <label>End Date: </label>
                                                <label class="text-primary"><strong>{{ format_date($travel->t_end_date) }}</strong></label>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <label>Time of Departure: </label>
                                            <label class="text-primary"><strong>{{ $travel->t_time }}</strong></label>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Destination: </label>
                                            <label class="text-primary"><strong>{{ $travel->t_destination }}</strong></label>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Mode of Travel: </label>
                                            <label class="text-primary"><strong>{{ $travel->mode->m_name }}</strong></label>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div><label>Employee/s: </label></div>
                                            @foreach($travel->passengers as $user)
                                                <span class="passenger-container">
                                                    <label {!! $user->r_id == 5 || $user->r_id == 6 || $user->r_id == 7 ? 'class="label label-success text-white custom-label"' : 'class="label label-warning text-white"' !!}><strong><small>{{ $user->u_fname }} {{ format_middle_name($user->u_mname) }} {{ $user->u_lname }}</small></strong></label>
                                                </span>
                                            @endforeach
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Purpose: </label>
                                            <label class="text-primary"><strong>{{ $travel->t_purpose }}</strong></label>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Remarks</label>
                                            <label class="text-danger"><strong>{{ $travel->t_remarks }}</strong></label>
                                        </div>
                                    </div>
                                {!! Form::close() !!}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-content">
                                <h5>Comments</h5>
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        @if(!count($comments))
                                            <div class="comment-container">
                                            <br><br>
                                            </div>
                                        @else
                                            @foreach($comments as $comment)
                                                <div class="row">
                                                    <div class="col-md-1">
                                                        <img class="img-circle img-responsive img-comment" src="{{ $comment->user->u_image == '' ? asset('images/blank-profile.jpg') : asset(''.$comment->user->u_image) }}">
                                                    </div>
                                                    <div class="col-md-11">
                                                        <p>
                                                            <label class="text-info"><strong>{!! $comment->user->u_fname !!} {!! format_middle_name($comment->user->u_mname) !!} {!! $comment->user->u_lname !!}</strong></label><br>
                                                            {!! nl2br($comment->tc_comment) !!}<br>
                                                            <label><small>{{ get_date_diff($comment->created_at) }}</small></label><br>
                                                        </p>
                                                    </div>
                                                </div>
                                            @endforeach
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @stop