@extends('layouts.content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-6">
						<div class="card">
							<div class="card-content">
								<h4><a href="{{ url('groups') }}">Groups</a> | {{ $option }}</h4>
								{!! Form::model($group, ['url' => 'groups/save/'.$id, 'autocomplete' => 'off']) !!}
								{!! Form::hidden('option', $option) !!}
								<div class="row">
									<div class="col-md-12">
										<div class="form-group label-floating">
											<label class="control-label">Group Name <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('g_name') }}</strong></span></label>
											{!! Form::text('g_name', NULL, ['class' => 'form-control', 'required', $option == 'View' ? 'disabled' : '']) !!}
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="form-group label-floating">
											<label class="label-floating">Division <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('d_id') }}</strong></span></label>
											{!! Form::select('d_id', $division, NULL, ['class' => 'form-control', 'required', $option == 'View' ? 'disabled' : '']) !!}
										</div>
									</div>
								</div>
								@if($option == 'View')
								<div class="row">
									<div class="col-md-12">
										<div><label>Members</label></div>
										@foreach($group->users as $user)
											<span class="passenger-container">
												<label class="label label-success text-white custom-label"><strong><small>{{ $user->u_fname }} {{ format_middle_name($user->u_mname) }} {{ $user->u_lname }}</small></strong></label>
											</span>
										@endforeach
									</div>
								</div>
								@endif
								@if($option != 'View')
								<div class="row">
									<div class="col-md-12">
										{!! Form::button('<i class="material-icons">check</i> Save', ['class' => 'btn btn-primary btn-fill text-center pull-right', 'type' => 'submit']) !!}
									</div>
								</div>
								@endif
								{!! Form::close() !!}
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	@stop