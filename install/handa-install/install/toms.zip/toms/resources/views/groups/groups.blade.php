@extends('layouts.content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-content table-responsive">
							@if(!count($groups))
								<div class="card-body">
									<h4><small class="text-danger"><strong><span class="fa fa-exclamation-circle"></span> No data found.</strong></small></h4>
								</div>
							@else
								<table class="table">
									<thead>
										<th>ID</th>
										<th>Group Name</th>
										<th>Division</th>
										<th class="text-center">Members</th>
										<th class="text-right"></th>
									</thead>
									<tbody>
										@foreach($groups as $group)
										<tr>
											<td>{{ $group->g_id }}</td>
											<td>{{ $group->g_name }}</td>
											<td>{{ $group->division->d_name }}</td>
											<td class="text-center">{{ count($group->users) }}</td>
											<td class="text-right">
												<a href="{{ url('groups/view/'.$group->g_id) }}"><button class="btn btn-primary btn-simple btn-xs" type="button" rel="tooltip" title="" data-original-title="View"><i class="fa fa-eye fa-lg"></i></button></a>
												<a href="{{ url('groups/update/'.$group->g_id) }}"><button class="btn btn-info btn-simple btn-xs" type="button" rel="tooltip" title="" data-original-title="Update"><i class="fa fa-edit fa-lg"></i></button></a>
											</td>
										</tr>
										@endforeach
									</tbody>
								</table>
								@if($groups->render())
									<div class="text-center">{!! $groups->render() !!}</div>
								@endif
							@endif
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	@stop
    <div id="container-floating">
        <a href="{{ url('groups/new') }}">
            <div id="floating-button">
                <p class="plus">+</p>
            </div>    
        </a>
    </div>