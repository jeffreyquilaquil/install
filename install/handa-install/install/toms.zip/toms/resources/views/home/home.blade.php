@extends('layouts.content')
	@section('content')
		<link rel="stylesheet" href="{{ asset('extensions/fullcalendar/fullcalendar.css') }}" type="text/css">

        <div class="content">
            <div class="container-fluid">
            	<div class="row">
            		<div class="col-md-12">
	            		{!! $calendar->calendar() !!}
						{!! $calendar->script() !!}
            		</div>
            	</div>
            </div>
        </div>

        <div id="calendarModal" class="modal fade">
			<div class="modal-dialog">
			    <div class="modal-content">
			        <div class="modal-header">
			            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span> <span class="sr-only">close</span></button>
			            <h4 id="modalTitle" class="modal-title"></h4>
			        </div>
			        <div id="modalBody" class="modal-body"></div>
			    </div>
			</div>
        </div>

        <script type="text/javascript">
        	$(document).ready(function() {
        		$('.modal').appendTo("body");
        	});
        </script>
        <script src="{{ asset('extensions/fullcalendar/lib/moment.min.js') }}"></script>
    	<script src="{{ asset('extensions/fullcalendar/fullcalendar.js') }}"></script>
	@stop