<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<link rel="icon" href="{{ asset('images/vrams.jpg') }}" type="image/x-icon">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

	<title>TOMS | {{ $data['page'] }}</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>

    <!-- CSS -->
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/bootstrap/css/bootstrap.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/font-awesome/css/font-awesome.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/template/css/animate.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/template/css/light-bootstrap-dashboard.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/template/css/demo.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/template/css/pe-icon-7-stroke.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/main.css') }}">
    <script type="text/javascript" src="{{ asset('extensions/jquery/jquery.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('extensions/bootstrap/js/bootstrap.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('extensions/template/js/light-bootstrap-dashboard.js') }}"></script>

</head>
<body>

<!-- data-color= blue | azure | green | orange | red | purple -->

        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <span class="navbar-brand">{{ Auth::user()->u_fname }} {{ format_middle_name(Auth::user()->u_mname) }} {{ Auth::user()->u_lname }}</span>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">

                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="{{ url('administrators') }}"><span class="fa fa-users"></span> Users</a></li>
                        <li><a href="{{ url('logout') }}"><span class="fa fa-sign-out fa-fw"></span> Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        @if(Session::has('message'))
            <br>
            <div class="container-fluid">
                <div class="alert {{ Session::get('alert_type') }} fade in custom-alert">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong><span class="fa fa-exclamation-circle"></span> {{ Session::get('message') }}</strong>
                </div>
            </div>
        @endif

        <script type="text/javascript">
            $(".alert").fadeTo(2000, 500).slideUp(500, function(){
                $(".alert").slideUp(500);
            });
        </script>
