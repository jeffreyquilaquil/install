        <footer class="footer">
            <div class="container-fluid">
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> <a href="http://www.dost.gov.ph/" target="_blank">Department of Science and Technology.</a>
                </p>
            </div>
        </footer>
    </div>
</div>
</body>
</html>
