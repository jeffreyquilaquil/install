<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<link rel="icon" href="{{ asset('images/vrams.jpg') }}" type="image/x-icon">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>TOMS | {{ $data['page'] }}</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>

    <!-- Bootstrap CSS -->
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/material/css/bootstrap.min.css') }}">

    <!-- Material Dashboard CSS -->
    <link rel="stylesheet" type="text/css" href="{{ asset('extensions/material/css/material-dashboard.css') }}">

    <!-- Fonts and icons -->
    <link rel="stylesheet" type="text/css" href="{{ asset('extensions/font-awesome/css/font-awesome.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('extensions/fonts/fonts.css') }}">

    <!-- Main CSS -->
    <link rel="stylesheet" type="text/css" href="{{ asset('css/main.css') }}">
    
    <!-- Core JS Files -->
    <script type="text/javascript" src="{{ asset('extensions/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('extensions/material/js/bootstrap.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('extensions/material/js/material.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('extensions/material/js/material-dashboard.js') }}"></script>

</head>
<body>

<!-- data-color= blue | azure | green | orange | red | purple -->
<div class="wrapper">
    <div class="sidebar" data-color="blue">
        <div class="logo">
            <a href="" class="simple-text">TOMS</a>
        </div>
    	<div class="sidebar-wrapper">
            <ul class="nav">
                <li {{(Request::is('home') ? 'class=active' : '')}}>
                    <a href="{{ url('home') }}">
                        <i class="material-icons">home</i>
                        <p>Home</p>
                    </a>
                </li>
                @if(Auth::user()->r_id == 2)
                <li {{(Request::is('users') || (Request::is('users/new')) || (Request::is('users/search')) || (Request::is('users/update/'.Request::segment(3))) ? 'class=active' : '')}}>
                    <a href="{{ url('users') }}">
                        <i class="material-icons">people</i>
                        <p>Users</p>
                    </a>
                </li>
                <li {{(Request::is('groups') || (Request::is('groups/new')) || (Request::is('groups/update/'.Request::segment(3))) || (Request::is('groups/view/'.Request::segment(3))) ? 'class=active' : '')}}>
                    <a href="{{ url('groups') }}">
                        <i class="fa fa-users fa-fw"></i>
                        <p>Groups</p>
                    </a>
                </li>
                <li {{(Request::is('settings') || (Request::is('settings/update/'.Request::segment(3))) || (Request::is('settings/new')) ? 'class=active' : '')}}>
                    <a href="{{ url('settings') }}">
                        <i class="material-icons">build</i>
                        <p>Settings</p>
                    </a>
                </li>
                @endif
                @if(Auth::user()->r_id >= 3)
                <li {{(Request::is('travels') || (Request::is('travels/new')) || (Request::is('travels/update/'.Request::segment(3))) || (Request::is('travels/view/'.Request::segment(3))) ? 'class=active' : '')}}>
                    <a href="{{ url('travels') }}">
                        <i class="material-icons">card_travel</i>
                        <p>Travel Order</p>
                    </a>
                </li>
                @endif
                @if(get_group_heads(Auth::user()->u_id))
                <li {{(Request::is('approval') || (Request::is('approval/view/'.Request::segment(3))) ? 'class=active' : '')}}>
                    <a href="{{ url('approval') }}">
                        <i class="material-icons">playlist_add_check</i>
                        <p>For Approval</p>
                    </a>
                </li>
                <li {{(Request::is('approved') || (Request::is('approved/view/'.Request::segment(3))) ? 'class=active' : '')}}>
                    <a href="{{ url('approved') }}">
                        <i class="material-icons">check</i>
                        <p>Approved</p>
                    </a>
                </li>
                <li {{(Request::is('disapproved') || (Request::is('disapproved/view/'.Request::segment(3))) ? 'class=active' : '')}}>
                    <a href="{{ url('disapproved') }}">
                        <i class="material-icons">clear</i>
                        <p>Disapproved</p>
                    </a>
                </li>
                @endif
                @if(Auth::user()->r_id == 8)
                <li {{(Request::is('archive/search')) || (Request::is('archive')) || (Request::is('archive/view/'.Request::segment(3))) ? 'class=active' : ''}}>
                    <a href="{{ url('archive') }}">
                        <i class="material-icons">folder_shared</i>
                        <p>Travel Order Archives</p>
                    </a>
                </li>
                @endif
                <li class="active-pro">
                    <a href="{{ url('logout') }}">
                        <i class="material-icons">power_settings_new</i>
                        <p>Logout</p>
                    </a>
                </li>
            </ul>
    	</div>
    </div>
    <div class="main-panel">
        <nav class="navbar navbar-transparent navbar-absolute">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <span class="navbar-brand">{{ Auth::user()->u_fname }} {{ format_middle_name(Auth::user()->u_mname) }} {{ Auth::user()->u_lname }}</span>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="material-icons">notifications</i>
                                @if(get_notifications()['total'] != 0)<span class="notification">{{ get_notifications()['total'] }}</span>@endif
                                <p class="hidden-lg hidden-md">Notifications</p>
                            </a>
                            <ul class="dropdown-menu">
                                @if(get_notifications()['travel'] != 0) <li><a href="{{ url('travels') }}">{{ get_notifications()['travel'] }} new travel order</a></li> @endif
                                @if(get_notifications()['pending'] != 0) <li><a href="{{ url('approval') }}">{{ get_notifications()['pending'] }} new pending travel order</a></li> @endif
                            </ul>
                        </li>
                        <li>
                            <a href="{{ url('profile') }}">
                               <i class="material-icons">person</i>
                               <p class="hidden-lg hidden-md">Profile</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        @if(Session::has('message'))
            <div id="message">
                <div class="container">
                    <div class="alert {{ Session::get('alert_type') }}">
                        <div class="alert-icon">
                            <i class="material-icons">check</i>
                        </div>
                        <b>{{ Session::get('message') }}</b>
                    </div>
                </div>
            </div>
        @endif
        <script type="text/javascript">
            $(".alert").fadeTo(2000, 500).slideUp(500, function(){
                $(".alert").slideUp(500);
            });
        </script>