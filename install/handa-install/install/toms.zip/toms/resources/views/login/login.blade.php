<!DOCTYPE html>
<html lang="en">
<html>
<head>
	<meta charset="utf-8">
	<link rel="icon" href="{{ asset('images/vrams.jpg') }}" type="image/x-icon">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/bootstrap/css/bootstrap.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/font-awesome/css/font-awesome.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('css/roboto.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('css/login.css') }}">
</head>
<body>
	<div id="outter-wrapper">
		<div class="centering-container">
		    <div class="centering-content">
		        <div class="centering-horizontal">
		            <div class="jumbotron">
		                <h1><span style="font-family:vroom;"><a href="#" class="not-active" title="VROOM">&#xE600;</a></span><a href="#" class="not-active" title="VROOM">&nbspTOMS</a></h1>
		                <div id="pace-target"></div>
		                <h4>Travel Order Management System</h4>
		                <p>
							<div class="panel panel-default signin-form">
								<div class="panel-heading text-center">
							        <h4>Please sign-in</h4>
							    </div>
							    <div class="panel-body">
							    	{!! Form::open(['url' => 'login', 'class' => 'form', 'autocomplete' => 'off']) !!}
							            <div class="text-danger text-center"><strong>{{ $error_message }}</strong></div><br>
										<div class="form-group{{ ($errors->has('username') ? ' has-error' : '') }} has-feedback">
											<div class="input-group">
												<span class="input-group-addon">Username</span>
												{!! Form::text('username', NULL, ['class' => 'form-control', 'placeholder' => 'Username', 'required', 'maxlength' => '255']) !!}
											</div>
										</div>
										<div class="form-group{{ ($errors->has('password') ? ' has-error' : '') }} has-feedback">
											<div class="input-group">
												<span class="input-group-addon">Password</span>
												{!! Form::password('password', ['class' => 'form-control', 'placeholder' => 'Password', 'required', 'maxlength' => '255']) !!}
											</div>
										</div>
										<div class="form-group">
											{!! Form::submit('Sign-in', ['class' => 'btn btn-primary btn-block']) !!}
										</div>
									{!! Form::close() !!}
							    </div>
							</div>
		                </p>
		            </div>
		        </div>
		    </div>
		</div>
	</div>
	<!-- <div id="background"><img src="{{ asset('images/bg.jpg') }}"></div> -->
	<div class="footer-wrapper">
	    <footer id="footer">
	        <div class="container-fluid clearfix">
	            <span class="pull-left footer-text"><small>&copy; {{ date('Y') }}. TOMS. All Rights Reserved</small></span>
	            <span class="pull-right footer-text"><a href="http://region4a.dost.gov.ph/"><small>Developed by Department of Science and Technology - Region 4A · MIS Unit</small></a></span>
	        </div>
	    </footer>
	</div>
</body>