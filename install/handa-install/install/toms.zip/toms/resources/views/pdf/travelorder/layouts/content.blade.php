@include('pdf.travelorder.layouts.header')
@yield('content')
@include('pdf.travelorder.layouts.footer')