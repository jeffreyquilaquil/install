<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Travel Order</title>
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/bootstrap/css/bootstrap.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('extensions/font-awesome/css/font-awesome.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('css/travelorder.css') }}">
</head>
<body>
	<div class="text-center">
		<img class="align-img" src="{{ asset('images/DOST.png') }}" width="50" height="50"> <span><strong>DEPARTMENT OF SCIENCE AND TECHNOLOGY</strong></span>
	</div>
	<br>
	<table width="100%">
		<tr>
			<td class="text-left">LOCAL TRAVEL ORDER NO. {!! Carbon\Carbon::parse($travel->created_at)->format('Y') !!}-{!! $travel->t_id !!}</td>
			<td class="text-right">{!! Carbon\Carbon::parse($travel->created_at)->format('F d, Y') !!}</td>
		</tr>
		<tr>
			<td colspan="2">Series of {!! Carbon\Carbon::parse($travel->created_at)->format('Y') !!}</td>
		</tr>
	</table>
	<br>
	<strong>Authority to Travel is hereby granted to:</strong>
	<br><br>
	