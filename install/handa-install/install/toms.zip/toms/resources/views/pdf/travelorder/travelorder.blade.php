@extends('pdf.travelorder.layouts.content')
	@section('content')

		<table width="100%">
			<thead>
				<tr>
					<th class="text-center" width="30%">
						<p class="display-table">
						    <span class="display-cell text-center"><u>NAME</u></span>
						</p>
					</th>
					<th class="text-center" width="30%">
						<p class="display-table">
						    <span class="display-cell text-center"><u>POSITION</u></span>
						</p>
					</th>
					<th class="text-center" width="30%">
						<p class="display-table">
						    <span class="display-cell text-center"><u>DIVISION/AGENCY</u></span>
						</p>
					</th>
				</tr>
			</thead>
			<tbody>
				@foreach($travel->passengers as $user)
				<tr>
					<td class="text-center" width="30%">
						<p class="display-table">
						    <span class="display-cell underline text-nowrap">{!! $user->u_fname !!} {!! format_middle_name($user->u_mname) !!} {!! $user->u_lname !!}</span>
						</p>
					</td>
					<td class="text-center" width="30%">
						<p class="display-table text-center">
						    <span class="display-cell underline text-nowrap">{!! $user->u_position !!}</span>
						</p>
					</td>
					<td class="text-center" width="30%">
						<p class="display-table">
						    <span class="display-cell underline text-nowrap">{!! $user->u_division == '' ? '&nbsp' : $user->u_division !!}</span>
						</p>
					</td>
				</tr>
				@endforeach
			</tbody>
		</table>
		<br>
		<table width="100%">
			<thead>
				<tr>
					<th class="text-center" width="30%">
						<p class="display-table">
						    <span class="display-cell text-center"><u>DESTINATION</u></span>
						</p>
					</th>
					<th class="text-center" width="30%">
						<p class="display-table">
						    <span class="display-cell text-center"><u>Inclusive Date/s of Travel</u></span>
						</p>
					</th>
					<th class="text-center" width="30%">
						<p class="display-table">
						    <span class="display-cell text-center"><u>Purpose(s) of the Travel</u></span>
						</p>
					</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td class="text-center align-top" width="30%">
						<p class="display-table">
						    <span class="display-cell underline">{!! $travel->t_destination !!}</span>
						</p>
					</td>
					<td class="text-center align-top" width="30%">
						<p class="display-table">
						    <span class="display-cell underline text-nowrap">
						    @if($travel->t_start_date == $travel->t_end_date)
						    	{!! Carbon\Carbon::parse($travel->t_start_date)->format('F d, Y') !!}
						    @else
						    	{!! Carbon\Carbon::parse($travel->t_start_date)->format('F d, Y') !!} to {!! Carbon\Carbon::parse($travel->t_end_date)->format('F d, Y') !!}
						    @endif
						    </span>
						</p>
					</td>
					<td class="text-center align-top" width="30%">
						<p class="display-table">
						    <span class="display-cell underline">
						    	{!! $travel->t_purpose !!}
						    </span>
						</p>
					</td>
				</tr>
			</tbody>
		</table>
		<br>
		<table width="100%">
			<tr>
				<th class="text-left">Travel Expenses to be inccured</th>
				<th class="text-right">Approriate/Fund to which travel expenses would be charged to:</th>
			</tr>
		</table>
		<br>
		<table width="100%">
			<thead>
				<tr>
					<th width="30%">&nbsp</th>
					<th width="23%" class="text-center">(@if(in_array('1', $funds))<span class="fa fa-check"></span>@else &nbsp @endif) General Fund</th>
					<th width="23%" class="text-center">(@if(in_array('2', $funds))<span class="fa fa-check"></span>@else &nbsp @endif) Project Funds</th>
					<th width="23%" class="text-center">(@if(in_array('3', $funds))<span class="fa fa-check"></span>@else &nbsp @endif) Others</th>
				</tr>
			</thead>
		</table>
		<br>
		<table width="100%">
			@foreach($expenses as $key => $expense)
				@if($key == 0)
					<tr>
						<th>Actual</th>
					</tr>
				@elseif($key == 3)
					<tr>
						<th>Per Diem</th>
					</tr>
				@endif
			<tr>
				<td width="30%">{!! $expense->e_name !!}</td>
				<td width="23%" class="text-center">
					<p class="display-expense">
						<span class="display-cell underline text-nowrap">
							@foreach($travel->expenses as $ex)
								@if($ex->pivot->f_id == 1 && $ex->e_id == $expense->e_id)
									<span class="fa fa-check"></span>
								@endif
							@endforeach
							&nbsp
						</span>
					</p>
				</td>
				<td width="23%" class="text-center">
					<p class="display-expense">
						<span class="display-cell underline text-nowrap">
							@foreach($travel->expenses as $ex)
								@if($ex->pivot->f_id == 2 && $ex->e_id == $expense->e_id)
									<span class="fa fa-check"></span>
								@endif
							@endforeach
							&nbsp
						</span>
					</p>
				</td>
				<td width="23%" class="text-center">
					<p class="display-expense">
						<span class="display-cell underline text-nowrap">
							@foreach($travel->expenses as $ex)
								@if($ex->pivot->f_id == 3 && $ex->e_id == $expense->e_id)
									{!! $ex->pivot->tfe_others !!}
								@endif
							@endforeach
							&nbsp
						</span>
					</p>
				</td>
			</tr>
			@endforeach
			<tr>
				<td>&nbsp</td>
			</tr>
			<tr>
				<td class="align-top"><strong>Remarks/Special Instructions:</strong></td>
				<td colspan="3" class="underline">{!! $travel->t_remarks !!}</td>
			</tr>
		</table>
		<br><br>
		<div class="text-justify">
			<strong>
				A report of your travel must be submitted to the Agency Head/Supervising Official within 7 days completion of travel, liquidation of cash advance should be in accordance 
				with Executive Order No. 298: Rules and Regulations and New Rates of Allowances for Official Local and Foreign Travels of Government Personnel.
			</strong>
		</div>
		<br><br><br>
		<table width="100%">
			<tr>
				<td width="50%" class="align-top">
					<strong>
						<div>Recommending Approval:</div>
						@if($recommending)
							@if($travel->to_recommending == 1)
								@if($recommending->user->u_signature != NULL)
									@if(file_exists(storage_path('app/images/signature/'.$recommending->user->u_signature)))
										<img src="{{ url('image/'.$recommending->u_id) }}" alt="" width="100" height="50">
									@else
										<div class="img-height"></div>
									@endif
								@else
									<div class="img-height"></div>
								@endif
								<div>{!! $recommending->user->u_fname !!} {!! format_middle_name($recommending->user->u_mname) !!} {!! $recommending->user->u_lname !!}</div>
								<div>{!! $recommending->user->role->r_name !!}</div>
							@else
								<div class="img-height"></div>
								<div>{!! $recommending->user->u_fname !!} {!! format_middle_name($recommending->user->u_mname) !!} {!! $recommending->user->u_lname !!}</div>
								<div>{!! $recommending->user->role->r_name !!}</div>
							@endif
						@else
							<div class="img-height"></div>
						@endif
					</strong>
				</td>
				<td width="50%" class="align-top">
					<strong>
						<div>Approved:</div>
						@if($approval)
							@if($travel->to_approval == 1)
								@if($approval->user->u_signature != NULL)
									@if(file_exists(storage_path('app/images/signature/'.$approval->user->u_signature)))
										<img src="{{ url('image/'.$approval->u_id) }}" width="100" height="50">
										<div>{!! $approval->user->u_fname !!} {!! format_middle_name($approval->user->u_mname) !!} {!! $approval->user->u_lname !!}</div>
										<div>{!! $approval->user->role->r_name !!}</div>
									@else
										<div class="img-height"></div>
									@endif
								@else
									<div class="img-height"></div>
								@endif
							@else
								<div class="img-height"></div>
								<div>{!! $approval->user->u_fname !!} {!! format_middle_name($approval->user->u_mname) !!} {!! $approval->user->u_lname !!}</div>
								<div>{!! $approval->user->role->r_name !!}</div>
							@endif
						@else
							<div class="img-height"></div>
						@endif
					</strong>
				</td>
			</tr>
		</table>
	@stop