@extends('layouts.content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-8">
						<div class="card">
							<div class="card-content">
								{!! Form::model($user, ['url' => 'profile/save', 'autocomplete' => 'off', 'files' => 'true']) !!}
									<br>
									<div class="row">
										<div class="col-md-3">
											<small><span class="text-danger"><strong>{{ $errors->first('u_fname') }}</strong></span></small>
											<div class="form-group label-floating">
												<label class="control-label">First Name <span class="text-danger">*</span></label>
												{!! Form::text('u_fname', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										<div class="col-md-3">
											<small><span class="text-danger"><strong>{{ $errors->first('u_mname') }}</strong></span></small>
											<div class="form-group label-floating">	
												<label class="control-label">Middle Name <span class="text-danger">*</span></label>
												{!! Form::text('u_mname', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										<div class="col-md-3">
											<small><span class="text-danger"><strong>{{ $errors->first('u_lname') }}</strong></span></small>
											<div class="form-group label-floating">	
												<label class="control-label">Last Name <span class="text-danger">*</span></label>
												{!! Form::text('u_lname', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group label-floating">
												<label class="control-label">Prefix</label>
												{!! Form::text('u_suffix', NULL, ['class' => 'form-control']) !!}
											</div>
										</div>
									</div>
									<br>
									<div class="row">
										<div class="col-md-3">
											<small><span class="text-danger"><strong>{{ $errors->first('u_username') }}</strong></span></small>
											<div class="form-group label-floating">
												<label class="control-label">Username <span class="text-danger">*</span></label>
												{!! Form::text('u_username', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										<div class="col-md-3">
											<small><span class="text-danger"><strong>{{ $errors->first('u_password') }}</strong></span></small>
											<div class="form-group label-floating">
												<label class="control-label">Password <span class="text-danger">*</span></label>
												{!! Form::password('u_password', ['class' => 'form-control', 'required']) !!}
											</div>	
										</div>
										<div class="col-md-3">
											<small><span class="text-danger"><strong>{{ $errors->first('u_position') }}</strong></span></small>
											<div class="form-group label-floating">	
												<label class="control-label">Designation <span class="text-danger">*</span></label>
												{!! Form::text('u_position', NULL, ['class' => 'form-control', 'required']) !!}
											</div>	
										</div>
										<div class="col-md-3">
											<label class="control-label">Profile Picture <span class="text-danger"><strong>{{ $errors->first('u_image') }}</strong></span></label>
											{!! Form::file('u_image', ['id' => 'u_image']) !!}
										</div>
									</div>
									<br>
									<div class="row">
										<div class="col-md-12">
											{!! Form::submit('Update Profile', ['class' => 'btn btn-info btn-fill text-center pull-right']) !!}
										</div>
									</div>
								{!! Form::close() !!}
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="card card-profile">
							<div class="card-avatar">
								<a href="#">
									<img class="img" src="{{ Auth::user()->u_image == '' ? asset('images/blank-profile.jpg') : Auth::user()->u_image }}" id="profile-container">
								</a>
							</div>
							<div class="content">
								<div class="author">
									<h6 class="category text-gray">{{ Auth::user()->u_position }}</h6>
									<h4 class="card-title">{{ Auth::user()->u_fname }} {{ format_middle_name(Auth::user()->u_mname) }} {{ Auth::user()->u_lname }}</h4>
									<p class="card-content">
										<br><br><br>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			function readURL(input) {
				if(input.files && input.files[0]) {
					var reader = new FileReader();
					reader.onload = function(e) {
						$('#profile-container').attr('src', e.target.result);
					}
					reader.readAsDataURL(input.files[0]);
				}
			}
			$('#u_image').change(function() {
				readURL(this);
			});
		</script>
	@stop