@extends('layouts.content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-6">
						<div class="card">
							<div class="card-content">
								<h4><a href="{{ url('settings') }}">Settings</a> | {{ $option }}</h4>
								{!! Form::model($official, ['url' => 'settings/official/'.$id, 'autocomplete' => 'off']) !!}
								<div class="row">
									<div class="col-md-12">
										<div class="form-group label-floating">
											<label class="control-label">Group <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('g_id') }}</strong></span></label>
											{!! Form::select('g_id', $groups, NULL, ['class' => 'form-control', 'required']) !!}
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="form-group label-floating">
											<label class="control-label">Group Head <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('u_id') }}</strong></span></label>
											{!! Form::select('u_id', $users, NULL, ['class' => 'form-control', 'required']) !!}
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="form-group label-floating">
											<label class="control-label">Role <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('r_id') }}</strong></span></label>
											{!! Form::select('r_id', $role, NULL, ['class' => 'form-control', 'required']) !!}
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="form-group label-floating">
											<label class="control-label">Signature <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('to_approval') }}</strong></span></label>
											{!! Form::select('to_approval', $approval, NULL, ['class' => 'form-control', 'required']) !!}
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="checkbox">
											<label>
												{!! Form::hidden('oic', 0) !!}
												{!! Form::checkbox('oic', '1', NULL) !!} <b class="text-primary">Officer In Charge</b>
											</label>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										{!! Form::button('<i class="material-icons">check</i> Save', ['class' => 'btn btn-primary btn-fill text-center pull-right', 'type' => 'submit']) !!}
									</div>
								</div>
								{!! Form::close() !!}
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	@stop