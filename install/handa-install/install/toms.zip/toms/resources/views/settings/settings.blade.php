@extends('layouts.content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-content table-responsive">
							@if(!count($officials))
								<div class="card-body">
									<h4>Settings</h4>
									<h4><small class="text-danger"><strong><span class="fa fa-exclamation-circle"></span> No data found.</strong></small></h4>
								</div>
							@else
								<table class="table">
									<thead>
										<th>ID</th>
										<th>Group Name</th>
										<th>Group Head</th>
										<th>Role</th>
										<th>Signature</th>
										<th>Status</th>
										<th class="text-right"></th>
									</thead>
									<tbody>
										@foreach($officials as $official)
										<tr>
											<td>{{ $official->to_id }}</td>
											<td>{{ $official->group->g_name }}</td>
											<td>{{ $official->user->u_fname }} {{ format_middle_name($official->user->u_mname) }} {{ $official->user->u_lname }}  </td>
											<td>{{ $official->role->r_name }}</td>
											<td>@if($official->to_approval == 0) Recommending Approval @else Approval @endif</td>
											<td>@if($official->oic == 1) Officer In Charge @else Permanent @endif</td>
											<td class="text-right">
												<a href="{{ url('settings/update/'.$official->to_id) }}"><button class="btn btn-info btn-simple btn-xs" type="button" rel="tooltip" title="" data-original-title="Update"><i class="fa fa-edit fa-lg"></i></button></a>
											</td>
										</tr>
										@endforeach
									</tbody>
								</table>
							@endif
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-content">
								<h5>Travel Order Settings</h5>
								{!! Form::model($setting, ['url' => 'settings/save', 'autocomplete' => 'off']) !!}
									<div class="row">
										<div class="col-md-6">
											<div class="form-group label-floating">
												<label class="control-label">Region Name <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('s_region_name') }}</strong></span></label>
												{!! Form::text('s_region_name', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group label-floating">
												<label class="control-label">Region Address<span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('s_region_address') }}</strong></span></label>
												{!! Form::text('s_region_address', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											{!! Form::button('<i class="material-icons">check</i> Save', ['class' => 'btn btn-primary btn-fill text-center pull-right', 'type' => 'submit']) !!}
										</div>
									</div>
								{!! Form::close() !!}
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	@stop
	<div id="container-floating">
        <a href="{{ url('settings/new') }}">
            <div id="floating-button">
                <p class="plus">+</p>
            </div>    
        </a>
    </div>