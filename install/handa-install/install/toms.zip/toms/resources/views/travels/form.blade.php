@extends('layouts.content')
	@section('content')
		<link rel="stylesheet" type="text/css" href="{{ asset('extensions/chosen/chosen.min.css') }}">
		<link rel="stylesheet" type="text/css" href="{{ asset('extensions/date-picker/bootstrap-datepicker.css') }}">

		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-content">
								<h4><a href="{{ url('travels') }}">Travel Order</a> | {{ $option }}</h4>
								{!! Form::model($travel, ['url' => 'travels/save/'.$id, 'autocomplete' => 'off', 'files' => 'true', 'id' => 'travelForm']) !!}
									<div class="row">
										<div class="input-daterange">
											<div class="col-md-4">
												<small><span class="text-danger"><strong>{{ $errors->first('t_start_date') }}</strong></span></small>
												<div class="form-group label-floating">
													<label class="control-label">Start Date <span class="text-danger">*</span></label>
													{!! Form::text('t_start_date', $travel->t_start_date == null ? format_date(date('Y-m-d')) : format_date($travel->t_start_date), ['class' => 'form-control', 'maxlength' => '10', 'placeholder' => 'Start Date', 'readonly', 'required']) !!}
												</div>
											</div>
											<div class="col-md-4">
												<small><span class="text-danger"><strong>{{ $errors->first('t_end_date') }}</strong></span></small>
												<div class="form-group label-floating">
													<label class="control-label">End Date <span class="text-danger">*</span></label>
													{!! Form::text('t_end_date', $travel->t_end_date == null ? format_date(date('Y-m-d')) : format_date($travel->t_end_date), ['class' => 'form-control', 'maxlength' => '10', 'placeholder' => 'End Date', 'readonly', 'required']) !!}
												</div>
											</div>
										</div>
										<div class="col-md-4">
											<small><span class="text-danger"><strong>{{ $errors->first('t_time') }}</strong></span></small>
											<div class="form-group label-floating">
												<label class="control-label">Time of Departure <span class="text-danger">*</span></label>
												{!! Form::text('t_time', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-8">
											<small><span class="text-danger"><strong>{{ $errors->first('passengers') }}</strong></span></small>
											<div class="form-group">
												<label>Employee/s <span class="text-danger">*</span></label>
												{!! Form::select('passengers[]', $users, NULL, ['class' => 'form-control chosen-select', 'multiple', 'data-placeholder' => 'DOST Personnel']) !!}
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<small><span class="text-danger"><strong>{{ $errors->first('t_destination') }}</strong></span></small>
											<div class="form-group label-floating">
												<label class="control-label">Destination <span class="text-danger">*</span></label>
												{!! Form::text('t_destination', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										<div class="col-md-6">
											<small><span class="text-danger"><strong>{{ $errors->first('m_id') }}</strong></span></small>
											<div class="form-group label-floating">
												<label class="control-label">Mode of Travel <span class="text-danger">*</span></label>
												{!! Form::select('m_id', $modes, NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<small><span class="text-danger"><strong>{{ $errors->first('t_purpose') }}</strong></span></small>
											<div class="form-group label-floating">
												<label class="control-label">Purpose of Visit <span class="text-danger">*</span> <span class="text-danger"></label>
												{!! Form::textarea('t_purpose', NULL, ['class' => 'form-control', 'size' => '10x4', 'required']) !!}
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group label-floating">
												<label class="control-label">Remarks</label>
												{!! Form::textarea('t_remarks', NULL, ['class' => 'form-control', 'size' => '10x4']) !!}
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<small><span class="text-danger"><strong>{{ $errors->first('t_files[]') }}</strong></span></small>
											<label>Travel Documents</label>
											{!! Form::file('t_files[]', ['multiple']) !!}
										</div>
									</div>
									<br>
									<div class="row">
										<div class="col-md-3">
											<label>Travel Expenses to be incurred</label>
										</div>
										<div class="col-md-9 text-center">
											<label>Appropriate/Fund to which travel expenses would be charged to:</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-3 col-md-offset-3">
											<div class="checkbox">
												<label>
													{!! Form::checkbox('f_option', '1', NULL, ['class' => 'funds_checkbox general']) !!} <b class="label_checkbox">General Fund</b>
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label>
													{!! Form::checkbox('f_option', '2', NULL, ['class' => 'funds_checkbox project']) !!} <b class="label_checkbox">Project Funds</b>
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label>
													{!! Form::checkbox('f_option', '3', NULL, ['class' => 'funds_checkbox others']) !!} <b class="label_checkbox">Others</b>
												</label>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											<label><strong>Actual</strong></label>
										</div>
									</div>
									<div class="row chkbox_row">
										<div class="col-md-3">
											<label class="text-align">
												{!! Form::checkbox('e_id[]', 1, NULL, ['class' => 'hidden general']) !!} 
												{!! Form::checkbox('e_id[]', 1, NULL, ['class' => 'hidden project']) !!} 
												{!! Form::checkbox('e_id[]', 1, NULL, ['class' => 'hidden others']) !!}
												Accomodation
											</label>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '1', NULL, ['class' => 'funds general']) !!}
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '2', NULL, ['class' => 'funds project']) !!}
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '3', NULL, ['class' => 'funds others']) !!} {!! Form::text('tfe_others[]', NULL, ['class' => 'others-container hidden']) !!}
												</label>
											</div>
										</div>
									</div>
									<div class="row chkbox_row">
										<div class="col-md-3">
											<label class="text-align">
											{!! Form::checkbox('e_id[]', 2, NULL, ['class' => 'hidden general']) !!} 
											{!! Form::checkbox('e_id[]', 2, NULL, ['class' => 'hidden project']) !!} 
											{!! Form::checkbox('e_id[]', 2, NULL, ['class' => 'hidden others']) !!}
											Meals
											</label>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '1', NULL, ['class' => 'funds general']) !!}
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '2', NULL, ['class' => 'funds project']) !!}
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '3', NULL, ['class' => 'funds others']) !!} {!! Form::text('tfe_others[]', NULL, ['class' => 'others-container hidden']) !!}
												</label>
											</div>
										</div>
									</div>
									<div class="row chkbox_row">
										<div class="col-md-3">
											<label class="text-align">
											{!! Form::checkbox('e_id[]', 3, NULL, ['class' => 'hidden general']) !!} 
											{!! Form::checkbox('e_id[]', 3, NULL, ['class' => 'hidden project']) !!} 
											{!! Form::checkbox('e_id[]', 3, NULL, ['class' => 'hidden others']) !!}
											Incidental Expenses
											</label>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '1', NULL, ['class' => 'funds general']) !!}
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '2', NULL, ['class' => 'funds project']) !!}
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '3', NULL, ['class' => 'funds others']) !!} {!! Form::text('tfe_others[]', NULL, ['class' => 'others-container hidden']) !!}
												</label>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											<label><strong>Per Diem</strong></label>
										</div>
									</div>
									<div class="row chkbox_row">
										<div class="col-md-3">
											<label class="text-align">
											{!! Form::checkbox('e_id[]', 4, NULL, ['class' => 'hidden general']) !!} 
											{!! Form::checkbox('e_id[]', 4, NULL, ['class' => 'hidden project']) !!} 
											{!! Form::checkbox('e_id[]', 4, NULL, ['class' => 'hidden others']) !!}
											Accomodation
											</label>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '1', NULL, ['class' => 'funds general']) !!}
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '2', NULL, ['class' => 'funds project']) !!}
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '3', NULL, ['class' => 'funds others']) !!} {!! Form::text('tfe_others[]', NULL, ['class' => 'others-container hidden']) !!}
												</label>
											</div>
										</div>
									</div>
									<div class="row chkbox_row">
										<div class="col-md-3">
											<label class="text-align">
											{!! Form::checkbox('e_id[]', 5, NULL, ['class' => 'hidden general']) !!} 
											{!! Form::checkbox('e_id[]', 5, NULL, ['class' => 'hidden project']) !!} 
											{!! Form::checkbox('e_id[]', 5, NULL, ['class' => 'hidden others']) !!}
											Subsistence
											</label>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '1', NULL, ['class' => 'funds general']) !!}
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '2', NULL, ['class' => 'funds project']) !!}
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '3', NULL, ['class' => 'funds others']) !!} {!! Form::text('tfe_others[]', NULL, ['class' => 'others-container hidden']) !!}
												</label>
											</div>
										</div>
									</div>
									<div class="row chkbox_row">
										<div class="col-md-3">
											<label class="text-align">
											{!! Form::checkbox('e_id[]', 6, NULL, ['class' => 'hidden general']) !!} 
											{!! Form::checkbox('e_id[]', 6, NULL, ['class' => 'hidden project']) !!} 
											{!! Form::checkbox('e_id[]', 6, NULL, ['class' => 'hidden others']) !!}
											Incidental Expenses
											</label>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '1', NULL, ['class' => 'funds general']) !!}
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '2', NULL, ['class' => 'funds project']) !!}
												</label>
											</div>
										</div>
										<div class="col-md-3">
											<div class="checkbox">
												<label class="text-indent">
													{!! Form::checkbox('f_id[]', '3', NULL, ['class' => 'funds others']) !!} {!! Form::text('tfe_others[]', NULL, ['class' => 'others-container hidden']) !!}
												</label>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											{!! Form::button('<i class="material-icons">check</i> Save', ['class' => 'btn btn-primary btn-fill text-center pull-right', 'type' => 'submit', 'id' => 'saveBtn']) !!}
										</div>
									</div>
								{!! Form::close() !!}
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<script src="{{ asset('extensions/fullcalendar/lib/moment.min.js') }}"></script>
        <script type="text/javascript" src="{{ asset('extensions/chosen/chosen.jquery.min.js') }}"></script>
    	<script type="text/javascript" src="{{ asset('extensions/date-picker/bootstrap-datepicker.js') }}"></script>
		<script type="text/javascript">

			$('.others').click(function() {
				var container = $(this).closest('.row').find('.others-container');
				container.toggleClass('hidden');
			});


			$('#saveBtn').click(function(e) {
				e.preventDefault();
				if($('.funds:checked').length == 0) {
					alert("Please select atleast one checkbox");
					$('.text-align').addClass('text-danger');
				}
				else {
					document.getElementById('travelForm').submit();
				}
			});

			$('.funds_checkbox').click(function(e) {
				var myClass = $(this).attr('class');
				if(myClass == 'funds_checkbox general') {
					if($(this).is(':checked')) {
						$('.general').prop('checked', true);
					}
					else {
						$('.general').prop('checked', false);
					}
				}
				else if(myClass == 'funds_checkbox project') {
					if($(this).is(':checked')) {
						$('.project').prop('checked', true);
					}
					else {
						$('.project').prop('checked', false);
					}
				}
				else if(myClass == 'funds_checkbox others') {
					$('.others-container').toggleClass('hidden');
					if($(this).is(':checked')) {
						$('.others').prop('checked', true);						
					}
					else {
						$('.others').prop('checked', false);
					}
				}
			});

			$('.funds').click(function() {
				var myClass = $(this).attr('class');
				if(myClass == 'funds general') {
					if($(this).is(':checked')) {
						$(this).closest('.chkbox_row').find('.general').prop('checked', true);
					}
					else {
						$(this).closest('.chkbox_row').find('.general').prop('checked', false);
					}
				}
				else if(myClass == 'funds project') {
					if($(this).is(':checked')) {
						$(this).closest('.chkbox_row').find('.project').prop('checked', true);
					}
					else {
						$(this).closest('.chkbox_row').find('.project').prop('checked', false);
					}
				}
				else if(myClass == 'funds others') {
					if($(this).is(':checked')) {
						$(this).closest('.chkbox_row').find('.others').prop('checked', true);
					}
					else {
						$(this).closest('.chkbox_row').find('.others').prop('checked', false);
					}
				}
			});

			if($('.chosen-select').length) {
				$(".chosen-select").chosen();
			}

			var nowDate 	= new Date();
			var today 		= new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 0, 0, 0, 0);

			$('.input-daterange').datepicker({
				format: 'MM dd, yyyy',
				orientation: 'top',
				startDate: today
			});
		</script>
	@stop