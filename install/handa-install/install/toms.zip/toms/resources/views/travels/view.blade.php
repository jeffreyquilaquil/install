@extends('layouts.content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-content">
								<h4><a href="{{ url('travels') }}">Travel Order</a> | {{ $option }}</h4>
								<br>
								<div class="row">
									<div class="input-daterange">
										<div class="col-md-4">
											<label>Start Date: </label>
											<label class="text-primary"><strong>{{ format_date($travel->t_start_date) }}</strong></label>
										</div>
										<div class="col-md-4">
											<label>End Date: </label>
											<label class="text-primary"><strong>{{ format_date($travel->t_end_date) }}</strong></label>
										</div>
									</div>
									<div class="col-md-4">
										<label>Time of Departure: </label>
										<label class="text-primary"><strong>{{ $travel->t_time }}</strong></label>
									</div>
								</div>
								<br>
								<div class="row">
									<div class="col-md-6">
										<label>Destination: </label>
										<label class="text-primary"><strong>{{ $travel->t_destination }}</strong></label>
									</div>
									<div class="col-md-6">
										<label>Mode of Travel: </label>
										<label class="text-primary"><strong>{{ $travel->mode->m_name }}</strong></label>
									</div>
								</div>
								<br>
								<div class="row">
									<div class="col-md-12">
										<div><label>Employee/s: </label></div>
										@foreach($travel->passengers as $user)
											<span class="passenger-container">
												<label class="label label-success"><strong><small>{{ $user->u_fname }} {{ format_middle_name($user->u_mname) }} {{ $user->u_lname }}</small></strong></label>
											</span>
										@endforeach
									</div>
								</div>
								<br>
								<div class="row">
									<div class="col-md-6">
										<label>Purpose: </label>
										<label class="text-primary"><strong>{{ $travel->t_purpose }}</strong></label>
									</div>
									<div class="col-md-6">
										<label>Remarks</label>
										<label class="text-danger"><strong>{{ $travel->t_remarks }}</strong></label>
									</div>
								</div>
								<br>
								<div class="row">
									<div class="col-md-3">
										<label>Travel Documents: </label>
										@foreach($travel->files as $document)
											<div><a href="{{ url('view/'.$document->td_id) }}" target="_blank">{!! $document->td_path !!}</a></div>
										@endforeach
									</div>
								</div>
								<br>
								<div class="row">
									<div class="col-md-3">
										<label>Travel Expenses to be incurred</label>
									</div>
									<div class="col-md-9 text-center">
										<label>Appropriate/Fund to which travel expenses would be charged to:</label>
									</div>
								</div>
								<br>
								<table width="100%">
									<thead>
										<tr>
											<th width="30%">&nbsp</th>
											<th width="23%" class="text-center">(@if(in_array('1', $funds))<span class="fa fa-check"></span>@else &nbsp @endif) General Fund</th>
											<th width="23%" class="text-center">(@if(in_array('2', $funds))<span class="fa fa-check"></span>@else &nbsp @endif) Project Funds</th>
											<th width="23%" class="text-center">(@if(in_array('3', $funds))<span class="fa fa-check"></span>@else &nbsp @endif) Others</th>
										</tr>
									</thead>
								</table>
								<table width="100%">
									@foreach($expenses as $key => $expense)
										@if($key == 0)
											<tr>
												<th>Actual</th>
											</tr>
										@elseif($key == 3)
											<tr>
												<th>Per Diem</th>
											</tr>
										@endif
										<tr>
											<td width="30%">{!! $expense->e_name !!}</td>
											<td width="23%" class="text-center">
												@foreach($travel->expenses as $ex)
													@if($ex->pivot->f_id == 1 && $ex->e_id == $expense->e_id)
														<span class="fa fa-check"></span>
													@endif
												@endforeach
												&nbsp
											</td>
											<td width="23%" class="text-center">
												@foreach($travel->expenses as $ex)
													@if($ex->pivot->f_id == 2 && $ex->e_id == $expense->e_id)
														<span class="fa fa-check"></span>
													@endif
												@endforeach
												&nbsp
											</td>
											<td width="23%" class="text-center">
												@foreach($travel->expenses as $ex)
													@if($ex->pivot->f_id == 3 && $ex->e_id == $expense->e_id)
														{!! $ex->pivot->tfe_others !!}
													@endif
												@endforeach
												&nbsp
											</td>
										</tr>
									@endforeach
								</table>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-content">
                            	<h5>Comments</h5>
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        @if(!count($comments))
                                            <div class="comment-container">
                                            <br><br>
                                            </div>
                                        @else
                                            @foreach($comments as $comment)
                                                <div class="row">
                                                    <div class="col-md-1">
                                                        <img class="img img-circle img-comment" src="{{ $comment->user->u_image == '' ? asset('images/blank-profile.jpg') : asset(''.$comment->user->u_image) }}">
                                                    </div>
                                                    <div class="col-md-11">
                                                        <p>
                                                        	<label class="text-info"><strong>{!! $comment->user->u_fname !!} {!! format_middle_name($comment->user->u_mname) !!} {!! $comment->user->u_lname !!}</strong></label><br>
                                                            {!! nl2br($comment->tc_comment) !!}<br>
                                                            <label><small>{{ get_date_diff($comment->created_at) }}</small></label>
                                                        </p>
                                                    </div>
                                                </div>
                                            @endforeach
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                	<div class="col-md-12">
                		<div class="pull-right">
                			<a href="{{ url('pdf/'.$travel->t_id) }}" target="_blank" class="btn btn-primary"><span class="fa fa-print"></span> Print</a>
                		</div>
                	</div>
                </div>
			</div>
		</div>
	@stop