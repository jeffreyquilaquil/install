@extends('layouts.content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-10">
						<div class="card">
							<div class="card-content">
								<h4><a href="{{ url('users') }}">Users</a> | {{ $option }}</h4>
								{!! Form::model($user, ['url' => 'users/save/'.$id, 'autocomplete' => 'off', 'files' => 'true']) !!}
									<div class="row">
										<div class="col-md-3">
											<div class="form-group label-floating">
												<label class="control-label">First Name <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('u_fname') }}</strong></span></label>
												{!! Form::text('u_fname', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group label-floating">
												<label class="control-label">Middle Name <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('u_mname') }}</strong></span></label>
												{!! Form::text('u_mname', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group label-floating">
												<label class="control-label">Last Name <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('u_lname') }}</strong></span></label>
												{!! Form::text('u_lname', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group label-floating">
												<label class="control-label">Prefix</label>
												{!! Form::text('u_suffix', NULL, ['class' => 'form-control']) !!}
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group label-floating">
												<label class="control-label">Username <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('u_username') }}</strong></span></label>
												{!! Form::text('u_username', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										@if($option != 'Update')
										<div class="col-md-4">
											<div class="form-group label-floating">
												<label class="control-label">Password <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('u_password') }}</strong></span></label>
												{!! Form::password('u_password', ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										@endif
										<div class="col-md-4">
											<div class="form-group label-floating">
												<label class="control-label">Designation <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('u_position') }}</strong></span></label>
												{!! Form::text('u_position', NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
									</div>
									<br>
									<div class="row">
										<div class="col-md-3">
											<div class="form-group label-floating">
												<label class="control-label">Group <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('g_id') }}</strong></span></label>
												{!! Form::select('g_id', $groups, NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group label-floating">
												<label class="control-label">Role <span class="text-danger">*</span> <span class="text-danger"><strong>{{ $errors->first('r_id') }}</strong></span></label>
												{!! Form::select('r_id', $roles, NULL, ['class' => 'form-control', 'required']) !!}
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group label-floating">
												<label class="control-label">Status</label>
												{!! Form::select('is_active', array('1' => 'Active', '0' => 'Inactive'), NULL, ['class' => 'form-control']) !!}
											</div>
										</div>
										<div class="col-md-3">
											<label class="control-label">Signature <span class="text-danger"><strong>{{ $errors->first('u_signature') }}</strong></span></label>
											{!! Form::file('u_signature', ['id' => 'esig']) !!}
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											{!! Form::button('<i class="material-icons">check</i> Save', ['class' => 'btn btn-primary btn-fill text-center pull-right', 'type' => 'submit']) !!}										
										</div>
									</div>
								{!! Form::close() !!}
							</div>
						</div>
					</div>
					<div class="col-md-2">
						<div class="row">
							<div class="card">
								<div class="card-content">
									<div class="text-center">
										<label>Image Preview</label>
										<img src="{{ asset('images/no-preview-available.png') }}" class="img-responsive img-rounded text-center" id="esig-container" height="100" width="100%">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			function readURL(input) {
				if(input.files && input.files[0]) {
					var reader = new FileReader();

					reader.onload = function(e) {
						$('#esig-container').attr('src', e.target.result);
					}

					reader.readAsDataURL(input.files[0]);
				}
			}

			$('#esig').change(function() {
				readURL(this);
			});
		</script>
	@stop