@extends('layouts.content')
	@section('content')
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-content table-responsive">
							{!! Form::open(['url' => 'users/search', 'class' => 'navbar-form', 'role' => 'search']) !!}
								<div class="form-group is-empty">
									{!! Form::text('search', NULL, ['class' => 'form-control', 'placeholder' => 'Search', 'required']) !!}
		                        	<span class="material-input"></span>
								</div>
								<button type="submit" class="btn btn-white btn-round btn-just-icon">
									<i class="material-icons">search</i><div class="ripple-container"></div>
								</button>
							{!! Form::close() !!}
							@if(!count($users))
								<div class="card-body">
									<h4><small class="text-danger"><strong><span class="fa fa-exclamation-circle"></span> No data found.</strong></small></h4>
								</div>
							@else
								<table class="table">
									<thead>
										<th>ID</th>
										<th>Name</th>
										<th>Designation</th>
										<th>Group</th>
										<th>Role</th>
										<th>Signature</th>
										<th class="text-right"></th>
									</thead>
									<tbody>
										@foreach($users as $key => $user)
										<tr>
											<td>{{ ($users->currentpage() - 1) * $users->perpage() + $key + 1 }}</td>
											<td>{{ $user->u_lname }}, {{ $user->u_fname }} {{ format_middle_name($user->u_mname) }}</td>
											<td>{{ $user->u_position }}</td>
											<td>{{ $user->group == null ? '' : $user->group->g_name }}</td>
											<td>{{ $user->role->r_name }}</td>
											<td><img src="{{ url('image/'.$user->u_id) }}" height="50" alt=""></td>
											<td class="text-right">
												<a href="{{ url('users/reset/'.$user->u_id) }}"><button class="btn btn-warning btn-simple btn-xs" type="button" rel="tooltip" title="" data-original-title="Reset Password"><i class="material-icons">restore</i></button></a>
												<a href="{{ url('users/update/'.$user->u_id) }}"><button class="btn btn-info btn-simple btn-xs" type="button" rel="tooltip" title="" data-original-title="Update"><i class="fa fa-edit fa-lg"></i></button></a>
											</td>
										</tr>
										@endforeach
									</tbody>
								</table>
								@if($users->render())
									<div class="text-center">{!! $users->render() !!}</div>
								@endif
							@endif
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	@stop
    <div id="container-floating">
        <a href="{{ url('users/new') }}">
            <div id="floating-button">
                <p class="plus">+</p>
            </div>    
        </a>
    </div>