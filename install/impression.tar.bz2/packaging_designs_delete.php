<?php
require_once('inc_conn.php');
require_once('inc_secure.php');

if (!can_access('Packaging & Labeling Designs', 'delete')){
    redirect(WEBSITE_URL.'index.php');
}

$pid = requestInteger('pid', 'location: '.WEBSITE_URL.'packaging.php');
$id = requestInteger('id', 'location: '.WEBSITE_URL.'packaging.php');

$sql = "DELETE FROM psi_packaging_designs WHERE design_id = $id";
mysqli_query($GLOBALS['cn'], $sql);

$msg = 'Record Deleted.';

$_SESSION['errmsg'] = $msg;
redirect(WEBSITE_URL.'packaging_designs.php?pid='.$pid);
?>