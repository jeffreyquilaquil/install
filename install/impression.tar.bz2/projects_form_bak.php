<?php
require_once('inc_page.php');
require_once('inc_secure.php');

$id = requestInteger('id', 'location: '.WEBSITE_URL.'projects.php');
$op = requestInteger('op', 'location: '.WEBSITE_URL.'projects.php');

if ($op == 1){
    if (!can_access('Projects', 'edit')){
        redirect(WEBSITE_URL.'index.php');
    }
} else {
    if (!can_access('Projects', 'add')){
        redirect(WEBSITE_URL.'index.php');
    }
}

$GLOBALS['coop_id'] = array();
$GLOBALS['col_id'] = array();
$opstr = 'Add';
if ($op == 1){
    $opstr = 'Edit';
    loadDBValues("psi_projects", "SELECT * FROM psi_projects WHERE prj_id = ".$id);
    load_beneficiaries($id);
    load_collaborators($id);
} else {
    initFormValues('psi_projects');
    $GLOBALS['prj_year_approved'] = date('Y');
    $GLOBALS['prj_longitude'] = DEF_LONGITUDE;
    $GLOBALS['prj_latitude'] = DEF_LATITUDE;

}

loadFormCache('psi_projects', 'coop_id, col_id');

$sel_provinces = getOptions('psi_provinces', 'province_name', 'province_id', $GLOBALS['province_id'], '', 'ORDER BY province_name ASC');
$sel_cities = getOptions('psi_cities', 'city_name', 'city_id', $GLOBALS['city_id'], '', "WHERE province_id = $GLOBALS[province_id] ORDER BY city_name ASC");
$sel_barangays = getOptions('psi_barangays', 'barangay_name', 'barangay_id', $GLOBALS['barangay_id'], '', "WHERE city_id = $GLOBALS[city_id] ORDER BY barangay_name ASC");
$sel_sectors = getOptions('psi_sectors', 'sector_name', 'sector_id', $GLOBALS['sector_id']);

$sel_type = getOptions('psi_project_types', 'prj_type_name', 'prj_type_id', $GLOBALS['prj_type_id']);

$sel_beneficiaries = getOptions('psi_cooperators', 'coop_name', 'coop_id', $GLOBALS['coop_id']);

$sel_collaborators = getOptions('psi_collaborators', 'col_name', 'col_id', $GLOBALS['col_id']);

$sel_usergroup = getOptions('psi_usergroups', 'ug_name', 'ug_id', $GLOBALS['ug_id']);

$sel_status = getOptions('psi_project_status', 'prj_status_name', 'prj_status_id', $GLOBALS['prj_status_id']);

page_header('Projects ('.$opstr.')');

?>
<script>
    var _city_id = <?php echo $GLOBALS['city_id']; ?>;
    var _barangay_id = <?php echo $GLOBALS['barangay_id']; ?>;
</script>
<div class="panel panel-default">
    <div class="panel-heading clearfix">
        <h3 class="panel-title pull-left">Projects (<?php echo $opstr; ?>) </h3>
        <div class="pull-right">
            <a class="btn btn-primary btn-sm" href="projects.php" title="Projects"><span class="fa fa-arrow-circle-left"></span> Back</a>
        </div>
    </div>
    <div class="panel-body">
        <?php if (strlen($GLOBALS['errmsg']) > 0){ ?>
        <div class="alert alert-danger"><?php echo $GLOBALS['errmsg']; ?></div>
        <?php } ?>
        <form method="POST" action="projects_save.php?op=<?php echo $op; ?>&amp;id=<?php echo $id; ?>" accept-charset="UTF-8" class="form" role="form">

        <div class="form-group">
        <label for="prj_title" class="control-label">Project Title *</label>
        &nbsp;&nbsp;<span class="text-danger"><small></small></span>
        <input class="form-control input-sm" placeholder="Project Title" maxlength="255" required="required" name="prj_title" id="prj_title" type="text" value="<?php echo $GLOBALS['prj_title']; ?>">
                </div>

        <div class="form-group">
        <label for="prj_code" class="control-label">Project Code</label>
        &nbsp;&nbsp;<span class="text-danger"><small></small></span>
        <input class="form-control input-sm" placeholder="Project Code" maxlength="255" name="prj_code" id="prj_code" type="text" value="<?php echo $GLOBALS['prj_code']; ?>">
                </div>


        <div class="form-group form-group-sm">
        <label for="prj_type_id" class="control-label">Project Type</label>
        <select class="form-control input-sm" id="prj_type_id" name="prj_type_id">
        <?php echo $sel_type; ?>
        </select>
        </div>

        <div class="form-group form-group-sm">
        <label for="sector_id" class="control-label">Sector</label>
        <select class="form-control input-sm" id="sector_id" name="sector_id">
        <?php echo $sel_sectors; ?>
        </select>
        </div>

        <div class="form-group form-group-sm">
        <label for="coop_id" class="control-label">Beneficiaries</label>
        <select class="form-control input-sm chosen-select" id="coop_id" name="coop_id[]" multiple="multiple" required="required">
        <?php echo $sel_beneficiaries; ?>
        </select>
        </div>


        <div class="form-group form-group-sm">
        <label for="col_id" class="control-label">Collaborating Agencies</label>
        <select class="form-control input-sm chosen-select" id="col_id" name="col_id[]" multiple="multiple">
        <?php echo $sel_collaborators; ?>
        </select>
        </div>

        <div class="form-group form-group-sm">
        <label for="ug_id" class="control-label">Implementor</label>
        <select class="form-control input-sm" id="ug_id" name="ug_id">
        <?php echo $sel_usergroup; ?>
        </select>
        </div>

        <div class="form-group">
        <label for="prj_year_approved" class="control-label">Year Approved *</label>
        <input class="form-control input-sm" placeholder="Year Approved" maxlength="4" min="1800" max="<?php echo date('Y'); ?>" required="required" name="prj_year_approved" id="prj_year_approved" type="number" value="<?php echo $GLOBALS['prj_year_approved']; ?>">
                </div>

        <div class="form-group">
        <label for="prj_objective" class="control-label">Objective *</label>
        <textarea class="form-control input-sm" placeholder="Objective" required="required" name="prj_objective" id="prj_objective" cols="50" rows="4"><?php echo $GLOBALS['prj_objective']; ?></textarea>
        </div>

        <div class="form-group">
        <label for="prj_expected_output" class="control-label">Expected Output *</label>
        <textarea class="form-control input-sm" placeholder="Expected Output" required="required" name="prj_expected_output" id="prj_expected_output" cols="50" rows="4"><?php echo $GLOBALS['prj_expected_output']; ?></textarea>
        </div>

        <div class="form-group">
        <label for="prj_product_line" class="control-label">Products *</label>
        <textarea class="form-control input-sm" placeholder="Products" required="required" name="prj_product_line" id="prj_product_line" cols="50" rows="4"><?php echo $GLOBALS['prj_product_line']; ?></textarea>
        </div>

        <div class="form-group form-group-sm">
        <label for="prj_status_id" class="control-label">Project Status</label>
        <select class="form-control input-sm" id="prj_status_id" name="prj_status_id">
        <?php echo $sel_status; ?>
        </select>
        </div>

        <h3><span class="label label-default full-width">Project Location</span></h3>
        
        <div class="form-group form-group-sm">
        <label for="province_id" class="control-label">Province *</label>
        <select class="form-control input-sm" id="province_id" name="province_id" required="required">
        <?php echo $sel_provinces; ?>
        </select>
        </div>

        <div class="form-group form-group-sm">
        <label for="city_id" class="control-label">City/Town *</label>
        <select class="form-control input-sm" id="city_id" name="city_id" required="required">
        <?php echo $sel_cities; ?>
        </select>
        </div>

        <div class="form-group form-group-sm">
        <label for="barangay_id" class="control-label">Barangay *</label>
        <select class="form-control input-sm" id="barangay_id" name="barangay_id" required="required">
        <?php echo $sel_barangays; ?>
        </select>
        </div>

        <h3><span class="label label-default full-width">Costs</span></h3>

        <div class="form-group">
        <label for="prj_cost_setup" class="control-label">SETUP Project Cost</label>
        <input class="form-control input-sm" placeholder="SETUP Project Cost" min="0" step="any" name="prj_cost_setup" id="prj_cost_setup" type="number" value="<?php echo $GLOBALS['prj_cost_setup']; ?>">
                </div>

        <div class="form-group">
        <label for="prj_cost_gia" class="control-label">GIA Project Cost</label>
        <input class="form-control input-sm" placeholder="GIA Project Cost" min="0" step="any" name="prj_cost_gia" id="prj_cost_gia" type="number" value="<?php echo $GLOBALS['prj_cost_gia']; ?>">
                </div>

        <div class="form-group">
        <label for="prj_cost_rollout" class="control-label">Roll-out Project Cost</label>
        <input class="form-control input-sm" placeholder="Roll-out Project Cost" min="0" step="any" name="prj_cost_rollout" id="prj_cost_rollout" type="number" value="<?php echo $GLOBALS['prj_cost_rollout']; ?>">
                </div>

        <div class="form-group">
        <label for="prj_cost_benefactor" class="control-label">Beneficiaries&rsquo; Counterpart Project Cost</label>
        <input class="form-control input-sm" placeholder="Beneficiaries&rsquo; Counterpart Project Cost" min="0" step="any" name="prj_cost_benefactor" id="prj_cost_benefactor" type="number" value="<?php echo $GLOBALS['prj_cost_benefactor']; ?>">
                </div>

        <div class="form-group">
        <label for="prj_cost_other" class="control-label">Other Project Cost</label>
        <input class="form-control input-sm" placeholder="Other Project Cost" min="0" step="any" name="prj_cost_other" id="prj_cost_other" type="number" value="<?php echo $GLOBALS['prj_cost_other']; ?>">
                </div>

        <h3><span class="label label-default full-width">Project Map Coordinates</span></h3>
        <div id="map-location-picker" class="form-group map-location-picker">
        </div>

        <div class="form-group">
        <label for="prj_longitude" class="control-label">Longitude</label>
        <input class="form-control input-sm" placeholder="Longitude" min="0" step="any" name="prj_longitude" id="longitude" type="number" value="<?php echo $GLOBALS['prj_longitude']; ?>">
                </div>

        <div class="form-group">
        <label for="prj_latitude" class="control-label">Latitude</label>
        <input class="form-control input-sm" placeholder="Latitude" min="0" step="any" name="prj_latitude" id="latitude" type="number" value="<?php echo $GLOBALS['prj_latitude']; ?>">
                </div>

        <div class="form-group">
        <label for="prj_elevation" class="control-label">Elevation</label>
        <input class="form-control input-sm" placeholder="Elevation" min="0" step="any" name="prj_elevation" id="elevation" type="number" value="<?php echo $GLOBALS['prj_elevation']; ?>">
                </div>

        <input class="btn btn-primary btn-block" type="submit" name="save" id="save" value="Save">
        <input type="hidden" name="prj_id" value="<?php echo $GLOBALS['prj_id']; ?>">
        </form>
    </div>
    <div class="panel-footer">
    </div>
</div>
<script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
<script>
var _longitude = <?php echo $GLOBALS['prj_longitude']; ?>;
var _latitude = <?php echo $GLOBALS['prj_latitude']; ?>;
</script>
<?php 
    page_footer();

    function load_beneficiaries($pid){
        $sql = "SELECT * FROM psi_project_beneficiaries WHERE prj_id = $pid";
        $res = mysqli_query($GLOBALS['cn'], $sql);
        if (!$res) return;
        while ($row = mysqli_fetch_array($res)){
            $GLOBALS['coop_id'][] = $row['coop_id'];
        }
        mysqli_free_result($res);
    }

    function load_collaborators($pid){
        $sql = "SELECT * FROM psi_project_collaborators WHERE prj_id = $pid";
        $res = mysqli_query($GLOBALS['cn'], $sql);
        if (!$res) return;
        while ($row = mysqli_fetch_array($res)){
            $GLOBALS['col_id'][] = $row['col_id'];
        }
        mysqli_free_result($res);
    }
?>