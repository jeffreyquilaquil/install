#!/bin/bash

# install composer
curl -s http://getcomposer.org/installer | sudo php
sudo mv composer.phar /usr/local/bin/

# install php-gd
sudo apt-get install php-gd

# install wkhtmltopdf
sudo apt-get install ttf-mscorefonts-installer
sudo apt-get install xvfb
sudo dpkg -i ./wkhtmltopdf/wkhtmltox-0.12.2.1_linux-trusty-amd64.deb
sudo apt-get -f install
echo 'exec xvfb-run -a -s "-screen 0 640x480x16" wkhtmltopdf "$@"' | sudo tee /usr/local/bin/wkhtmltopdf.sh >/dev/null && sudo chmod a+x /usr/local/bin/wkhtmltopdf.sh

# copy key-gen to your home directory
mkdir ~/.ssh
cp ./.ssh/id_rsa ~/.ssh
cp ./.ssh/id_rsa.pub ~/.ssh
chmod -R 700 ~/.ssh

# clone TOMS
mkdir /var/web
git clone -b toms-dost --single-branch dost@124.105.2.58:/var/web/toms.git /var/web/toms
(cd /var/web/toms; /usr/local/bin/composer.phar install --prefer-dist)
(cd /var/web/toms; php artisan optimize)
cp ./.env /var/web/toms
(cd /var/web/lguids; php artisan key:generate)

sudo chmod -R 777 /var/web/toms

if grep -qF "Alias /toms /var/web/toms/public" /etc/apache2/sites-available/000-default.conf;then
   echo "Alias already exists, skipping.."
else
	sudo sed -i '6i Alias /toms /var/web/toms/public' /etc/apache2/sites-available/000-default.conf
   echo "Alias added in 000-default.conf"
fi

sudo service apache2 restart

echo "Installation complete!"