-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 12, 2018 at 02:45 AM
-- Server version: 5.7.20-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toms_db_dost`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2017_05_01_034756_create_division_table', 1),
('2017_05_02_053535_create_roles_table', 1),
('2017_05_02_054234_create_groups_table', 1),
('2017_05_02_054235_create_users_table', 1),
('2017_05_10_015900_create_modes_table', 1),
('2017_05_10_015951_create_travels_table', 1),
('2017_05_10_053953_create_travel_passengers_table', 1),
('2017_05_12_020539_create_travel_comments', 1),
('2017_05_17_013017_create_settings_table', 1),
('2017_07_12_021906_create_travel_documents', 1),
('2017_07_12_022701_create_funds_table', 1),
('2017_07_12_022736_create_expenses_table', 1),
('2017_07_12_023316_create_travel_funds_expense', 1),
('2017_07_20_082650_create_travel_officials', 1),
('2017_07_25_015746_create_travel_signatures', 1),
('2017_08_22_063815_create_offset_table', 1),
('2017_08_22_064915_create_offset_dates_table', 1),
('2017_08_25_075818_create_offset_comments', 1),
('2017_09_05_031414_create_overtime_hours', 1),
('2017_09_08_012804_alter_overtime_table', 1),
('2017_09_25_054816_alter_overtime_hours_table', 1),
('2017_10_02_061930_alter_offset_hours', 1),
('2017_10_20_060442_alter_offset_table', 1),
('2017_10_26_011939_alter_official_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `to_divisions`
--

CREATE TABLE `to_divisions` (
  `d_id` int(10) UNSIGNED NOT NULL,
  `d_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `to_divisions`
--

INSERT INTO `to_divisions` (`d_id`, `d_name`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Regional Office', 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(2, 'Provincial Office', 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(3, 'Finance and Administrative Services', 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31');

-- --------------------------------------------------------

--
-- Table structure for table `to_expenses`
--

CREATE TABLE `to_expenses` (
  `e_id` int(10) UNSIGNED NOT NULL,
  `e_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `to_expenses`
--

INSERT INTO `to_expenses` (`e_id`, `e_name`, `created_at`, `updated_at`) VALUES
(1, 'Accomodation', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(2, 'Meals/Food', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(3, 'Incidental expenses', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(4, 'Accomodation', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(5, 'Subsistence', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(6, 'Incidental expenses', '2018-01-12 02:34:31', '2018-01-12 02:34:31');

-- --------------------------------------------------------

--
-- Table structure for table `to_funds`
--

CREATE TABLE `to_funds` (
  `f_id` int(10) UNSIGNED NOT NULL,
  `f_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `to_funds`
--

INSERT INTO `to_funds` (`f_id`, `f_name`, `created_at`, `updated_at`) VALUES
(1, 'General Funds', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(2, 'Project Funds', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(3, 'Others', '2018-01-12 02:34:31', '2018-01-12 02:34:31');

-- --------------------------------------------------------

--
-- Table structure for table `to_groups`
--

CREATE TABLE `to_groups` (
  `g_id` int(10) UNSIGNED NOT NULL,
  `g_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `d_id` int(10) UNSIGNED NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `to_groups`
--

INSERT INTO `to_groups` (`g_id`, `g_name`, `d_id`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Cavite', 2, 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(2, 'Laguna', 2, 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(3, 'Batangas', 2, 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(4, 'Rizal', 2, 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(5, 'Quezon', 2, 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(6, 'Regional Office', 1, 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(7, 'Finance and Administrative Services', 3, 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31');

-- --------------------------------------------------------

--
-- Table structure for table `to_modes`
--

CREATE TABLE `to_modes` (
  `m_id` int(10) UNSIGNED NOT NULL,
  `m_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `to_modes`
--

INSERT INTO `to_modes` (`m_id`, `m_name`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'DOST Vehicle', 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(2, 'Public Conveyance', 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(3, 'Van Rental', 1, '2018-01-12 02:34:31', '2018-01-12 02:34:31');

-- --------------------------------------------------------

--
-- Table structure for table `to_officials`
--

CREATE TABLE `to_officials` (
  `to_id` int(10) UNSIGNED NOT NULL,
  `u_id` int(10) UNSIGNED NOT NULL,
  `g_id` int(10) UNSIGNED NOT NULL,
  `r_id` int(10) UNSIGNED NOT NULL,
  `to_approval` int(10) UNSIGNED NOT NULL,
  `to_type` tinyint(3) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `to_offset`
--

CREATE TABLE `to_offset` (
  `o_id` int(10) UNSIGNED NOT NULL,
  `u_id` int(10) UNSIGNED NOT NULL,
  `o_supervisor` tinyint(3) UNSIGNED NOT NULL,
  `o_recommending` tinyint(3) UNSIGNED NOT NULL,
  `o_approval` tinyint(3) UNSIGNED NOT NULL,
  `is_read` tinyint(4) NOT NULL DEFAULT '0',
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `to_offset_comments`
--

CREATE TABLE `to_offset_comments` (
  `oc_id` int(10) UNSIGNED NOT NULL,
  `o_id` int(10) UNSIGNED NOT NULL,
  `u_id` int(10) UNSIGNED NOT NULL,
  `oc_comment` text COLLATE utf8_unicode_ci NOT NULL,
  `is_read` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `to_offset_dates`
--

CREATE TABLE `to_offset_dates` (
  `od_id` int(10) UNSIGNED NOT NULL,
  `o_id` int(10) UNSIGNED NOT NULL,
  `od_date` date NOT NULL,
  `od_time` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `od_hours` int(10) UNSIGNED NOT NULL,
  `od_remarks` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `to_overtime_hours`
--

CREATE TABLE `to_overtime_hours` (
  `oh_id` int(10) UNSIGNED NOT NULL,
  `u_id` int(10) UNSIGNED NOT NULL,
  `oh_hours` int(10) UNSIGNED NOT NULL,
  `oh_minutes` int(10) UNSIGNED NOT NULL,
  `oh_month` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oh_year` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oh_used` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oh_date` date DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `to_roles`
--

CREATE TABLE `to_roles` (
  `r_id` int(10) UNSIGNED NOT NULL,
  `r_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `to_roles`
--

INSERT INTO `to_roles` (`r_id`, `r_name`, `created_at`, `updated_at`) VALUES
(1, 'Superuser', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(2, 'Administrator', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(3, 'Regional Director', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(4, 'Assistant Regional Director - TO', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(5, 'Assistant Regional Director - FAS', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(6, 'Provincial Director', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(7, 'Staff', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(8, 'FAS-HR', '2018-01-12 02:34:31', '2018-01-12 02:34:31'),
(9, 'PSTC', '2018-01-12 02:34:31', '2018-01-12 02:34:31');

-- --------------------------------------------------------

--
-- Table structure for table `to_settings`
--

CREATE TABLE `to_settings` (
  `s_id` int(10) UNSIGNED NOT NULL,
  `s_region_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `s_region_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `to_settings`
--

INSERT INTO `to_settings` (`s_id`, `s_region_name`, `s_region_address`, `created_at`, `updated_at`) VALUES
(1, '', '', '2018-01-12 02:34:31', '2018-01-12 02:34:31');

-- --------------------------------------------------------

--
-- Table structure for table `to_travels`
--

CREATE TABLE `to_travels` (
  `t_id` int(10) UNSIGNED NOT NULL,
  `t_purpose` text COLLATE utf8_unicode_ci NOT NULL,
  `t_destination` text COLLATE utf8_unicode_ci NOT NULL,
  `t_start_date` date NOT NULL,
  `t_end_date` date NOT NULL,
  `t_time` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `t_remarks` text COLLATE utf8_unicode_ci,
  `u_id` int(10) UNSIGNED NOT NULL,
  `m_id` int(10) UNSIGNED NOT NULL,
  `t_recommending` tinyint(3) UNSIGNED NOT NULL,
  `t_approval` tinyint(3) UNSIGNED NOT NULL,
  `is_read` tinyint(4) NOT NULL DEFAULT '0',
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `to_travel_comments`
--

CREATE TABLE `to_travel_comments` (
  `tc_id` int(10) UNSIGNED NOT NULL,
  `t_id` int(10) UNSIGNED NOT NULL,
  `u_id` int(10) UNSIGNED NOT NULL,
  `tc_comment` text COLLATE utf8_unicode_ci NOT NULL,
  `is_read` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `to_travel_documents`
--

CREATE TABLE `to_travel_documents` (
  `td_id` int(10) UNSIGNED NOT NULL,
  `t_id` int(10) UNSIGNED NOT NULL,
  `td_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `to_travel_funds_expenses`
--

CREATE TABLE `to_travel_funds_expenses` (
  `tfe_id` int(10) UNSIGNED NOT NULL,
  `t_id` int(10) UNSIGNED NOT NULL,
  `f_id` int(10) UNSIGNED NOT NULL,
  `e_id` int(10) UNSIGNED NOT NULL,
  `tfe_others` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `to_travel_passengers`
--

CREATE TABLE `to_travel_passengers` (
  `tp_id` int(10) UNSIGNED NOT NULL,
  `t_id` int(10) UNSIGNED NOT NULL,
  `u_id` int(10) UNSIGNED NOT NULL,
  `is_read` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `to_travel_signatures`
--

CREATE TABLE `to_travel_signatures` (
  `ts_id` int(10) UNSIGNED NOT NULL,
  `t_id` int(10) UNSIGNED NOT NULL,
  `u_id` int(10) UNSIGNED NOT NULL,
  `ts_role` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `to_users`
--

CREATE TABLE `to_users` (
  `u_id` int(10) UNSIGNED NOT NULL,
  `u_username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `u_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `u_fname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `u_mname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `u_lname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `u_suffix` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `u_position` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_signature` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `r_id` int(10) UNSIGNED DEFAULT NULL,
  `g_id` int(10) UNSIGNED DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `to_users`
--

INSERT INTO `to_users` (`u_id`, `u_username`, `u_password`, `u_fname`, `u_mname`, `u_lname`, `u_suffix`, `u_position`, `u_signature`, `u_image`, `r_id`, `g_id`, `is_active`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$Ru3dikFTdMDy.COBuAClGOHnmTQXxL9WImTLV6iOC1GZfmCzkhaZe', 'Kevin Brian', 'B', 'Paris', '', 'SRS I', NULL, NULL, 2, NULL, 1, NULL, '2018-01-12 02:34:31', '2018-01-12 02:34:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `to_divisions`
--
ALTER TABLE `to_divisions`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `to_expenses`
--
ALTER TABLE `to_expenses`
  ADD PRIMARY KEY (`e_id`);

--
-- Indexes for table `to_funds`
--
ALTER TABLE `to_funds`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `to_groups`
--
ALTER TABLE `to_groups`
  ADD PRIMARY KEY (`g_id`),
  ADD KEY `to_groups_d_id_foreign` (`d_id`);

--
-- Indexes for table `to_modes`
--
ALTER TABLE `to_modes`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `to_officials`
--
ALTER TABLE `to_officials`
  ADD PRIMARY KEY (`to_id`),
  ADD KEY `to_officials_u_id_foreign` (`u_id`),
  ADD KEY `to_officials_g_id_foreign` (`g_id`),
  ADD KEY `to_officials_r_id_foreign` (`r_id`);

--
-- Indexes for table `to_offset`
--
ALTER TABLE `to_offset`
  ADD PRIMARY KEY (`o_id`),
  ADD KEY `to_offset_u_id_foreign` (`u_id`);

--
-- Indexes for table `to_offset_comments`
--
ALTER TABLE `to_offset_comments`
  ADD PRIMARY KEY (`oc_id`),
  ADD KEY `to_offset_comments_o_id_foreign` (`o_id`),
  ADD KEY `to_offset_comments_u_id_foreign` (`u_id`);

--
-- Indexes for table `to_offset_dates`
--
ALTER TABLE `to_offset_dates`
  ADD PRIMARY KEY (`od_id`),
  ADD KEY `to_offset_dates_o_id_foreign` (`o_id`);

--
-- Indexes for table `to_overtime_hours`
--
ALTER TABLE `to_overtime_hours`
  ADD PRIMARY KEY (`oh_id`),
  ADD KEY `to_overtime_hours_u_id_foreign` (`u_id`);

--
-- Indexes for table `to_roles`
--
ALTER TABLE `to_roles`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `to_settings`
--
ALTER TABLE `to_settings`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `to_travels`
--
ALTER TABLE `to_travels`
  ADD PRIMARY KEY (`t_id`),
  ADD KEY `to_travels_u_id_foreign` (`u_id`),
  ADD KEY `to_travels_m_id_foreign` (`m_id`);

--
-- Indexes for table `to_travel_comments`
--
ALTER TABLE `to_travel_comments`
  ADD PRIMARY KEY (`tc_id`),
  ADD KEY `to_travel_comments_t_id_foreign` (`t_id`),
  ADD KEY `to_travel_comments_u_id_foreign` (`u_id`);

--
-- Indexes for table `to_travel_documents`
--
ALTER TABLE `to_travel_documents`
  ADD PRIMARY KEY (`td_id`),
  ADD KEY `to_travel_documents_t_id_foreign` (`t_id`);

--
-- Indexes for table `to_travel_funds_expenses`
--
ALTER TABLE `to_travel_funds_expenses`
  ADD PRIMARY KEY (`tfe_id`),
  ADD KEY `to_travel_funds_expenses_t_id_foreign` (`t_id`),
  ADD KEY `to_travel_funds_expenses_f_id_foreign` (`f_id`),
  ADD KEY `to_travel_funds_expenses_e_id_foreign` (`e_id`);

--
-- Indexes for table `to_travel_passengers`
--
ALTER TABLE `to_travel_passengers`
  ADD PRIMARY KEY (`tp_id`),
  ADD KEY `to_travel_passengers_t_id_foreign` (`t_id`),
  ADD KEY `to_travel_passengers_u_id_foreign` (`u_id`);

--
-- Indexes for table `to_travel_signatures`
--
ALTER TABLE `to_travel_signatures`
  ADD PRIMARY KEY (`ts_id`),
  ADD KEY `to_travel_signatures_t_id_foreign` (`t_id`);

--
-- Indexes for table `to_users`
--
ALTER TABLE `to_users`
  ADD PRIMARY KEY (`u_id`),
  ADD KEY `to_users_r_id_foreign` (`r_id`),
  ADD KEY `to_users_g_id_foreign` (`g_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `to_divisions`
--
ALTER TABLE `to_divisions`
  MODIFY `d_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `to_expenses`
--
ALTER TABLE `to_expenses`
  MODIFY `e_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `to_funds`
--
ALTER TABLE `to_funds`
  MODIFY `f_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `to_groups`
--
ALTER TABLE `to_groups`
  MODIFY `g_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `to_modes`
--
ALTER TABLE `to_modes`
  MODIFY `m_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `to_officials`
--
ALTER TABLE `to_officials`
  MODIFY `to_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `to_offset`
--
ALTER TABLE `to_offset`
  MODIFY `o_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `to_offset_comments`
--
ALTER TABLE `to_offset_comments`
  MODIFY `oc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `to_offset_dates`
--
ALTER TABLE `to_offset_dates`
  MODIFY `od_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `to_overtime_hours`
--
ALTER TABLE `to_overtime_hours`
  MODIFY `oh_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `to_roles`
--
ALTER TABLE `to_roles`
  MODIFY `r_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `to_settings`
--
ALTER TABLE `to_settings`
  MODIFY `s_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `to_travels`
--
ALTER TABLE `to_travels`
  MODIFY `t_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `to_travel_comments`
--
ALTER TABLE `to_travel_comments`
  MODIFY `tc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `to_travel_documents`
--
ALTER TABLE `to_travel_documents`
  MODIFY `td_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `to_travel_funds_expenses`
--
ALTER TABLE `to_travel_funds_expenses`
  MODIFY `tfe_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `to_travel_passengers`
--
ALTER TABLE `to_travel_passengers`
  MODIFY `tp_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `to_travel_signatures`
--
ALTER TABLE `to_travel_signatures`
  MODIFY `ts_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `to_users`
--
ALTER TABLE `to_users`
  MODIFY `u_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `to_groups`
--
ALTER TABLE `to_groups`
  ADD CONSTRAINT `to_groups_d_id_foreign` FOREIGN KEY (`d_id`) REFERENCES `to_divisions` (`d_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `to_officials`
--
ALTER TABLE `to_officials`
  ADD CONSTRAINT `to_officials_g_id_foreign` FOREIGN KEY (`g_id`) REFERENCES `to_groups` (`g_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `to_officials_r_id_foreign` FOREIGN KEY (`r_id`) REFERENCES `to_roles` (`r_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `to_officials_u_id_foreign` FOREIGN KEY (`u_id`) REFERENCES `to_users` (`u_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `to_offset`
--
ALTER TABLE `to_offset`
  ADD CONSTRAINT `to_offset_u_id_foreign` FOREIGN KEY (`u_id`) REFERENCES `to_users` (`u_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `to_offset_comments`
--
ALTER TABLE `to_offset_comments`
  ADD CONSTRAINT `to_offset_comments_o_id_foreign` FOREIGN KEY (`o_id`) REFERENCES `to_offset` (`o_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `to_offset_comments_u_id_foreign` FOREIGN KEY (`u_id`) REFERENCES `to_users` (`u_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `to_offset_dates`
--
ALTER TABLE `to_offset_dates`
  ADD CONSTRAINT `to_offset_dates_o_id_foreign` FOREIGN KEY (`o_id`) REFERENCES `to_offset` (`o_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `to_overtime_hours`
--
ALTER TABLE `to_overtime_hours`
  ADD CONSTRAINT `to_overtime_hours_u_id_foreign` FOREIGN KEY (`u_id`) REFERENCES `to_users` (`u_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `to_travels`
--
ALTER TABLE `to_travels`
  ADD CONSTRAINT `to_travels_m_id_foreign` FOREIGN KEY (`m_id`) REFERENCES `to_modes` (`m_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `to_travels_u_id_foreign` FOREIGN KEY (`u_id`) REFERENCES `to_users` (`u_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `to_travel_comments`
--
ALTER TABLE `to_travel_comments`
  ADD CONSTRAINT `to_travel_comments_t_id_foreign` FOREIGN KEY (`t_id`) REFERENCES `to_travels` (`t_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `to_travel_comments_u_id_foreign` FOREIGN KEY (`u_id`) REFERENCES `to_users` (`u_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `to_travel_documents`
--
ALTER TABLE `to_travel_documents`
  ADD CONSTRAINT `to_travel_documents_t_id_foreign` FOREIGN KEY (`t_id`) REFERENCES `to_travels` (`t_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `to_travel_funds_expenses`
--
ALTER TABLE `to_travel_funds_expenses`
  ADD CONSTRAINT `to_travel_funds_expenses_e_id_foreign` FOREIGN KEY (`e_id`) REFERENCES `to_expenses` (`e_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `to_travel_funds_expenses_f_id_foreign` FOREIGN KEY (`f_id`) REFERENCES `to_funds` (`f_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `to_travel_funds_expenses_t_id_foreign` FOREIGN KEY (`t_id`) REFERENCES `to_travels` (`t_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `to_travel_passengers`
--
ALTER TABLE `to_travel_passengers`
  ADD CONSTRAINT `to_travel_passengers_t_id_foreign` FOREIGN KEY (`t_id`) REFERENCES `to_travels` (`t_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `to_travel_passengers_u_id_foreign` FOREIGN KEY (`u_id`) REFERENCES `to_users` (`u_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `to_travel_signatures`
--
ALTER TABLE `to_travel_signatures`
  ADD CONSTRAINT `to_travel_signatures_t_id_foreign` FOREIGN KEY (`t_id`) REFERENCES `to_travels` (`t_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `to_users`
--
ALTER TABLE `to_users`
  ADD CONSTRAINT `to_users_g_id_foreign` FOREIGN KEY (`g_id`) REFERENCES `to_groups` (`g_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `to_users_r_id_foreign` FOREIGN KEY (`r_id`) REFERENCES `to_roles` (`r_id`) ON DELETE CASCADE ON UPDATE CASCADE;
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
